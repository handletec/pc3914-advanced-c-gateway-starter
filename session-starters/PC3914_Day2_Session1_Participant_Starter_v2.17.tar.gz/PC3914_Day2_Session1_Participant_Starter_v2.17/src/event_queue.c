/* event_queue.c — linked-node FIFO of owned events (Day 2). Participants complete TODO-D2.1 in event_queue_pop. */
#include "event_queue.h"
#include "gw_alloc.h"
#include <assert.h>

event_queue_t *event_queue_create(void)
{
    event_queue_t *q = gw_malloc(sizeof *q);
    if (!q)
        return NULL;
    q->head = NULL;
    q->tail = NULL;
    q->size = 0;
    return q;
}

gw_status_t event_queue_push(event_queue_t *q, event_t *event)
{
    if (!event)
        return GW_EINVAL;

    queue_node_t *n = gw_malloc(sizeof *n);
    if (!n)
        return GW_ENOMEM;                   /* queue unchanged; caller still owns event */
    n->event = event;                       /* ownership transfers here */
    n->next  = NULL;

    if (q->tail)
        q->tail->next = n;                  /* append after the current last node */
    else
        q->head = n;                        /* empty queue: the new node is also the head */
    q->tail = n;
    q->size++;
    return GW_OK;
}

/* TODO-D2.1: pop the OLDEST node and hand its event to the caller.
 * This version moves head and frees the node, but leaves the queue in an
 * inconsistent state on some paths. Required, on every path:
 *   a. when the removed node was the last one, tail must become NULL
 *   b. size must be decremented
 *   c. the node is freed, the event is NOT (ownership goes to the caller)
 * The invariants in event_queue.h are what tests/test_event_queue.c checks. */
event_t *event_queue_pop(event_queue_t *q)
{
    if (!q->head)
        return NULL;                        /* empty: expected */

    queue_node_t *n = q->head;
    event_t *e = n->event;
    q->head = n->next;
    gw_free(n);
    return e;
}

size_t event_queue_size(const event_queue_t *q)    { return q->size; }
int    event_queue_is_empty(const event_queue_t *q) { return q->head == NULL; }

void event_queue_destroy(event_queue_t *q)
{
    if (!q)
        return;
    queue_node_t *n = q->head;
    while (n) {
        queue_node_t *next = n->next;       /* read before freeing the node */
        event_free(n->event);               /* still owned by the queue */
        gw_free(n);
        n = next;
    }
    gw_free(q);
}
