/* gateway.c — Wireless Module Diagnostics Gateway (Day 2 Block 1 starter). Participants complete TODO-D2.2a/b.
 *
 *   Simulated Module Events (file) -> Event Parser -> Diagnostic Engine -> Console
 *                                                  -> Intake Queue (owned, FIFO)
 *                                                       -> Processing stage -> Event Store
 *                                                            -> Snapshot (arena, per window)
 *   Sink registry: diag_sink_list_t (registered diagnostic sinks, Day 3 subscribers)
 *
 * Arrival and processing are now separate stages: the parser callback only
 * clones and ENQUEUES; the processing stage DEQUEUES into the store. Today
 * both run in the main loop; Day 3 moves the processing stage to a worker. */
#include "event_parser.h"
#include "event_store.h"
#include "diag_engine.h"
#include "diag_snapshot.h"
#include "event_queue.h"
#include "diag_sink_list.h"
#include "arena.h"
#include "gw_alloc.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define READ_CHUNK      4096
#define SNAPSHOT_EVERY  50
#define ARENA_DEFAULT   16384

static event_store_t *store;
static event_queue_t *intake;                   /* arrival order, owned events */
static size_t         queued, processed;

/* Arrival stage: runs inside the parser callback. */
static void on_event(const event_view_t *ev)
{
    diag_on_event(ev);                          /* engine sees the borrowed view */

    event_t *e = event_clone(ev);               /* retain an owned copy */
    if (!e) {
        fprintf(stderr, "warning: event dropped (out of memory)\n");
        return;
    }
    /* TODO-D2.2a: replace the direct store push below with
     *   event_queue_push(intake, e) -> on GW_OK: queued++ ; otherwise we still
     *   own e: report and event_free(e).
     * Until then the gateway behaves exactly as at the end of Day 1. */
    if (event_store_push(store, e) != 0) {      /* store unchanged; we still own e */
        fprintf(stderr, "warning: event dropped (store full)\n");
        event_free(e);
    }
}

/* TODO-D2.2b: processing stage — drain the intake queue into the store.
 *   while ((e = event_queue_pop(intake)) != NULL)      ownership: queue -> us
 *       event_store_push(store, e) == 0 -> processed++  ownership: us -> store
 *       otherwise: report, event_free(e)               still ours
 * Called once per read chunk, before the snapshot cycle. */
static void process_intake(void)
{
    /* not implemented yet */
}

static void usage(const char *prog)
{
    fprintf(stderr, "usage: %s [--arena BYTES] <events-file>\n", prog);
}

int main(int argc, char **argv)
{
    size_t arena_bytes = ARENA_DEFAULT;
    int argi = 1;
    if (argc >= 3 && strcmp(argv[1], "--arena") == 0) {
        char *endp;
        errno = 0;                                          /* POSIX errno: library boundary */
        unsigned long v = strtoul(argv[2], &endp, 10);
        if (errno != 0 || *endp != '\0' || v == 0) {
            usage(argv[0]);
            return 2;
        }
        arena_bytes = (size_t)v;
        argi = 3;
    }
    if (argc != argi + 1) {
        usage(argv[0]);
        return 2;
    }

    FILE *in = fopen(argv[argi], "rb");
    if (!in) {
        perror(argv[argi]);                                 /* errno -> message at the boundary */
        return 1;
    }

    store = event_store_create(64);
    if (!store) {
        fprintf(stderr, "error: cannot create event store\n");
        fclose(in);
        return 1;
    }
    arena_t arena;
    gw_status_t st = arena_init(&arena, arena_bytes);       /* project status code */
    if (st != GW_OK) {
        fprintf(stderr, "error: arena_init(%zu): %s\n", arena_bytes, gw_strstatus(st));
        event_store_destroy(store);
        fclose(in);
        return 1;
    }
    intake = event_queue_create();
    diag_sink_list_t sinks;
    diag_sink_list_init(&sinks);
    if (!intake ||
        diag_sink_list_add(&sinks, 1, "console") != GW_OK ||
        diag_sink_list_add(&sinks, 2, "snapshot-log") != GW_OK) {
        fprintf(stderr, "error: cannot set up intake queue / sink registry\n");
        diag_sink_list_destroy(&sinks);
        event_queue_destroy(intake);
        arena_destroy(&arena);
        event_store_destroy(store);
        fclose(in);
        return 1;
    }
    diag_init();

    char   buf[READ_CHUNK];
    size_t held = 0;
    parse_result_t total = { 0, 0, 0 };
    size_t reported = 0, snapshots = 0, skipped = 0, arena_peak = 0;
    int rc = 0;

    for (;;) {
        size_t n = fread(buf + held, 1, sizeof buf - held, in);
        if (n == 0)
            break;
        held += n;

        parse_result_t r = parse_events(buf, held, on_event);
        total.events   += r.events;
        total.rejected += r.rejected;
        memmove(buf, buf + r.consumed, held - r.consumed);
        held -= r.consumed;
        if (held == sizeof buf) {
            fprintf(stderr, "error: record longer than %d bytes\n", READ_CHUNK);
            rc = 1;
            break;
        }

        process_intake();                       /* D2.2b: processing stage, after each read */

        /* L3.2c: snapshot cycle — build, emit, release the whole batch */
        while (event_store_len(store) - reported >= SNAPSHOT_EVERY) {
            snapshot_t snap;
            size_t first = reported, last = reported + SNAPSHOT_EVERY;
            st = diag_snapshot_build(store, first, last, &arena, &snap);
            if (st == GW_OK) {
                diag_snapshot_emit(&snap, stdout);
                snapshots++;
            } else {
                fprintf(stderr, "snapshot %zu..%zu skipped: %s (arena %zu/%zu bytes)\n",
                        first, last, gw_strstatus(st), arena_used(&arena), arena.capacity);
                skipped++;
            }
            if (arena_used(&arena) > arena_peak)
                arena_peak = arena_used(&arena);
            arena_reset(&arena);            /* snap and everything it points to is now invalid */
            reported = last;
        }
    }
    fclose(in);

    if (held > 0 && rc == 0)
        fprintf(stderr, "warning: %zu bytes of incomplete record at end of input\n", held);

    diag_report();
    printf("parser: %zu events, %zu rejected\n", total.events, total.rejected);
    printf("store: %zu retained events\n", event_store_len(store));
    printf("snapshots: %zu emitted, %zu skipped, arena peak %zu of %zu bytes\n",
           snapshots, skipped, arena_peak, arena.capacity);
    printf("intake: %zu queued, %zu processed, %zu still queued\n",
           queued, processed, event_queue_size(intake));
    printf("sinks: %zu registered\n", diag_sink_list_count(&sinks));

    diag_sink_list_destroy(&sinks);
    event_queue_destroy(intake);                /* frees anything still queued */
    intake = NULL;
    diag_shutdown();
    arena_destroy(&arena);
    event_store_destroy(store);
    store = NULL;
    printf("heap: %zu new blocks, %zu live at exit\n",
           gw_alloc_total_count(), gw_alloc_live_count());
    return rc;
}
