# PC3914 Day 2 — Session 1: Linear Structures

This is the participant stage-entry workspace for the current session. It contains the verified Day 1 final state plus the current session's intentionally incomplete work. It contains only the current participant stage-entry source and verification assets.

## First commands

```bash
make course-status
make test-day2
```

At the untouched starter state, `make test-day2` intentionally stops at TODO-D2.1a. This is the current task boundary, not a broken distribution.

## Current participant work

`TODO-D2.1, TODO-D2.2a/b, TODO-D2.3`

Use `make checkpoint` to save your own current source before a substantial change. Stage progression is supplied by the course distribution; do not copy source from another stage.
