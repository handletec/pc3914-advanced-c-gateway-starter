/* work_queue.c — producer/consumer queue over event_queue_t (Day 3 Block 2). */
#include "work_queue.h"
#include <errno.h>

gw_status_t work_queue_init(work_queue_t *q)
{
    q->queue = event_queue_create();
    if (!q->queue)
        return GW_ENOMEM;
    q->closed = 0;
    if (pthread_mutex_init(&q->mutex, NULL) != 0) {
        event_queue_destroy(q->queue);
        q->queue = NULL;
        return GW_EIO;
    }
    if (pthread_cond_init(&q->not_empty, NULL) != 0) {
        pthread_mutex_destroy(&q->mutex);
        event_queue_destroy(q->queue);
        q->queue = NULL;
        return GW_EIO;
    }
    return GW_OK;
}

/* TODO-D3.3: make push safe for many producers and one or more waiting consumers.
 *   1. lock the mutex
 *   2. if closed: unlock and return GW_ECLOSED — the caller still owns e
 *   3. push to the underlying queue; on GW_ENOMEM unlock and return it (caller still owns e)
 *   4. the predicate "not empty" is now true: pthread_cond_signal(&q->not_empty)
 *   5. unlock, return GW_OK
 * The starter touches the FIFO with no lock, no closed check and no signal. */
gw_status_t work_queue_push(work_queue_t *q, event_t *e)
{
    if (!e)
        return GW_EINVAL;
    return event_queue_push(q->queue, e);       /* starter: unsafe */
}

/* TODO-D3.4a: wait for an item without spinning.
 *   lock
 *   while (event_queue_size(q->queue) == 0 && !q->closed)
 *       pthread_cond_wait(&q->not_empty, &q->mutex);   -- releases the mutex while asleep, holds it on return
 *   if an item exists: pop it into *out, unlock, return GW_OK   (caller owns *out)
 *   else (closed and empty): unlock, return GW_ECLOSED
 * `while`, never `if`: a wake-up is a hint to re-check, not a promise.
 * The starter never waits: an empty queue is reported as closed. */
gw_status_t work_queue_pop(work_queue_t *q, event_t **out)
{
    pthread_mutex_lock(&q->mutex);
    event_t *e = event_queue_pop(q->queue);
    pthread_mutex_unlock(&q->mutex);
    if (!e)
        return GW_ECLOSED;                      /* starter: wrong — empty is not closed */
    *out = e;
    return GW_OK;
}

/* TODO-D3.4b: close must wake EVERY waiter, not one.
 *   lock; closed = 1; pthread_cond_broadcast(&q->not_empty); unlock
 * The starter sets the flag and wakes nobody: idle workers sleep forever. */
void work_queue_close(work_queue_t *q)
{
    pthread_mutex_lock(&q->mutex);
    q->closed = 1;
    pthread_mutex_unlock(&q->mutex);
}

size_t work_queue_size(work_queue_t *q)
{
    pthread_mutex_lock(&q->mutex);
    size_t n = event_queue_size(q->queue);
    pthread_mutex_unlock(&q->mutex);
    return n;
}

int work_queue_is_closed(work_queue_t *q)
{
    pthread_mutex_lock(&q->mutex);
    int c = q->closed;
    pthread_mutex_unlock(&q->mutex);
    return c;
}

/* After every user thread has been joined: nobody can be waiting on not_empty
 * or holding the mutex, so destroying them is safe. Remaining events are freed
 * by the underlying queue (it still owns them). */
void work_queue_destroy(work_queue_t *q)
{
    if (!q->queue)
        return;
    pthread_cond_destroy(&q->not_empty);
    pthread_mutex_destroy(&q->mutex);
    event_queue_destroy(q->queue);
    q->queue = NULL;
}
