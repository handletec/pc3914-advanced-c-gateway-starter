/* worker_pool.c — workers with a clean shutdown path (Day 3 Block 2).
 *
 * pthread functions return an error NUMBER; they do not set errno. Failures
 * are reported with strerror(rc) and translated to GW_EIO at this boundary. */
#include "worker_pool.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* One worker. It writes only its own slot; main reads the slot after join. */
static void *worker_main(void *arg)
{
    worker_slot_t *slot = arg;
    event_t *e;
    while (work_queue_pop(slot->queue, &e) == GW_OK) {   /* returns with the mutex RELEASED */
        slot->fn(e, slot->ctx);                          /* slow work: no queue lock held here */
        slot->processed++;
    }
    return NULL;                                         /* GW_ECLOSED: closed and drained */
}

gw_status_t worker_pool_start(worker_pool_t *p, work_queue_t *q, size_t n, work_fn_t fn, void *ctx)
{
    if (!p || !q || !fn || n == 0 || n > WORKER_MAX)
        return GW_EINVAL;
    p->queue = q;
    p->count = 0;
    p->joined_processed = 0;
    for (size_t i = 0; i < n; i++) {
        worker_slot_t *slot = &p->slots[i];
        slot->queue     = q;
        slot->fn        = fn;
        slot->ctx       = ctx;
        slot->processed = 0;
        int rc = pthread_create(&slot->thread, NULL, worker_main, slot);
        if (rc != 0) {                                   /* rc IS the error; errno says nothing */
            fprintf(stderr, "worker_pool_start: pthread_create: %s\n", strerror(rc));
            /* Partial startup is a special unwind: close the queue, then prove
             * every created thread is joined before returning. Do not rely on
             * worker_pool_stop() here because the participant may still be
             * implementing TODO-D3.4c. If joining cannot be proven, abort
             * rather than return to code that could destroy worker-visible state. */
            work_queue_close(q);
            while (p->count > 0) {
                worker_slot_t *created = &p->slots[p->count - 1];
                int jrc = pthread_join(created->thread, NULL);
                if (jrc != 0) {
                    fprintf(stderr, "worker_pool_start: pthread_join during rollback: %s\n", strerror(jrc));
                    abort();
                }
                p->count--;
            }
            return GW_EIO;                               /* queue is closed; this run cannot continue */
        }
        p->count++;
    }
    return GW_OK;
}

/* TODO-D3.4c: shut down in the only safe order.
 *   1. work_queue_close(p->queue)   -- wakes every idle worker; busy ones finish their item
 *   2. join from the END of slots[0..count), one at a time
 *      on success: add slot->processed to joined_processed, then decrement count
 *      on failure: return GW_EIO immediately; *processed_out stays untouched
 *      and slots[0..count) still identifies every unjoined worker
 *   3. when count reaches 0: publish joined_processed, reset it, return GW_OK
 * Never destroy the queue's mutex/cond before this returns.
 * The starter closes and returns a published total of 0: nothing was joined,
 * so the workers may still be running and their counts are lost. */
gw_status_t worker_pool_stop(worker_pool_t *p, size_t *processed_out)
{
    if (!p || !processed_out)
        return GW_EINVAL;
    work_queue_close(p->queue);
    *processed_out = 0;                                  /* starter: nothing joined, nothing counted */
    return GW_OK;
}
