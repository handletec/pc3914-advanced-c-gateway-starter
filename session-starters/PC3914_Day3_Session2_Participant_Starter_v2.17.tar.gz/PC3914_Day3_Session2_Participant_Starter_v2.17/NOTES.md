# PC3914 Day 3 Session 2 Notes

Use this file for observations, commands, evidence and questions during the current session.
