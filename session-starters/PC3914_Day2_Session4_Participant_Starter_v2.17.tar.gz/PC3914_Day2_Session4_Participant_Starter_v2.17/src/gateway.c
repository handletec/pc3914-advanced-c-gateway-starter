/* gateway.c — Wireless Module Diagnostics Gateway (Day 2 Block 4).
 *
 *   Simulated Module Events (file) -> Event Parser -> Diagnostic Engine -> Console
 *                                                  -> Intake Queue (owned, FIFO)
 *                                                       -> Processing stage -> Event Store
 *                                                            -> Snapshot (arena, per window)
 *   Sink registry: diag_sink_list_t (registered diagnostic sinks, Day 3 subscribers)
 *
 * Arrival and processing are separate stages: the parser callback only
 * clones and ENQUEUES; the processing stage DEQUEUES into the store, steps
 * each module's LIFECYCLE (State: module_state_machine, stored in the
 * DEVICE REGISTRY) and raises ALERTS chosen by the selected classification
 * POLICY (Strategy: alert_strategy, picked with --policy at run time) into
 * a priority heap. Trace output is a BUILD-TIME choice (gw_trace: compiled
 * in with -DGW_ENABLE_TRACE=1). Three questions, three mechanisms, no
 * #ifdef in this file. Day 3 moves the processing stage to a worker. */
#include "event_parser.h"
#include "event_store.h"
#include "diag_engine.h"
#include "diag_snapshot.h"
#include "event_queue.h"
#include "diag_sink_list.h"
#include "device_registry.h"
#include "alert_heap.h"
#include "alert_strategy.h"
#include "module_state_machine.h"
#include "gw_trace.h"
#include "arena.h"
#include "gw_alloc.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define READ_CHUNK      4096
#define SNAPSHOT_EVERY  50
#define ARENA_DEFAULT   16384

static event_store_t    *store;
static event_queue_t    *intake;                /* arrival order, owned events */
static device_registry_t *devices;              /* current state per module_id (opaque handle) */
static alert_heap_t      alerts;                /* most urgent first */
static const alert_strategy_t *policy;          /* classification policy chosen at start-up (Strategy) */
static size_t            queued, processed, raised;
static size_t            transitions, stayed, rejected;   /* lifecycle outcomes (State) */

/* Arrival stage: runs inside the parser callback. */
static void on_event(const event_view_t *ev)
{
    diag_on_event(ev);                          /* engine sees the borrowed view */

    event_t *e = event_clone(ev);               /* retain an owned copy */
    if (!e) {
        fprintf(stderr, "warning: event dropped (out of memory)\n");
        return;
    }
    /* D2.2a: hand the event to the intake queue in arrival order */
    if (event_queue_push(intake, e) != GW_OK) { /* queue unchanged; we still own e */
        fprintf(stderr, "warning: event dropped (intake queue out of memory)\n");
        event_free(e);
        return;
    }
    queued++;
}

/* Step the module's lifecycle with this event and store the result.
 * State: the registry holds the current state; the machine decides the next
 * one; this function only moves the value between them and counts outcomes. */
static void update_device(const event_t *e)
{
    device_state_t d = { e->module_id, MOD_OFFLINE, 0, 0 };
    const device_state_t *cur = device_registry_find(devices, e->module_id);
    if (cur) d = *cur;
    d.last_rssi = e->rssi_dbm;
    d.event_count++;
    sm_outcome_t outcome = module_sm_step(&d.state, e);
    if (device_registry_upsert(devices, &d) != GW_OK) {
        fprintf(stderr, "warning: registry full, state for module %u not updated\n", e->module_id);
        return;
    }
    switch (outcome) {
    case SM_TRANSITION: transitions++; gw_trace("state", e->module_id, module_state_name(d.state)); break;
    case SM_STAY: stayed++; break;
    case SM_REJECTED: rejected++; break;
    }
}

/* Raise an alert if the selected policy says so.
 * Strategy: the caller does not know which policy it holds — it asks. */
static void raise_alert(const event_t *e, uint64_t seq)
{
    alert_t a;
    int raise;
    if (alert_classify(policy, e, seq, &a, &raise) != GW_OK || !raise)
        return;                                     /* invalid policy raises nothing; nothing to raise */
    if (alert_heap_push(&alerts, &a) != GW_OK) {    /* the heap is unchanged by any of this */
        fprintf(stderr, "warning: alert dropped (out of memory)\n");
        return;
    }
    raised++;
    gw_trace("alert", e->module_id, a.code);
}

/* D2.2b: processing stage — drain the intake queue into the store, then
 * step each module's lifecycle and raise alerts (Day 2 Block 4). */
static void process_intake(void)
{
    event_t *e;
    while ((e = event_queue_pop(intake)) != NULL) {    /* ownership: queue -> us */
        uint64_t seq = event_store_len(store);         /* the gateway sequence number */
        if (event_store_push(store, e) != 0) {         /* store unchanged; still ours */
            fprintf(stderr, "warning: event dropped (store full)\n");
            event_free(e);
            continue;
        }
        processed++;                                   /* ownership: us -> store */
        update_device(e);                              /* e is now store-owned: read only */
        raise_alert(e, seq);
    }
}

/* Report line for one device; used through device_registry_for_each. */
static void print_device(const device_state_t *v, void *ctx)
{
    (void)ctx;
    printf("  module %u: %s, last rssi %d dBm, %zu events\n",
           v->module_id, module_state_name(v->state), v->last_rssi, v->event_count);
}

static void usage(const char *prog)
{
    fprintf(stderr, "usage: %s [--arena BYTES] [--policy NAME] <events-file>\n  policies:", prog);
    for (size_t i = 0; i < alert_strategy_count(); i++)
        fprintf(stderr, " %s", alert_strategy_at(i)->name);
    fputc('\n', stderr);
}

int main(int argc, char **argv)
{
    size_t arena_bytes = ARENA_DEFAULT;
    policy = alert_strategy_default();
    int argi = 1;
    while (argi < argc && argv[argi][0] == '-') {
        const char *opt = argv[argi];
        if (strcmp(opt, "--arena") == 0) {
            if (argi + 1 >= argc) { usage(argv[0]); return 2; }
            const char *arg = argv[argi + 1]; char *endp = NULL; errno = 0;
            unsigned long v = strtoul(arg, &endp, 10);
            if (errno != 0 || endp == arg || *endp != '\0' || arg[0] == '-' || v == 0 || v > SIZE_MAX) { usage(argv[0]); return 2; }
            arena_bytes = (size_t)v; argi += 2; continue;
        }
        if (strcmp(opt, "--policy") == 0) {
            if (argi + 1 >= argc) { usage(argv[0]); return 2; }
            policy = alert_strategy_find(argv[argi + 1]);
            if (!policy) { fprintf(stderr, "error: unknown policy '%s'\n", argv[argi + 1]); usage(argv[0]); return 2; }
            argi += 2; continue;
        }
        usage(argv[0]); return 2;
    }
    if (argc != argi + 1) { usage(argv[0]); return 2; }

    FILE *in = fopen(argv[argi], "rb");
    if (!in) {
        perror(argv[argi]);                                 /* errno -> message at the boundary */
        return 1;
    }

    store = event_store_create(64);
    if (!store) {
        fprintf(stderr, "error: cannot create event store\n");
        fclose(in);
        return 1;
    }
    arena_t arena;
    gw_status_t st = arena_init(&arena, arena_bytes);       /* project status code */
    if (st != GW_OK) {
        fprintf(stderr, "error: arena_init(%zu): %s\n", arena_bytes, gw_strstatus(st));
        event_store_destroy(store);
        fclose(in);
        return 1;
    }
    intake = event_queue_create();
    diag_sink_list_t sinks;
    diag_sink_list_init(&sinks);
    alert_heap_init(&alerts);
    devices = device_registry_create(16);
    if (!intake || !devices ||
        diag_sink_list_add(&sinks, 1, "console") != GW_OK ||
        diag_sink_list_add(&sinks, 2, "snapshot-log") != GW_OK) {
        fprintf(stderr, "error: cannot set up intake queue / sink registry\n");
        diag_sink_list_destroy(&sinks);
        event_queue_destroy(intake);
        device_registry_destroy(devices);
        arena_destroy(&arena);
        event_store_destroy(store);
        fclose(in);
        return 1;
    }
    diag_init();

    char   buf[READ_CHUNK];
    size_t held = 0;
    parse_result_t total = { 0, 0, 0 };
    size_t reported = 0, snapshots = 0, skipped = 0, arena_peak = 0;
    int rc = 0;

    for (;;) {
        size_t n = fread(buf + held, 1, sizeof buf - held, in);
        if (n == 0)
            break;
        held += n;

        parse_result_t r = parse_events(buf, held, on_event);
        total.events   += r.events;
        total.rejected += r.rejected;
        memmove(buf, buf + r.consumed, held - r.consumed);
        held -= r.consumed;
        if (held == sizeof buf) {
            fprintf(stderr, "error: record longer than %d bytes\n", READ_CHUNK);
            rc = 1;
            break;
        }

        process_intake();                       /* D2.2b: processing stage, after each read */

        /* L3.2c: snapshot cycle — build, emit, release the whole batch */
        while (event_store_len(store) - reported >= SNAPSHOT_EVERY) {
            snapshot_t snap;
            size_t first = reported, last = reported + SNAPSHOT_EVERY;
            st = diag_snapshot_build(store, first, last, &arena, &snap);
            if (st == GW_OK) {
                diag_snapshot_emit(&snap, stdout);
                snapshots++;
            } else {
                fprintf(stderr, "snapshot %zu..%zu skipped: %s (arena %zu/%zu bytes)\n",
                        first, last, gw_strstatus(st), arena_used(&arena), arena.capacity);
                skipped++;
            }
            if (arena_used(&arena) > arena_peak)
                arena_peak = arena_used(&arena);
            arena_reset(&arena);            /* snap and everything it points to is now invalid */
            reported = last;
        }
    }
    fclose(in);

    if (held > 0 && rc == 0)
        fprintf(stderr, "warning: %zu bytes of incomplete record at end of input\n", held);

    diag_report();
    printf("parser: %zu events, %zu rejected\n", total.events, total.rejected);
    printf("store: %zu retained events\n", event_store_len(store));
    printf("snapshots: %zu emitted, %zu skipped, arena peak %zu of %zu bytes\n",
           snapshots, skipped, arena_peak, arena.capacity);
    printf("intake: %zu queued, %zu processed, %zu still queued\n",
           queued, processed, event_queue_size(intake));
    printf("sinks: %zu registered\n", diag_sink_list_count(&sinks));

    printf("devices: %zu tracked (registry capacity %zu)\n",
           device_registry_count(devices), device_registry_capacity(devices));
    device_registry_for_each(devices, print_device, NULL);      /* D2.6b: through the interface */
    printf("lifecycle: %zu transitions, %zu no-ops, %zu rejected\n", transitions, stayed, rejected);
    printf("alerts: %zu raised (policy %s); most urgent first:\n", raised, policy->name);
    alert_t a;
    for (int shown = 0; shown < 5 && alert_heap_pop(&alerts, &a); shown++)
        printf("  sev %u  seq %llu  module %u  %s\n",
               a.severity, (unsigned long long)a.seq, a.module_id, a.code);
    printf("  (%zu more queued)\n", alert_heap_size(&alerts));

    alert_heap_destroy(&alerts);
    device_registry_destroy(devices);
    devices = NULL;
    diag_sink_list_destroy(&sinks);
    event_queue_destroy(intake);                /* frees anything still queued */
    intake = NULL;
    diag_shutdown();
    arena_destroy(&arena);
    event_store_destroy(store);
    store = NULL;
    printf("heap: %zu new blocks, %zu live at exit\n",
           gw_alloc_total_count(), gw_alloc_live_count());
    return rc;
}
