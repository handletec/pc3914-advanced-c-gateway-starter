/* test_module_state_machine.c — every (state, input) pair has a decided outcome; nothing is invented.
 * Events are built on the stack: the lifecycle rules never allocate. */
#include "module_state_machine.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static char pl_attach[]  = "ATTACH_OK";
static char pl_down[]    = "LINK_DOWN";
static char pl_signal[]  = "CONNECTED";
static char pl_error[]   = "SIM_NOT_READY";

static event_t ev(event_kind_t kind, int16_t rssi)
{
    char *pl = kind == EV_CONNECT ? pl_attach : kind == EV_DISCONNECT ? pl_down
             : kind == EV_ERROR ? pl_error : pl_signal;
    event_t e = { 3, kind, rssi, strlen(pl), pl };
    return e;
}

/* Apply one event and check outcome and resulting state in one line. */
static void expect(module_state_t *s, event_kind_t kind, int16_t rssi,
                   sm_outcome_t want, module_state_t want_state, const char *why)
{
    module_state_t before = *s;
    event_t e = ev(kind, rssi);
    sm_outcome_t got = module_sm_step(s, &e);
    if (got != want || *s != want_state) {
        fprintf(stderr, "  %s + %s(%d): got %s -> %s, want %s -> %s  [%s]\n",
                module_state_name(before), event_kind_name(kind), rssi,
                module_sm_outcome_name(got), module_state_name(*s),
                module_sm_outcome_name(want), module_state_name(want_state), why);
    }
    assert(got == want && *s == want_state);
}

static void test_classify(void)
{
    event_t e;
    e = ev(EV_CONNECT, -70);      assert(module_sm_classify(&e) == SM_IN_CONNECT);
    e = ev(EV_DISCONNECT, -70);   assert(module_sm_classify(&e) == SM_IN_DISCONNECT);
    e = ev(EV_ERROR, -70);        assert(module_sm_classify(&e) == SM_IN_ERROR);
    e = ev(EV_SIGNAL, -99);       assert(module_sm_classify(&e) == SM_IN_SIGNAL_GOOD);  /* boundary */
    e = ev(EV_SIGNAL, -100);      assert(module_sm_classify(&e) == SM_IN_SIGNAL_WEAK);  /* at threshold: weak */
    e = ev(EV_SIGNAL, -113);      assert(module_sm_classify(&e) == SM_IN_SIGNAL_WEAK);
    printf("[classify]   OK\n");
}

/* The complete lifecycle the brief asks for, in one run. */
static void test_full_sequence(void)
{
    module_state_t s = MOD_OFFLINE;
    expect(&s, EV_CONNECT,     -90, SM_TRANSITION, MOD_CONNECTING, "TODO-D2.8a: OFFLINE + CONNECT -> CONNECTING");
    expect(&s, EV_SIGNAL,      -71, SM_TRANSITION, MOD_ONLINE,     "TODO-D2.8a: CONNECTING + good SIGNAL -> ONLINE");
    expect(&s, EV_SIGNAL,     -105, SM_TRANSITION, MOD_DEGRADED,   "TODO-D2.8b: ONLINE + weak SIGNAL -> DEGRADED");
    expect(&s, EV_SIGNAL,      -80, SM_TRANSITION, MOD_ONLINE,     "TODO-D2.8b: DEGRADED + good SIGNAL -> ONLINE");
    expect(&s, EV_DISCONNECT, -101, SM_TRANSITION, MOD_OFFLINE,    "TODO-D2.8b: ONLINE + DISCONNECT -> OFFLINE");
    printf("[sequence]   OK\n");
}

static void test_repeated_and_noop(void)
{
    module_state_t s = MOD_OFFLINE;
    expect(&s, EV_DISCONNECT, -90, SM_STAY, MOD_OFFLINE,    "DISCONNECT while OFFLINE is a no-op");
    expect(&s, EV_CONNECT,    -90, SM_TRANSITION, MOD_CONNECTING, "");
    expect(&s, EV_CONNECT,    -90, SM_STAY, MOD_CONNECTING, "repeated CONNECT while CONNECTING is a no-op");
    expect(&s, EV_SIGNAL,     -70, SM_TRANSITION, MOD_ONLINE, "");
    expect(&s, EV_SIGNAL,     -70, SM_STAY, MOD_ONLINE,      "TODO-D2.8b: good SIGNAL while ONLINE stays ONLINE");
    expect(&s, EV_SIGNAL,    -110, SM_TRANSITION, MOD_DEGRADED, "");
    expect(&s, EV_SIGNAL,    -110, SM_STAY, MOD_DEGRADED,    "TODO-D2.8b: weak SIGNAL while DEGRADED stays DEGRADED");
    printf("[repeated]   OK\n");
}

static void test_error_never_drives_lifecycle(void)
{
    for (int st = 0; st < MOD_STATE_COUNT; st++) {
        module_state_t s = (module_state_t)st;
        expect(&s, EV_ERROR, -113, SM_STAY, (module_state_t)st, "TODO-D2.8b: ERROR is a no-op in every state");
    }
    printf("[error]      OK\n");
}

static void test_rejected(void)
{
    module_state_t s = MOD_OFFLINE;
    expect(&s, EV_SIGNAL,  -70, SM_REJECTED, MOD_OFFLINE, "SIGNAL while OFFLINE is rejected");
    expect(&s, EV_SIGNAL, -110, SM_REJECTED, MOD_OFFLINE, "weak SIGNAL while OFFLINE is rejected");
    s = MOD_ONLINE;
    expect(&s, EV_CONNECT, -70, SM_REJECTED, MOD_ONLINE,   "TODO-D2.8b: CONNECT while ONLINE is rejected");
    s = MOD_DEGRADED;
    expect(&s, EV_CONNECT, -70, SM_REJECTED, MOD_DEGRADED, "TODO-D2.8b: CONNECT while DEGRADED is rejected");

    /* out-of-range values are rejected, never looked up */
    module_state_t next = MOD_ONLINE;
    assert(module_sm_next(MOD_STATE_COUNT, SM_IN_CONNECT, &next) == SM_REJECTED && next == MOD_ONLINE);
    assert(module_sm_next(MOD_OFFLINE, SM_INPUT_COUNT, &next) == SM_REJECTED && next == MOD_ONLINE);
    assert(module_sm_next((module_state_t)-1, SM_IN_CONNECT, &next) == SM_REJECTED && next == MOD_ONLINE);
    printf("[rejected]   OK\n");
}

static void test_disconnect_from_everywhere(void)
{
    module_state_t from[] = { MOD_CONNECTING, MOD_ONLINE, MOD_DEGRADED };
    for (size_t i = 0; i < 3; i++) {
        module_state_t s = from[i];
        expect(&s, EV_DISCONNECT, -95, SM_TRANSITION, MOD_OFFLINE, "TODO-D2.8b: DISCONNECT always leads to OFFLINE");
    }
    printf("[disconnect] OK\n");
}

static void test_recovery(void)
{
    module_state_t s = MOD_CONNECTING;
    expect(&s, EV_SIGNAL, -100, SM_TRANSITION, MOD_DEGRADED, "CONNECTING + weak SIGNAL -> DEGRADED");
    expect(&s, EV_SIGNAL,  -99, SM_TRANSITION, MOD_ONLINE,   "TODO-D2.8b: DEGRADED + good SIGNAL -> ONLINE");
    expect(&s, EV_SIGNAL, -100, SM_TRANSITION, MOD_DEGRADED, "TODO-D2.8b: ONLINE + weak SIGNAL -> DEGRADED");
    printf("[recovery]   OK\n");
}

/* Exhaustive: every cell of the table yields exactly one of the three outcomes,
 * and the outcome agrees with what *next says. No cell is left to chance. */
static void test_table_complete(void)
{
    size_t transitions = 0, stays = 0, rejected = 0;
    for (int st = 0; st < MOD_STATE_COUNT; st++) {
        for (int in = 0; in < SM_INPUT_COUNT; in++) {
            module_state_t next = MOD_STATE_COUNT;
            sm_outcome_t o = module_sm_next((module_state_t)st, (sm_input_t)in, &next);
            if (o == SM_TRANSITION) { assert(next < MOD_STATE_COUNT && next != (module_state_t)st); transitions++; }
            else if (o == SM_STAY)  { assert(next == (module_state_t)st); stays++; }
            else                    { assert(o == SM_REJECTED && next == MOD_STATE_COUNT); rejected++; }
        }
    }
    assert(transitions + stays + rejected == (size_t)MOD_STATE_COUNT * SM_INPUT_COUNT);
    assert(transitions == 8 && stays == 8 && rejected == 4 && "TODO-D2.8b: 8 transitions, 8 no-ops, 4 rejections");
    printf("[table]      OK (%zu transitions, %zu no-ops, %zu rejections)\n", transitions, stays, rejected);
}

static void test_null_contract(void)
{
    assert(module_sm_classify(NULL) == SM_INPUT_COUNT);
    module_state_t next = MOD_ONLINE;
    assert(module_sm_next(MOD_OFFLINE, SM_IN_CONNECT, NULL) == SM_REJECTED);
    assert(next == MOD_ONLINE);
    module_state_t st = MOD_OFFLINE;
    event_t e = ev(EV_CONNECT, -70);
    assert(module_sm_step(NULL, &e) == SM_REJECTED);
    assert(module_sm_step(&st, NULL) == SM_REJECTED);
    assert(st == MOD_OFFLINE);
    printf("[null]       OK\n");
}

int main(void)
{
    test_classify();
    test_null_contract();
    test_full_sequence();
    test_repeated_and_noop();
    test_error_never_drives_lifecycle();
    test_rejected();
    test_disconnect_from_everywhere();
    test_recovery();
    test_table_complete();
    assert(gw_alloc_live_count() == 0 && gw_alloc_total_count() == 0);   /* the rules never allocate */
    printf("test_module_state_machine: all groups passed\n");
    return 0;
}
