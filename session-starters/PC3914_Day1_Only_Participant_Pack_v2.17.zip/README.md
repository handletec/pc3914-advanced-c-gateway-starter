# PC3914 — Day 1 Participant Pack (v2.17)

This pack contains **Day 1 only** for PC3914 — Advanced C Programming.

It contains the four locked Day 1 participant starter snapshots. Each later session is cumulative: start the next session from its supplied snapshot, while your earlier work remains untouched in its own `work/` directory.

## Start Session 1

From the folder containing this README:

```sh
./tools/start-session day1-session1
cd work/day1-session1
make course-status
```

For later sessions, return to the pack root and run one of:

```sh
./tools/start-session day1-session2
./tools/start-session day1-session3
./tools/start-session day1-session4
```

Then enter the corresponding `work/day1-sessionN` directory and continue there.

## Important

- Work only inside `work/<session-id>/`.
- Do not edit files under `session-starters/`.
- `start-session` verifies the SHA-256 checksum before extraction.
- It refuses to overwrite an existing session work directory.
- Earlier session work remains available for comparison or review.

## Session map

- `day1-session1` — bounded parsing and parser contracts
- `day1-session2` — retained data, ownership and Event Store
- `day1-session3` — arena/snapshot/integration work
- `day1-session4` — regression and cumulative Day 1 gate

If a current exercise intentionally fails before you complete its TODO, that is expected. Use the exercise instructions and the session Makefile targets for the current activity.
