# Lab — Build and Consume Gateway Core (30 minutes)

Work in `build/lab/`. Every command below is one you type; the reference
Makefile targets (`make lib-static`, `make client-shared`, …) do the same
in `build/` and you may compare against them, but the point is the commands.

## Part 1 — static library (target: 8 minutes)

    mkdir -p build/lab
    for f in event event_parser event_store event_queue diag_sink_list work_stack \
             device_registry alert_heap event_bst arena diag_snapshot gw_alloc gw_status; do
        gcc -std=c11 -Wall -Wextra -Werror -g -O0 -Iinclude -c src/$f.c -o build/lab/$f.o
    done
    ar rcs build/lab/libgateway_core.a build/lab/*.o
    ar t  build/lab/libgateway_core.a                       # what is inside?
    nm    build/lab/libgateway_core.a | grep device_registry_create   # T = defined here

## Part 2 — link a consumer (target: 6 minutes)

    gcc -std=c11 -Wall -Wextra -Werror -g -O0 -Iinclude -c examples/registry_client.c -o build/lab/registry_client.o
    nm build/lab/registry_client.o | grep device_registry_create      # U = needed, not defined
    gcc -o build/lab/registry_client build/lab/registry_client.o ____________________   # TODO-L2.1: complete the link line
    ./build/lab/registry_client

If you see `undefined reference to 'device_registry_create'`: which stage
failed, what does the message name, and what is missing from the command?

## Part 3 — shared library (target: 8 minutes)

    for f in event event_parser event_store event_queue diag_sink_list work_stack \
             device_registry alert_heap event_bst arena diag_snapshot gw_alloc gw_status; do
        gcc -std=c11 -Wall -Wextra -Werror -g -O0 -Iinclude ______ -c src/$f.c -o build/lab/pic_$f.o   # TODO-L2.2: position-independent code
    done
    gcc ________ -o build/lab/libgateway_core.so build/lab/pic_*.o                                    # TODO-L2.3: make a shared object
    gcc -o build/lab/registry_client_shared build/lab/registry_client.o -Lbuild/lab -lgateway_core
    ./build/lab/registry_client_shared                  # read the message: which stage is this?
    ldd ./build/lab/registry_client_shared | grep gateway_core
    LD_LIBRARY_PATH=build/lab ./build/lab/registry_client_shared

`LD_LIBRARY_PATH` configures the RUNTIME LOADER's search path for this
process only; it changes nothing about the executable. The alternative that
records the path inside the executable:

    gcc -o build/lab/registry_client_rpath build/lab/registry_client.o -Lbuild/lab -lgateway_core -Wl,-rpath,'$PWD/build/lab'
    ./build/lab/registry_client_rpath

## Part 4 — evidence (target: 3 minutes)

    make lab-check

## Debrief (5 minutes)

For each of the three failures you met (undefined reference, loader cannot
open, and the duplicate definition demo): failing stage · message · root
cause · repair.
