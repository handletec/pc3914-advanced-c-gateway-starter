#ifndef EVENT_DIR_H
#define EVENT_DIR_H
#include "gw_status.h"
#include <stddef.h>

/* Event-file discovery (Day 3 Block 1): "which files in this directory are
 * event inputs?"
 *
 * opendir / readdir / closedir, with three rules the tests enforce:
 *   1. skip "." and ".." and any dot-file; accept only names ending in ".txt"
 *      (event_dir_accept — the FILTER is explicit, not "everything")
 *   2. build "<dir>/<name>" into a caller-owned buffer, refusing to truncate
 *      (event_dir_join — the PATH is bounded)
 *   3. keep only regular files, decided by stat(), never by d_type alone
 *      (a directory named legacy.txt is not an input)
 *
 * readdir order is unspecified, so the result is sorted by path for
 * deterministic processing. Paths are COPIED into the caller's array. */

#define EVENT_PATH_MAX 256

typedef struct {
    char path[EVENT_PATH_MAX];
} event_path_t;

int         event_dir_accept(const char *name);                                   /* 1 = an event input, 0 = skip */
gw_status_t event_dir_join(char *out, size_t cap, const char *dir, const char *name);
            /* GW_OK: out = "dir/name" (one '/', even if dir ends with '/'); GW_ENOSPACE: does not fit, out[0] = '\0' */
gw_status_t event_dir_list(const char *dir, event_path_t *out, size_t max, size_t *count);
            /* GW_OK: *count paths, sorted; GW_ENOENT: opendir failed (errno kept);
             * GW_ENOSPACE: more accepted files than max, or a path too long; GW_EIO: readdir/stat error */

#endif
