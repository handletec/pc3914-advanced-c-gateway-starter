#ifndef EVENT_STORE_H
#define EVENT_STORE_H
#include "event.h"
#include <stddef.h>

/* Growable, owning container of retained events.
 * Element pointers returned by event_store_get() stay valid until
 * event_store_destroy(); growth never moves the events themselves. */
typedef struct {
    event_t **items;    /* owned array of owned events */
    size_t    len;
    size_t    cap;
} event_store_t;

event_store_t *event_store_create(size_t initial_cap);   /* NULL on failure */

/* Takes ownership of e on success (returns 0).
 * On failure returns -1: store is unchanged and caller STILL owns e. */
int            event_store_push(event_store_t *s, event_t *e);

const event_t *event_store_get(const event_store_t *s, size_t i);
size_t         event_store_len(const event_store_t *s);

void           event_store_destroy(event_store_t *s);    /* accepts NULL */

#endif
