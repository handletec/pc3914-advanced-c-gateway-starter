#ifndef HEALTH_PIPE_H
#define HEALTH_PIPE_H
#include "gw_status.h"
#include <sys/types.h>

/* Gateway (parent) -> pipe -> health_reporter (child): the process side (Day 3 Block 1).
 *
 *   pipe()   two descriptors: fds[0] read end, fds[1] write end
 *   fork()   both processes continue from the same point; both hold BOTH ends
 *   child    close write end; dup2 read end onto stdin; close the original; exec reporter
 *   parent   close read end; write the record; close write end; waitpid
 *
 * EOF on the read end happens only when EVERY write descriptor is closed —
 * in every process. A forgotten copy in the child keeps the child waiting
 * for itself. A forgotten read end in the parent is a leaked descriptor.
 *
 * spawn_reporter   on GW_OK: *write_fd is the only pipe descriptor this
 *                  process still holds and *pid is the child. On failure
 *                  nothing is left open and no child exists.
 * finish_reporter  closes write_fd (the child then sees EOF), reaps the
 *                  child, and reports: *exit_status = the child's exit code
 *                  (127 when exec failed), or -1 if it died from a signal. */

gw_status_t spawn_reporter(const char *reporter_exe, int *write_fd, pid_t *pid);   /* GW_OK | GW_EIO (errno) */
gw_status_t finish_reporter(int write_fd, pid_t pid, int *exit_status);            /* GW_OK | GW_EIO */

#endif
