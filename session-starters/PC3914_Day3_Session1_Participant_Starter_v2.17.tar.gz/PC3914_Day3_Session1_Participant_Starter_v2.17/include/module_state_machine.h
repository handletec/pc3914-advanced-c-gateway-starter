#ifndef MODULE_STATE_MACHINE_H
#define MODULE_STATE_MACHINE_H
#include "device_registry.h"     /* module_state_t: the lifecycle state the registry stores */
#include "event.h"
#include <stddef.h>

/* Module lifecycle — a State machine (Day 2 Block 4).
 *
 * "Given the CURRENT state and this event, what is the next state?"
 *
 * Since Block 2 the gateway labelled a module with its LAST event; the label
 * carried no memory. A lifecycle has memory: the same SIGNAL event means
 * "attach completed" in CONNECTING, "still fine" in ONLINE and "recovered"
 * in DEGRADED, and is REJECTED in OFFLINE — a module that never connected
 * cannot report signal.
 *
 *   OFFLINE ──CONNECT──▶ CONNECTING ──good SIGNAL──▶ ONLINE
 *                          │ weak SIGNAL              │ weak SIGNAL   ▲ good SIGNAL
 *                          ▼                          ▼               │
 *                        DEGRADED ◀───────────────────┘───────────────┘
 *   any of CONNECTING / ONLINE / DEGRADED ──DISCONNECT──▶ OFFLINE
 *
 * Outcome policy (explicit, tested — nothing is invented):
 *   SM_TRANSITION  a defined transition: *state changed
 *   SM_STAY        a defined no-op (repeated CONNECT while CONNECTING, DISCONNECT
 *                  while OFFLINE, a good SIGNAL while ONLINE, any ERROR): unchanged
 *   SM_REJECTED    not valid in this state (SIGNAL while OFFLINE, CONNECT while
 *                  ONLINE or DEGRADED, out-of-range values): unchanged
 * ERROR events never drive the lifecycle: they are classified by the alert
 * Strategy. The two mechanisms answer different questions and stay apart.
 *
 * Pure rules, no I/O, no allocation, no registry access: the caller reads
 * the state out of the registry, steps it here, and writes it back. */

typedef enum {
    SM_IN_CONNECT = 0,
    SM_IN_DISCONNECT,
    SM_IN_SIGNAL_GOOD,           /* rssi above GW_WEAK_RSSI_DBM */
    SM_IN_SIGNAL_WEAK,           /* rssi at or below GW_WEAK_RSSI_DBM */
    SM_IN_ERROR,
    SM_INPUT_COUNT               /* not an input: array bound for tables */
} sm_input_t;

typedef enum {
    SM_TRANSITION = 0,
    SM_STAY,
    SM_REJECTED
} sm_outcome_t;

sm_input_t   module_sm_classify(const event_t *e);                              /* event -> input class */
sm_outcome_t module_sm_next(module_state_t cur, sm_input_t in, module_state_t *next);
             /* table lookup; *next written only for SM_TRANSITION and SM_STAY (then *next == cur) */
sm_outcome_t module_sm_step(module_state_t *state, const event_t *e);          /* classify + next, in place */
const char  *module_sm_input_name(sm_input_t in);
const char  *module_sm_outcome_name(sm_outcome_t o);

#endif
