#ifndef GW_IO_H
#define GW_IO_H
#include "gw_status.h"
#include <stddef.h>

/* Descriptor-layer I/O helpers (Day 3 Block 1).
 *
 * read() and write() move SOME bytes: a write to a full pipe may transfer
 * part of the buffer; a read returns what is available, not what was asked
 * for; either may fail with EINTR when a signal arrives first. One write
 * does not equal one read. These helpers turn "some" into "all":
 *
 *   write_all   loops until every byte is written or a hard error occurs
 *   read_full   loops until `len` bytes arrived or the peer closed (EOF)
 *
 * Both retry EINTR, advance through the buffer with size_t arithmetic
 * (never mixing the ssize_t result into the remaining count unchecked), and
 * return GW_EIO on a hard failure with errno preserved for the caller.
 * gw_io_stats counts the events the tests look for. */

typedef struct {
    size_t short_writes;     /* write() moved fewer bytes than requested */
    size_t short_reads;      /* read() returned fewer bytes than requested (and not EOF) */
    size_t eintr_retries;    /* read()/write() returned -1 with errno == EINTR */
} gw_io_stats_t;

extern gw_io_stats_t gw_io_stats;

gw_status_t write_all(int fd, const void *buf, size_t len);              /* GW_OK | GW_EIO (errno set) */
gw_status_t read_full(int fd, void *buf, size_t len, size_t *got);       /* GW_OK: *got == len, or *got < len at EOF | GW_EIO */

#endif
