#ifndef DIAG_SNAPSHOT_H
#define DIAG_SNAPSHOT_H
#include "arena.h"
#include "event_store.h"
#include <stdio.h>

/* Per-module summary for one snapshot window. */
typedef struct {
    uint32_t    module_id;
    size_t      events;
    size_t      errors;
    int         has_signal;
    int16_t     weakest_rssi;   /* valid only if has_signal */
    const char *last_error;     /* arena-owned copy, NUL-terminated, or NULL */
    const char *line;           /* arena-owned formatted summary line */
} snapshot_module_t;

/* A temporary diagnostic snapshot of store events [first, last).
 *
 * EVERYTHING reachable from this struct lives in the arena passed to
 * diag_snapshot_build(). It is valid until the next arena_reset() or
 * arena_destroy() and must not be stored in event_store_t or anywhere
 * that outlives the snapshot cycle. The store's own events are not touched. */
typedef struct {
    size_t             first, last;
    snapshot_module_t *modules;       /* arena-owned array, module_count entries */
    size_t             module_count;
    const char       **event_lines;   /* arena-owned array of arena-owned strings */
    size_t             event_count;   /* == last - first */
} snapshot_t;

/* Builds the snapshot. Returns:
 *   GW_OK        *out complete
 *   GW_EINVAL    bad window or NULL argument (*out untouched)
 *   GW_ENOSPACE  arena too small for this window; *out is unusable and
 *                the arena is partially consumed — caller resets it */
gw_status_t diag_snapshot_build(const event_store_t *store, size_t first, size_t last,
                                arena_t *arena, snapshot_t *out);

void diag_snapshot_emit(const snapshot_t *s, FILE *out);

#endif
