#ifndef DIAG_SINK_LIST_H
#define DIAG_SINK_LIST_H
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Registry of diagnostic sinks (Day 2).
 *
 * A sink is a destination for diagnostics (console, log file, ...). Sinks are
 * registered and unregistered at run time by id, so membership is dynamic:
 * a singly linked list where each node is one registration.
 *
 * Today a sink is only a descriptor (id + name). On Day 3 the same list
 * becomes the subscriber set that receives notifications.
 *
 * Ownership: the list owns every node. Names are copied into the node.
 * Order: registration order (append at the tail).
 * Invariants (tested)
 *   count == number of nodes
 *   ids are unique
 *   last node's next == NULL
 *   removing an id that is absent leaves the list unchanged */

#define SINK_NAME_MAX 24

typedef struct diag_sink {
    uint32_t          id;
    char              name[SINK_NAME_MAX];  /* NUL-terminated copy */
    struct diag_sink *next;
} diag_sink_t;

typedef struct {
    diag_sink_t *head;
    size_t       count;
} diag_sink_list_t;

void        diag_sink_list_init(diag_sink_list_t *l);
gw_status_t diag_sink_list_add(diag_sink_list_t *l, uint32_t id, const char *name); /* GW_OK | GW_EEXIST | GW_ENOMEM | GW_EINVAL */
gw_status_t diag_sink_list_remove(diag_sink_list_t *l, uint32_t id);                /* GW_OK | GW_ENOENT */
const diag_sink_t *diag_sink_list_find(const diag_sink_list_t *l, uint32_t id);     /* borrowed; NULL if absent */
size_t      diag_sink_list_count(const diag_sink_list_t *l);
void        diag_sink_list_destroy(diag_sink_list_t *l);                            /* frees all nodes; list reusable */

#endif
