#ifndef DIAG_ENGINE_H
#define DIAG_ENGINE_H
#include "event.h"

#define DIAG_MAX_MODULES 8

/* Diagnostic engine (end of Block 2): prints each event, keeps counters and
 * retains an OWNED copy of the last error event per module. */
void        diag_init(void);
void        diag_on_event(const event_view_t *ev);   /* parse_events callback */
const char *diag_last_error(unsigned module_id);      /* borrowed; NULL if none */
void        diag_report(void);
void        diag_shutdown(void);                      /* releases retained events */

#endif
