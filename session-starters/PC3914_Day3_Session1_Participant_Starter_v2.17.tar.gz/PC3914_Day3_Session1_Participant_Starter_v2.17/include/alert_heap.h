#ifndef ALERT_HEAP_H
#define ALERT_HEAP_H
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Alert priority queue (Day 2 Block 2): "which alert is most urgent next?"
 *
 * The intake queue preserves ARRIVAL order. Alerts must come out in
 * URGENCY order regardless of when they arrived: an array-backed binary
 * max-heap of alert records stored BY VALUE.
 *
 * Order: higher severity first; equal severity -> lower sequence number
 * first (older alert first). The pair (severity, seq) is a total order, so
 * pop order is deterministic.
 *
 * Layout: items[0] is the root. For index i:
 *   parent(i) = (i - 1) / 2      left(i) = 2i + 1      right(i) = 2i + 2
 * Heap invariant (tested): for every i > 0, items[parent(i)] outranks items[i].
 * The array is NOT globally sorted — only the root is guaranteed to be the
 * maximum; siblings and cousins are unordered.
 *
 * Growth doubles the array through a temporary pointer; on failure the heap
 * is unchanged and the push reports GW_ENOMEM. */

typedef struct {
    uint8_t  severity;      /* 3 = critical, 2 = major, 1 = minor */
    uint32_t module_id;
    uint64_t seq;           /* gateway sequence number: arrival order, unique */
    char     code[16];      /* short descriptor, NUL-terminated copy */
} alert_t;

typedef struct {
    alert_t *items;         /* owned array; the heap owns the records (by value) */
    size_t   len;
    size_t   cap;
} alert_heap_t;

void        alert_heap_init(alert_heap_t *h);
gw_status_t alert_heap_push(alert_heap_t *h, const alert_t *a);   /* GW_OK | GW_ENOMEM (heap unchanged) | GW_EINVAL */
int         alert_heap_pop(alert_heap_t *h, alert_t *out);        /* 1 and *out = highest priority; 0 when empty (expected) */
int         alert_heap_peek(const alert_heap_t *h, alert_t *out); /* same, without removing */
size_t      alert_heap_size(const alert_heap_t *h);
void        alert_heap_destroy(alert_heap_t *h);

/* 1 if a outranks b (comes out first). Exposed for tests. */
int         alert_outranks(const alert_t *a, const alert_t *b);

#endif
