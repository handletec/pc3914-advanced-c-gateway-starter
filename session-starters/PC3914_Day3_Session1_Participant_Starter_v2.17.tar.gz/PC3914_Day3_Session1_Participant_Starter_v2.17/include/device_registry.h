#ifndef DEVICE_REGISTRY_H
#define DEVICE_REGISTRY_H
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Device-state registry — PUBLIC INTERFACE (Day 2 Block 3: opaque ADT).
 *
 * "What is the current state of module X?"  Keyed by module_id, values
 * stored by value. Open addressing with linear probing, growth at load 3/4.
 * The representation is private to src/device_registry.c: callers hold a
 * device_registry_t * handle and use only the functions below.
 *
 * Ownership / lifetime contract
 *   create   returns an owned handle; destroy releases it (accepts NULL)
 *   upsert   copies *v into the registry; the caller keeps its copy
 *   find     returns a BORROWED pointer into the registry, valid only until
 *            the next upsert — growth moves every entry. Copy out what you
 *            need before inserting again. Opacity does not change this rule.
 *   for_each calls fn once per entry with a borrowed pointer; fn must not
 *            call upsert or destroy on the same registry
 *
 * Invariants are enforced inside the implementation and checked by
 * tests/test_device_registry.c through this interface only. */

/* Lifecycle state of a module (Day 2 Block 4). The registry STORES it; the
 * rules that change it live in module_state_machine.h — the registry never
 * decides a transition. A module the gateway has never seen starts OFFLINE. */
typedef enum {
    MOD_OFFLINE = 0,
    MOD_CONNECTING,
    MOD_ONLINE,
    MOD_DEGRADED,
    MOD_STATE_COUNT               /* not a state: array bound for tables */
} module_state_t;

typedef struct {
    uint32_t       module_id;
    module_state_t state;
    int16_t        last_rssi;
    size_t         event_count;
} device_state_t;

typedef struct device_registry device_registry_t;   /* opaque: defined in device_registry.c */

typedef void (*device_visit_t)(const device_state_t *v, void *ctx);

device_registry_t    *device_registry_create(size_t initial_capacity);           /* NULL on failure (capacity 0 or no memory) */
gw_status_t           device_registry_upsert(device_registry_t *r, const device_state_t *v); /* GW_OK | GW_ENOMEM (unchanged) */
const device_state_t *device_registry_find(const device_registry_t *r, uint32_t id);        /* NULL if absent (expected) */
size_t                device_registry_count(const device_registry_t *r);
size_t                device_registry_capacity(const device_registry_t *r);
void                  device_registry_for_each(const device_registry_t *r, device_visit_t fn, void *ctx);
void                  device_registry_destroy(device_registry_t *r);

/* Teaching/test aid: the home slot of an id before probing. */
size_t                device_registry_home_slot(const device_registry_t *r, uint32_t id);
const char           *module_state_name(module_state_t s);

#endif
