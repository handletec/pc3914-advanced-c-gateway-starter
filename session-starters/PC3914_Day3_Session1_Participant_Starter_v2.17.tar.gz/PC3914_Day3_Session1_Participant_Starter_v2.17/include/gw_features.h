#ifndef GW_FEATURES_H
#define GW_FEATURES_H

/* Build-time feature flags (Day 2 Block 4).
 *
 * A feature flag answers ONE question: "was this capability compiled into
 * this build?"  It is set on the compiler command line, never edited here:
 *
 *     gcc ... -DGW_ENABLE_TRACE=1 ...      trace compiled in
 *     gcc ...                              trace compiled out (default 0)
 *
 * Rules that keep flags from spreading through the code base:
 *   1. every flag has a default here, so every file sees a defined value
 *   2. a flag's value is checked with #if FLAG, not #ifdef FLAG — a flag
 *      that is defined as 0 must behave as "off"
 *   3. the #if that switches the implementation lives in ONE file
 *      (src/gw_trace.c); application code calls gw_trace() unconditionally
 *   4. a flag never decides per-event or per-device behaviour — that is a
 *      runtime policy (Strategy) or lifecycle behaviour (State) */

#ifndef GW_ENABLE_TRACE
#define GW_ENABLE_TRACE 0
#endif

#if GW_ENABLE_TRACE != 0 && GW_ENABLE_TRACE != 1
#error "GW_ENABLE_TRACE must be 0 or 1"
#endif

/* Object-like constants shared by the classification policies and the
 * lifecycle machine: one definition, one place to change. */
#define GW_WEAK_RSSI_DBM   (-100)   /* at or below: weak signal */
#define GW_POOR_RSSI_DBM   (-90)    /* at or below: poor signal (conservative policy) */

#endif
