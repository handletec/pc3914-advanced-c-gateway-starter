#ifndef ALERT_STRATEGY_H
#define ALERT_STRATEGY_H
#include "alert_heap.h"
#include "event.h"
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Alert classification policy — a Strategy (Day 2 Block 4).
 *
 * "Which policy decides whether this event becomes an alert, and how severe?"
 *
 * The gateway used to answer that with code hard-wired into raise_alert().
 * Now the answer is an OBJECT: a name plus the one operation a policy must
 * provide. The caller holds a pointer to the policy it was given at run time
 * and calls classify through it — the caller never asks which policy it is.
 *
 * Contract for classify():
 *   returns 1  -> *out_alert is fully filled (severity, module_id, seq, code)
 *   returns 0  -> nothing to raise; *out_alert is untouched
 *   never allocates, never touches the heap, never prints
 *
 * The heap (alert_heap_t) is unchanged: a Strategy decides WHAT is raised,
 * the heap decides the ORDER it comes out. */

typedef struct {
    const char *name;                                   /* stable, unique, for selection and reporting */
    int (*classify)(const event_t *event, alert_t *out_alert, uint64_t seq);
} alert_strategy_t;

/* Built-in policies (static storage; pointers stay valid for the program's life). */
const alert_strategy_t *alert_strategy_default(void);             /* "default" */
const alert_strategy_t *alert_strategy_find(const char *name);    /* NULL when unknown or name == NULL */
size_t                  alert_strategy_count(void);
const alert_strategy_t *alert_strategy_at(size_t i);              /* NULL when i >= count */

/* The one entry point callers use. Validates the policy before trusting it:
 *   GW_EINVAL  s, s->classify, e, out or raise is NULL — *out and *raise untouched
 *   GW_OK      *raise = 1 and *out filled, or *raise = 0 and *out untouched */
gw_status_t alert_classify(const alert_strategy_t *s, const event_t *e, uint64_t seq,
                           alert_t *out, int *raise);

#endif
