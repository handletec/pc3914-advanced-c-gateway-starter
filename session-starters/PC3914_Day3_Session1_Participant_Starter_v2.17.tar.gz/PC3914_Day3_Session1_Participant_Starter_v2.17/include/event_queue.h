#ifndef EVENT_QUEUE_H
#define EVENT_QUEUE_H
#include "event.h"
#include "gw_status.h"
#include <stddef.h>

/* FIFO intake queue of OWNED events (Day 2).
 *
 * Arrival order is preserved: the first event pushed is the first popped.
 * Linked nodes: one heap block per queued event, no capacity limit, no
 * copying of events — only the event_t pointer moves.
 *
 * Ownership contract
 *   push, GW_OK      the queue owns `event` until it is popped or destroyed
 *   push, GW_ENOMEM  the queue is unchanged and the CALLER still owns `event`
 *   pop, non-NULL    the caller owns the returned event (event_free it)
 *   pop, NULL        the queue is empty — an expected result, not an error
 *   destroy          frees every event still queued, then the queue
 *
 * Invariants (tested)
 *   size == number of nodes
 *   size == 0  <=>  head == NULL && tail == NULL
 *   size == 1  <=>  head == tail != NULL
 *   tail->next == NULL
 *
 * Single-threaded today. Day 3 wraps these same operations for a worker
 * thread; the contract above is designed not to change. */

typedef struct queue_node {
    event_t           *event;     /* owned while in the queue */
    struct queue_node *next;
} queue_node_t;

typedef struct {
    queue_node_t *head;           /* next to pop (oldest) */
    queue_node_t *tail;           /* last pushed (newest) */
    size_t        size;
} event_queue_t;

event_queue_t *event_queue_create(void);                          /* NULL on allocation failure */
gw_status_t    event_queue_push(event_queue_t *q, event_t *event); /* GW_OK | GW_ENOMEM | GW_EINVAL (NULL event) */
event_t       *event_queue_pop(event_queue_t *q);                 /* NULL when empty */
size_t         event_queue_size(const event_queue_t *q);
int            event_queue_is_empty(const event_queue_t *q);
void           event_queue_destroy(event_queue_t *q);             /* accepts NULL */

#endif
