#ifndef GW_TRACE_H
#define GW_TRACE_H
#include <stdint.h>

/* Diagnostic trace — the ONE boundary behind the GW_ENABLE_TRACE flag.
 *
 * Callers always call gw_trace(); it always links. Whether it prints is
 * decided when src/gw_trace.c is compiled:
 *
 *   -DGW_ENABLE_TRACE=1   prints  "TRACE module=<id> <key>=<value>"  to stdout
 *   default (0)           empty function
 *
 * No #ifdef is needed at any call site. gw_trace_compiled_in() reports which
 * variant this executable contains (for evidence, not for branching). */

void gw_trace(const char *key, uint32_t module_id, const char *value);
int  gw_trace_compiled_in(void);

#endif
