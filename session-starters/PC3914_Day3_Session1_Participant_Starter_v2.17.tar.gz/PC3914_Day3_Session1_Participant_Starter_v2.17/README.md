# PC3914 Day 3 — Session 1 Starter

**Course:** PC3914 — Advanced C Programming: From Basic C to Systems-Ready  
**Session:** 1 — Files, Processes and Pipes

This is the standalone participant entry snapshot for Day 3 Session 1. It contains the completed prerequisite state and the deliberate TODOs for this session. Use this snapshot as the starting workspace for the session practicals.

## Start

```sh
make
make course-status
```

## Current session TODOs

- `TODO-D3.1a`
- `TODO-D3.1b`
- `TODO-D3.2a`
- `TODO-D3.2b`
- `TODO-D3.2c`

Use the practical instructions for the exact edit scope and verification commands. `make checkpoint` saves only your current work under `work/checkpoints/`; it does not restore a known-good state.

Valgrind remains useful where installed. If Valgrind is unavailable, skip that optional check; do not treat a skipped run as a Valgrind PASS.
