/* health_pipe.c — pipe, fork, exec, waitpid (Day 3 Block 1). */
#define _POSIX_C_SOURCE 200809L
#include "health_pipe.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

gw_status_t spawn_reporter(const char *reporter_exe, int *write_fd, pid_t *pid)
{
    int fds[2];
    if (pipe(fds) != 0)
        return GW_EIO;                                  /* errno from pipe() */

    fflush(stdout);                                     /* the child inherits stdio buffers too: empty them first */
    pid_t child = fork();
    if (child < 0) {
        int saved = errno;
        close(fds[0]);
        close(fds[1]);
        errno = saved;
        return GW_EIO;
    }

    if (child == 0) {                                   /* ---- child: continues here with BOTH ends ---- */
        /* TODO-D3.2b: close(fds[1]) — the child must not hold a write end,
         * or it will wait for EOF from itself. */
        if (dup2(fds[0], STDIN_FILENO) < 0)             /* stdin now IS the read end */
            _exit(126);
        /* TODO-D3.2b: close(fds[0]) — after dup2 the original read descriptor is redundant. */
        execl(reporter_exe, "health_reporter", (char *)NULL);   /* replaces this image: no return on success */
        _exit(127);                                     /* only reached when exec failed; _exit: no stdio flush */
    }

    /* ---- parent: continues here with BOTH ends ---- */
    /* TODO-D3.2c: close(fds[0]) — the parent never reads; an open read end is a leak. */
    *write_fd = fds[1];
    *pid = child;
    return GW_OK;
}

gw_status_t finish_reporter(int write_fd, pid_t pid, int *exit_status)
{
    int close_errno = 0;

    if (close(write_fd) != 0)
        close_errno = errno;

    int status;
    for (;;) {
        pid_t r = waitpid(pid, &status, 0);
        if (r == pid)
            break;
        if (r < 0 && errno == EINTR)
            continue;
        return GW_EIO;
    }

    if (exit_status)
        *exit_status = WIFEXITED(status) ? WEXITSTATUS(status) : -1;

    if (close_errno != 0) {
        errno = close_errno;
        return GW_EIO;
    }

    return GW_OK;
}
