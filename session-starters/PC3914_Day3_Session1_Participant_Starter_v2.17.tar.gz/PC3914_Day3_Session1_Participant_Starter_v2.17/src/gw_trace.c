/* gw_trace.c — the only file that tests GW_ENABLE_TRACE (Day 2 Block 4).
 *
 * Two implementations of the same interface; the compiler keeps one. The
 * rest of the gateway is compiled exactly once, the same way, in both
 * builds. Not part of libgateway_core: a feature flag is baked into the
 * object that was compiled with it, and the core archive is built without
 * flags so that one archive serves every application build. */
#include "gw_trace.h"
#include "gw_features.h"
#include <stdio.h>

#if GW_ENABLE_TRACE

void gw_trace(const char *key, uint32_t module_id, const char *value)
{
    printf("TRACE module=%u %s=%s\n", module_id, key, value);
}

int gw_trace_compiled_in(void) { return 1; }

#else

void gw_trace(const char *key, uint32_t module_id, const char *value)
{
    (void)key;                          /* compiled out: the call still exists and still links */
    (void)module_id;
    (void)value;
}

int gw_trace_compiled_in(void) { return 0; }

#endif
