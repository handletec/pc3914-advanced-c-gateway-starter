/* event_queue.c — linked-node FIFO of owned events (Day 2, reference solution). */
#include "event_queue.h"
#include "gw_alloc.h"
#include <assert.h>

event_queue_t *event_queue_create(void)
{
    event_queue_t *q = gw_malloc(sizeof *q);
    if (!q)
        return NULL;
    q->head = NULL;
    q->tail = NULL;
    q->size = 0;
    return q;
}

gw_status_t event_queue_push(event_queue_t *q, event_t *event)
{
    if (!event)
        return GW_EINVAL;

    queue_node_t *n = gw_malloc(sizeof *n);
    if (!n)
        return GW_ENOMEM;                   /* queue unchanged; caller still owns event */
    n->event = event;                       /* ownership transfers here */
    n->next  = NULL;

    if (q->tail)
        q->tail->next = n;                  /* append after the current last node */
    else
        q->head = n;                        /* empty queue: the new node is also the head */
    q->tail = n;
    q->size++;
    return GW_OK;
}

/* D2.1: remove the oldest node, hand its event to the caller, keep the
 * head/tail/size invariants true on every path. */
event_t *event_queue_pop(event_queue_t *q)
{
    if (!q->head)
        return NULL;                        /* empty: expected */

    queue_node_t *n = q->head;
    event_t *e = n->event;                  /* ownership leaves the queue */

    q->head = n->next;
    if (!q->head)
        q->tail = NULL;                     /* that was the last node */
    q->size--;

    gw_free(n);                             /* the node, never the event */
    assert((q->size == 0) == (q->head == NULL && q->tail == NULL));
    return e;
}

size_t event_queue_size(const event_queue_t *q)    { return q->size; }
int    event_queue_is_empty(const event_queue_t *q) { return q->head == NULL; }

void event_queue_destroy(event_queue_t *q)
{
    if (!q)
        return;
    queue_node_t *n = q->head;
    while (n) {
        queue_node_t *next = n->next;       /* read before freeing the node */
        event_free(n->event);               /* still owned by the queue */
        gw_free(n);
        n = next;
    }
    gw_free(q);
}
