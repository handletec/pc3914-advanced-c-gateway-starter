/* health_report.c — the record both processes agree on (Day 3 Block 1, prepared). */
#include "health_report.h"
#include <string.h>

void health_record_init(health_record_t *r, uint64_t processed, uint64_t rejected,
                        uint64_t alerts, uint64_t modules)
{
    memset(r, 0, sizeof *r);                    /* no padding today, but never send uninitialised bytes */
    memcpy(r->magic, HEALTH_MAGIC, 4);
    r->version   = HEALTH_VERSION;
    r->processed = processed;
    r->rejected  = rejected;
    r->alerts    = alerts;
    r->modules   = modules;
}

int health_record_valid(const health_record_t *r, size_t received)
{
    return received == sizeof *r
        && memcmp(r->magic, HEALTH_MAGIC, 4) == 0
        && r->version == HEALTH_VERSION;
}
