/* gw_config.c — key=value configuration through stdio (Day 3 Block 1, prepared).
 *
 * stdio is the right layer here: text, line-oriented, buffered, and the
 * boundary is one fopen(). The descriptor layer (read/write) is for the
 * pipe, where WE decide how many bytes move and when. */
#include "gw_config.h"
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void gw_config_init(gw_config_t *c)
{
    memset(c, 0, sizeof *c);
    strcpy(c->policy, "default");
    c->arena_bytes = 16384;
}

/* Parse a strictly positive decimal size_t; the whole token must be digits. */
static gw_status_t parse_size(const char *tok, size_t *out)
{
    if (*tok == '\0' || *tok == '-' || *tok == '+')
        return GW_EINVAL;
    char *endp;
    errno = 0;                                          /* strtoul boundary: errno tells ERANGE apart */
    unsigned long v = strtoul(tok, &endp, 10);
    if (errno != 0 || *endp != '\0' || v == 0 || v > SIZE_MAX)
        return GW_EINVAL;
    *out = (size_t)v;
    return GW_OK;
}

/* Apply one key/value pair to a scratch copy. */
static gw_status_t apply(gw_config_t *c, const char *key, const char *val)
{
    if (strcmp(key, "policy") == 0) {
        if (*val == '\0')
            return GW_EINVAL;
        if (strlen(val) >= sizeof c->policy)
            return GW_ENOSPACE;                         /* would not fit: refuse, do not truncate */
        strcpy(c->policy, val);                         /* COPY into the struct; never keep `val` */
        return GW_OK;
    }
    if (strcmp(key, "arena_bytes") == 0)
        return parse_size(val, &c->arena_bytes);
    return GW_EINVAL;                                   /* unknown key — including any feature flag */
}

gw_status_t gw_config_load(const char *path, gw_config_t *out, size_t *err_line)
{
    if (err_line)
        *err_line = 0;
    if (!path || !out)
        return GW_EINVAL;

    FILE *f = fopen(path, "r");
    if (!f)
        return errno == ENOENT ? GW_ENOENT : GW_EIO;                               /* errno set by fopen; the caller reports it */

    gw_config_t scratch = *out;                         /* build the result aside; commit only on success */
    char line[GW_CONFIG_LINE_MAX];                      /* local: reused every iteration, dead on return */
    size_t lineno = 0;
    gw_status_t rc = GW_OK;

    while (fgets(line, sizeof line, f)) {
        lineno++;
        size_t n = strlen(line);
        if (n == sizeof line - 1 && line[n - 1] != '\n') {
            rc = GW_ENOSPACE;                           /* line longer than the buffer: boundary, not silent split */
            break;
        }
        if (n && line[n - 1] == '\n')
            line[--n] = '\0';
        if (n == 0 || line[0] == '#')
            continue;
        char *eq = strchr(line, '=');
        if (!eq || eq == line) {
            rc = GW_EINVAL;
            break;
        }
        *eq = '\0';                                     /* key = line, value = eq + 1: both inside `line` */
        if ((rc = apply(&scratch, line, eq + 1)) != GW_OK)
            break;
    }
    if (rc == GW_OK && ferror(f))
        rc = GW_EIO;
    fclose(f);

    if (rc != GW_OK) {
        if (err_line)
            *err_line = lineno;
        return rc;                                      /* *out untouched */
    }
    *out = scratch;
    return GW_OK;
}
