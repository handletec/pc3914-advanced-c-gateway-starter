/* arena.c — minimal bump-pointer arena (Block 3, reference solution). */
#include "arena.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>

gw_status_t arena_init(arena_t *a, size_t capacity)
{
    a->base = NULL;
    a->capacity = 0;
    a->offset = 0;
    if (capacity == 0)
        return GW_EINVAL;
    a->base = gw_malloc(capacity);          /* the ONE backing allocation */
    if (!a->base)
        return GW_ENOMEM;
    a->capacity = capacity;
    return GW_OK;
}

void *arena_alloc(arena_t *a, size_t size)
{
    assert(a->base != NULL);                /* invariant: initialised */
    assert(a->offset <= a->capacity);       /* invariant: never over-committed */
    if (size == 0)
        return NULL;

    /* L3.1a: pad the start up to the next multiple of ARENA_ALIGN.
     * Generic modulo arithmetic: no power-of-two assumption. `offset` itself
     * is the end of used bytes and is not kept aligned. */
    size_t pad = a->offset % ARENA_ALIGN;
    if (pad != 0)
        pad = ARENA_ALIGN - pad;
    if (pad > SIZE_MAX - a->offset)         /* offset + pad must not wrap */
        return NULL;
    size_t start = a->offset + pad;

    /* L3.1b: fit check without forming start + size (which could wrap) */
    if (start > a->capacity || size > a->capacity - start)
        return NULL;                        /* expected failure: caller decides */

    void *p = a->base + start;
    a->offset = start + size;
    return p;
}

void *arena_alloc_array(arena_t *a, size_t count, size_t size)
{
    /* L3.1c: multiplication guard */
    if (size != 0 && count > SIZE_MAX / size)
        return NULL;
    return arena_alloc(a, count * size);
}

void arena_reset(arena_t *a)
{
    assert(a->offset <= a->capacity);
#ifndef NDEBUG
    /* Debug builds poison released bytes so a pointer used after reset
     * reads 0xA5 garbage instead of stale-but-plausible data. */
    if (a->base)
        memset(a->base, 0xA5, a->offset);
#endif
    a->offset = 0;
}

void arena_destroy(arena_t *a)
{
    gw_free(a->base);                       /* gw_free(NULL) is a no-op */
    a->base = NULL;
    a->capacity = 0;
    a->offset = 0;
}

size_t arena_used(const arena_t *a)      { return a->offset; }
size_t arena_remaining(const arena_t *a) { return a->capacity - a->offset; }
