/* device_registry.c — IMPLEMENTATION (Day 2 Block 3, reference).
 * The representation lives here and nowhere else. */
#include "device_registry.h"
#include "gw_alloc.h"
#include <stdint.h>
#include <string.h>

/* ---- private representation ------------------------------------------- */

typedef struct {
    int            used;          /* 0 = EMPTY, 1 = holds a value */
    device_state_t value;
} registry_slot_t;

struct device_registry {          /* completes the opaque type from the header */
    registry_slot_t *slots;       /* owned array, capacity entries */
    size_t           capacity;
    size_t           count;
};

/* ---- private helpers ---------------------------------------------------- */

static size_t hash_id(uint32_t id)
{
    return (size_t)(id * 2654435761u);
}

size_t device_registry_home_slot(const device_registry_t *r, uint32_t id)
{
    return hash_id(id) % r->capacity;
}

const char *module_state_name(module_state_t s)
{
    switch (s) {
    case MOD_OFFLINE:      return "OFFLINE";
    case MOD_CONNECTING:   return "CONNECTING";
    case MOD_ONLINE:       return "ONLINE";
    case MOD_DEGRADED:     return "DEGRADED";
    case MOD_STATE_COUNT:  break;
    }
    return "?";
}

/* Linear probing: slot holding id, or the first EMPTY slot on id's probe sequence. */
static size_t find_slot(const device_registry_t *r, uint32_t id)
{
    size_t i = device_registry_home_slot(r, id);
    for (size_t probes = 0; probes < r->capacity; probes++) {
        const registry_slot_t *s = &r->slots[i];
        if (!s->used || s->value.module_id == id)
            return i;
        i = (i + 1) % r->capacity;
    }
    return r->capacity;
}

static gw_status_t grow(device_registry_t *r)
{
    if (r->capacity > SIZE_MAX / 2)
        return GW_ENOMEM;
    size_t new_cap = r->capacity * 2;
    if (new_cap > SIZE_MAX / sizeof *r->slots)
        return GW_ENOMEM;
    registry_slot_t *new_slots = gw_calloc(new_cap, sizeof *new_slots);
    if (!new_slots)
        return GW_ENOMEM;

    device_registry_t fresh = { new_slots, new_cap, 0 };
    for (size_t i = 0; i < r->capacity; i++) {
        if (!r->slots[i].used)
            continue;
        size_t j = find_slot(&fresh, r->slots[i].value.module_id);
        fresh.slots[j].used  = 1;
        fresh.slots[j].value = r->slots[i].value;
        fresh.count++;
    }
    gw_free(r->slots);
    *r = fresh;
    return GW_OK;
}

/* ---- public operations -------------------------------------------------- */

device_registry_t *device_registry_create(size_t initial_capacity)
{
    if (initial_capacity == 0)
        return NULL;
    device_registry_t *r = gw_malloc(sizeof *r);
    if (!r)
        return NULL;
    r->slots = gw_calloc(initial_capacity, sizeof *r->slots);
    if (!r->slots) {
        gw_free(r);                                     /* unwind */
        return NULL;
    }
    r->capacity = initial_capacity;
    r->count = 0;
    return r;
}

gw_status_t device_registry_upsert(device_registry_t *r, const device_state_t *v)
{
    size_t i = find_slot(r, v->module_id);
    if (i < r->capacity && r->slots[i].used) {
        r->slots[i].value = *v;
        return GW_OK;
    }
    if ((r->count + 1) * 4 > r->capacity * 3) {
        gw_status_t st = grow(r);
        if (st != GW_OK)
            return st;
        i = find_slot(r, v->module_id);
    }
    r->slots[i].used  = 1;
    r->slots[i].value = *v;
    r->count++;
    return GW_OK;
}

const device_state_t *device_registry_find(const device_registry_t *r, uint32_t id)
{
    size_t i = find_slot(r, id);
    if (i < r->capacity && r->slots[i].used)
        return &r->slots[i].value;
    return NULL;
}

size_t device_registry_count(const device_registry_t *r)    { return r->count; }
size_t device_registry_capacity(const device_registry_t *r) { return r->capacity; }

void device_registry_for_each(const device_registry_t *r, device_visit_t fn, void *ctx)
{
    for (size_t i = 0; i < r->capacity; i++)
        if (r->slots[i].used)
            fn(&r->slots[i].value, ctx);
}

void device_registry_destroy(device_registry_t *r)
{
    if (!r)
        return;
    gw_free(r->slots);
    gw_free(r);
}
