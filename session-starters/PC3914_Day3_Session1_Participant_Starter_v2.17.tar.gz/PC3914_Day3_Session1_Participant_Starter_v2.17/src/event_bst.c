/* event_bst.c — naive binary search tree keyed by sequence number (Day 2 Block 2, prepared). */
#include "event_bst.h"
#include "gw_alloc.h"
#include <stdint.h>

/* ---- a small node-pointer stack for iterative traversal ---------------- */
/* Type-specific on purpose: work_stack_t holds const event_t *, not nodes. */
typedef struct {
    bst_node_t **items;
    size_t       len, cap;
} node_stack_t;

static gw_status_t node_stack_push(node_stack_t *s, bst_node_t *n)
{
    if (s->len == s->cap) {
        if (s->cap > SIZE_MAX / 2)
            return GW_ENOMEM;
        size_t new_cap = s->cap ? s->cap * 2 : 16;
        if (new_cap > SIZE_MAX / sizeof *s->items)
            return GW_ENOMEM;
        bst_node_t **tmp = gw_realloc(s->items, new_cap * sizeof *tmp);
        if (!tmp)
            return GW_ENOMEM;
        s->items = tmp;
        s->cap   = new_cap;
    }
    s->items[s->len++] = n;
    return GW_OK;
}

static bst_node_t *node_stack_pop(node_stack_t *s)
{
    return s->len ? s->items[--s->len] : NULL;
}

/* ---- tree --------------------------------------------------------------- */

void event_bst_init(event_bst_t *t)
{
    t->root  = NULL;
    t->count = 0;
}

/* Iterative insert: walk down holding the ADDRESS of the link to fill —
 * the same pointer-to-pointer idea as the registry list, in two directions. */
gw_status_t event_bst_insert(event_bst_t *t, uint64_t key, const event_t *value)
{
    if (!value)
        return GW_EINVAL;
    bst_node_t **link = &t->root;
    while (*link) {
        if (key == (*link)->key)
            return GW_EEXIST;                   /* duplicate policy: refuse, change nothing */
        link = key < (*link)->key ? &(*link)->left : &(*link)->right;
    }
    bst_node_t *n = gw_malloc(sizeof *n);
    if (!n)
        return GW_ENOMEM;
    n->key = key;
    n->value = value;
    n->left = n->right = NULL;
    *link = n;                                  /* fill the empty link we stopped at */
    t->count++;
    return GW_OK;
}

const event_t *event_bst_search(const event_bst_t *t, uint64_t key)
{
    const bst_node_t *n = t->root;
    while (n) {
        if (key == n->key)
            return n->value;
        n = key < n->key ? n->left : n->right;
    }
    return NULL;                                /* absent: expected */
}

/* In-order with an explicit stack: go left as far as possible, visit, then
 * step into the right subtree. Ascending keys. */
gw_status_t event_bst_inorder(const event_bst_t *t, bst_visit_t visit, void *ctx)
{
    node_stack_t st = { NULL, 0, 0 };
    bst_node_t *cur = t->root;
    gw_status_t rc = GW_OK;
    while (cur || st.len) {
        while (cur) {
            if ((rc = node_stack_push(&st, cur)) != GW_OK)
                goto done;
            cur = cur->left;
        }
        cur = node_stack_pop(&st);
        visit(cur->key, cur->value, ctx);
        cur = cur->right;
    }
done:
    gw_free(st.items);
    return rc;
}

/* Height = nodes on the longest root-to-leaf path, measured with an explicit
 * stack of nodes and a parallel array of depths (no recursion: on the
 * degenerate chain the depth equals the size). */
size_t event_bst_height(const event_bst_t *t)
{
    if (!t->root)
        return 0;
    node_stack_t st = { NULL, 0, 0 };
    size_t *depths = NULL, dcap = 0, dlen = 0, best = 0;

    if (node_stack_push(&st, t->root) != GW_OK)
        goto out;
    depths = gw_malloc(16 * sizeof *depths);
    if (!depths)
        goto out;
    dcap = 16;
    depths[dlen++] = 1;

    while (st.len) {
        bst_node_t *n = node_stack_pop(&st);
        size_t d = depths[--dlen];
        if (d > best)
            best = d;
        bst_node_t *kids[2] = { n->left, n->right };
        for (int k = 0; k < 2; k++) {
            if (!kids[k])
                continue;
            if (node_stack_push(&st, kids[k]) != GW_OK)
                goto out;
            if (dlen == dcap) {
                if (dcap > SIZE_MAX / 2 / sizeof *depths)
                    goto out;
                size_t *tmp = gw_realloc(depths, dcap * 2 * sizeof *tmp);
                if (!tmp)
                    goto out;
                depths = tmp;
                dcap *= 2;
            }
            depths[dlen++] = d + 1;
        }
    }
out:
    gw_free(depths);
    gw_free(st.items);
    return best;
}

size_t event_bst_count(const event_bst_t *t) { return t->count; }

/* Destroy: pop a node, push its children, free it. Order does not matter. */
void event_bst_destroy(event_bst_t *t)
{
    node_stack_t st = { NULL, 0, 0 };
    if (t->root && node_stack_push(&st, t->root) != GW_OK)
        return;                                 /* cannot allocate a 16-entry stack: leave the tree intact */
    while (st.len) {
        bst_node_t *n = node_stack_pop(&st);
        if (n->left  && node_stack_push(&st, n->left)  != GW_OK) break;
        if (n->right && node_stack_push(&st, n->right) != GW_OK) break;
        gw_free(n);
    }
    gw_free(st.items);
    t->root  = NULL;
    t->count = 0;
}
