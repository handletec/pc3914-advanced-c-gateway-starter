/* diag_snapshot.c — temporary diagnostic snapshot built entirely in an arena
 * (Block 3, reference solution). No heap allocation happens in this file. */
#include "diag_snapshot.h"
#include "diag_engine.h"          /* DIAG_MAX_MODULES */
#include <stdint.h>
#include <string.h>

/* L3.2a: copies len bytes into the arena as a NUL-terminated string.
 * NULL when the arena cannot hold len + 1 bytes. */
static char *snapshot_strdup(arena_t *a, const char *src, size_t len)
{
    if (len == SIZE_MAX)                    /* len + 1 would wrap */
        return NULL;
    char *d = arena_alloc(a, len + 1);
    if (!d)
        return NULL;                        /* expected: arena exhausted for this cycle */
    memcpy(d, src, len);
    d[len] = '\0';
    return d;
}

/* Formats into a bounded local buffer, then copies into the arena. */
static const char *format_module_line(arena_t *a, const snapshot_module_t *m)
{
    char tmp[160];
    int n;
    if (m->has_signal)
        n = snprintf(tmp, sizeof tmp, "module %u | events %zu | errors %zu | weakest %d dBm | last error %s",
                     m->module_id, m->events, m->errors, m->weakest_rssi,
                     m->last_error ? m->last_error : "-");
    else
        n = snprintf(tmp, sizeof tmp, "module %u | events %zu | errors %zu | no signal report | last error %s",
                     m->module_id, m->events, m->errors,
                     m->last_error ? m->last_error : "-");
    if (n < 0)
        return NULL;
    size_t len = (size_t)n < sizeof tmp ? (size_t)n : sizeof tmp - 1;   /* truncated is still valid text */
    return snapshot_strdup(a, tmp, len);
}

static const char *format_event_line(arena_t *a, size_t index, const event_t *e)
{
    char tmp[128];
    int n = snprintf(tmp, sizeof tmp, "#%zu module %u %s %d dBm %s",
                     index, e->module_id, event_kind_name(e->kind), e->rssi_dbm, e->payload);
    if (n < 0)
        return NULL;
    size_t len = (size_t)n < sizeof tmp ? (size_t)n : sizeof tmp - 1;
    return snapshot_strdup(a, tmp, len);
}

gw_status_t diag_snapshot_build(const event_store_t *store, size_t first, size_t last,
                                arena_t *arena, snapshot_t *out)
{
    if (!store || !arena || !out || first > last || last > event_store_len(store))
        return GW_EINVAL;

    /* Pass 1: aggregate per module into a fixed local table. No allocation. */
    snapshot_module_t table[DIAG_MAX_MODULES];
    const event_t    *last_err[DIAG_MAX_MODULES];
    int               present[DIAG_MAX_MODULES];
    memset(table, 0, sizeof table);
    memset(present, 0, sizeof present);
    for (unsigned i = 0; i < DIAG_MAX_MODULES; i++)
        last_err[i] = NULL;

    size_t distinct = 0;
    for (size_t i = first; i < last; i++) {
        const event_t *e = event_store_get(store, i);
        uint32_t id = e->module_id;
        if (id >= DIAG_MAX_MODULES)
            continue;
        if (!present[id]) {
            present[id] = 1;
            table[id].module_id = id;
            distinct++;
        }
        table[id].events++;
        if (e->kind == EV_ERROR) {
            table[id].errors++;
            last_err[id] = e;               /* borrowed from the store during the build only */
        }
        if (e->kind == EV_SIGNAL && (!table[id].has_signal || e->rssi_dbm < table[id].weakest_rssi)) {
            table[id].has_signal   = 1;
            table[id].weakest_rssi = e->rssi_dbm;
        }
    }

    /* L3.2b: move the per-module results into the arena. Every string the
     * snapshot refers to is COPIED into the arena — nothing points into the
     * store once this function returns. */
    snapshot_module_t *modules = arena_alloc_array(arena, distinct ? distinct : 1, sizeof *modules);
    if (!modules)
        return GW_ENOSPACE;
    size_t k = 0;
    for (unsigned id = 0; id < DIAG_MAX_MODULES; id++) {
        if (!present[id])
            continue;
        modules[k] = table[id];
        modules[k].last_error = NULL;
        if (last_err[id]) {
            modules[k].last_error = snapshot_strdup(arena, last_err[id]->payload, last_err[id]->payload_len);
            if (!modules[k].last_error)
                return GW_ENOSPACE;
        }
        modules[k].line = format_module_line(arena, &modules[k]);
        if (!modules[k].line)
            return GW_ENOSPACE;
        k++;
    }

    /* Event detail lines, one per event in the window. */
    size_t count = last - first;
    const char **lines = arena_alloc_array(arena, count ? count : 1, sizeof *lines);
    if (!lines)
        return GW_ENOSPACE;
    for (size_t i = first; i < last; i++) {
        lines[i - first] = format_event_line(arena, i, event_store_get(store, i));
        if (!lines[i - first])
            return GW_ENOSPACE;
    }

    out->first        = first;
    out->last         = last;
    out->modules      = modules;
    out->module_count = k;
    out->event_lines  = lines;
    out->event_count  = count;
    return GW_OK;
}

void diag_snapshot_emit(const snapshot_t *s, FILE *out)
{
    fprintf(out, "=== snapshot: events %zu..%zu (%zu modules) ===\n",
            s->first, s->last, s->module_count);
    for (size_t i = 0; i < s->module_count; i++)
        fprintf(out, "  %s\n", s->modules[i].line);
    fprintf(out, "  --- %zu events ---\n", s->event_count);
    for (size_t i = 0; i < s->event_count; i++)
        fprintf(out, "  %s\n", s->event_lines[i]);
}
