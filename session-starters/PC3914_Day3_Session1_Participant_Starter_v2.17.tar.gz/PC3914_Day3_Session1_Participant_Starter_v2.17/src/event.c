#include "event.h"
#include "gw_alloc.h"
#include <string.h>

static const char *const kind_names[EV_KIND_COUNT] = {
    [EV_CONNECT]    = "CONNECT",
    [EV_DISCONNECT] = "DISCONNECT",
    [EV_SIGNAL]     = "SIGNAL",
    [EV_ERROR]      = "ERROR",
};

const char *event_kind_name(event_kind_t k)
{
    return (k >= 0 && k < EV_KIND_COUNT) ? kind_names[k] : "?";
}

event_t *event_clone(const event_view_t *v)
{
    event_t *e = gw_malloc(sizeof *e);
    if (!e)
        return NULL;

    e->payload = gw_malloc(v->payload_len + 1);
    if (!e->payload) {
        gw_free(e);                 /* unwind the first allocation */
        return NULL;
    }
    memcpy(e->payload, v->payload, v->payload_len);
    e->payload[v->payload_len] = '\0';

    e->payload_len = v->payload_len;
    e->module_id   = v->module_id;
    e->kind        = v->kind;
    e->rssi_dbm    = v->rssi_dbm;
    return e;
}

void event_free(event_t *e)
{
    if (!e)
        return;
    gw_free(e->payload);
    gw_free(e);
}
