/* health_reporter.c — the child process (Day 3 Block 1, prepared).
 *
 * Reads ONE health record from standard input (the pipe's read end after the
 * gateway's dup2), prints a one-line summary, and exits:
 *   0  complete, well-formed record
 *   2  EOF before any byte arrived
 *   3  short or malformed record
 * It never assumes one read() returns the whole record, and it knows the
 * record is complete only when it sees EOF — which needs every write end closed. */
#define _POSIX_C_SOURCE 200809L
#include "health_report.h"
#include "gw_io.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void)
{
    /* The record ends when the writer closes: read until EOF, allowing one
     * extra byte so that "more than a record" is detected, not truncated. */
    unsigned char buf[sizeof(health_record_t) + 1];
    size_t got = 0;
    if (read_full(STDIN_FILENO, buf, sizeof buf, &got) != GW_OK) {
        fprintf(stderr, "health_reporter: read: %s\n", strerror(errno));
        return 3;
    }
    if (got == 0) {
        fprintf(stderr, "health_reporter: EOF with no record\n");
        return 2;
    }
    health_record_t r;
    memcpy(&r, buf, sizeof r);
    if (!health_record_valid(&r, got)) {
        fprintf(stderr, "health_reporter: bad record (%zu bytes, expected %zu)\n", got, sizeof r);
        return 3;
    }
    printf("health_reporter (pid %ld): %llu events processed, %llu lifecycle rejected, "
           "%llu alerts, %llu modules tracked  [%zu bytes, %zu short reads]\n",
           (long)getpid(), (unsigned long long)r.processed, (unsigned long long)r.rejected,
           (unsigned long long)r.alerts, (unsigned long long)r.modules, got, gw_io_stats.short_reads);
    return 0;
}
