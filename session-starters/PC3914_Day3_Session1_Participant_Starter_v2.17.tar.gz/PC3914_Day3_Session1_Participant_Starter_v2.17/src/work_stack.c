/* work_stack.c — growable-array LIFO of borrowed event pointers (Day 2, prepared). */
#include "work_stack.h"
#include "gw_alloc.h"
#include <stdint.h>

void work_stack_init(work_stack_t *s)
{
    s->items = NULL;
    s->len = 0;
    s->cap = 0;
}

gw_status_t work_stack_push(work_stack_t *s, const event_t *e)
{
    if (!e)
        return GW_EINVAL;                               /* NULL is the "empty" pop result; never store it */
    if (s->len == s->cap) {
        if (s->cap > SIZE_MAX / 2)
            return GW_ENOMEM;                           /* doubling itself would wrap */
        size_t new_cap = s->cap ? s->cap * 2 : 8;
        if (new_cap > SIZE_MAX / sizeof *s->items)
            return GW_ENOMEM;                           /* byte count would wrap */
        const event_t **tmp = gw_realloc(s->items, new_cap * sizeof *tmp);
        if (!tmp)
            return GW_ENOMEM;                           /* stack unchanged (Day 1 realloc rule) */
        s->items = tmp;
        s->cap   = new_cap;
    }
    s->items[s->len++] = e;                             /* top is items[len - 1] */
    return GW_OK;
}

const event_t *work_stack_pop(work_stack_t *s)
{
    if (s->len == 0)
        return NULL;                                    /* empty: expected */
    return s->items[--s->len];                          /* last in, first out */
}

int    work_stack_is_empty(const work_stack_t *s) { return s->len == 0; }
size_t work_stack_size(const work_stack_t *s)     { return s->len; }

void work_stack_destroy(work_stack_t *s)
{
    gw_free(s->items);                                  /* the array; never the events */
    s->items = NULL;
    s->len = 0;
    s->cap = 0;
}
