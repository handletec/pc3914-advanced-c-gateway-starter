/* module_state_machine.c — module lifecycle rules (Day 2 Block 4, reference).
 *
 * Part of libgateway_core: the rules are data (one table) plus one lookup.
 * Adding a state or an input means adding a row or a column — never a new
 * branch in the gateway. */
#include "module_state_machine.h"
#include "gw_features.h"

/* Marks a (state, input) pair the lifecycle does not accept. */
#define SM_X  MOD_STATE_COUNT

/* The lifecycle, as data. Row = current state, column = input class.
 * A cell equal to its own row is a defined no-op (SM_STAY).
 * D2.8b: every cell is a state or SM_X — each one decided, none invented. */
static const module_state_t next_state[MOD_STATE_COUNT][SM_INPUT_COUNT] = {
    /*                     CONNECT          DISCONNECT    SIGNAL_GOOD   SIGNAL_WEAK    ERROR          */
    [MOD_OFFLINE]    = { MOD_CONNECTING,  MOD_OFFLINE,  SM_X,         SM_X,          MOD_OFFLINE    },
    [MOD_CONNECTING] = { MOD_CONNECTING,  MOD_OFFLINE,  MOD_ONLINE,   MOD_DEGRADED,  MOD_CONNECTING },
    [MOD_ONLINE]     = { SM_X,            MOD_OFFLINE,  MOD_ONLINE,   MOD_DEGRADED,  MOD_ONLINE     },  /* D2.8b */
    [MOD_DEGRADED]   = { SM_X,            MOD_OFFLINE,  MOD_ONLINE,   MOD_DEGRADED,  MOD_DEGRADED   },  /* D2.8b */
};

sm_input_t module_sm_classify(const event_t *e)
{
    switch (e->kind) {
    case EV_CONNECT:    return SM_IN_CONNECT;
    case EV_DISCONNECT: return SM_IN_DISCONNECT;
    case EV_SIGNAL:     return e->rssi_dbm <= GW_WEAK_RSSI_DBM ? SM_IN_SIGNAL_WEAK : SM_IN_SIGNAL_GOOD;
    case EV_ERROR:      return SM_IN_ERROR;
    case EV_KIND_COUNT: break;
    }
    return SM_INPUT_COUNT;                      /* unknown kind: rejected by module_sm_next */
}

/* D2.8a: look the pair up in next_state.
 *   - cur or in out of range          -> SM_REJECTED, *next untouched
 *   - cell is SM_X                    -> SM_REJECTED, *next untouched
 *   - cell equals cur                 -> SM_STAY,       *next = cur
 *   - otherwise                       -> SM_TRANSITION, *next = cell */
sm_outcome_t module_sm_next(module_state_t cur, sm_input_t in, module_state_t *next)
{
    if ((unsigned)cur >= MOD_STATE_COUNT || (unsigned)in >= SM_INPUT_COUNT)
        return SM_REJECTED;                     /* D2.8a: never index the table with a bad value */
    module_state_t cell = next_state[cur][in];
    if (cell == SM_X)
        return SM_REJECTED;                     /* not valid here: *next untouched */
    *next = cell;
    return cell == cur ? SM_STAY : SM_TRANSITION;
}

sm_outcome_t module_sm_step(module_state_t *state, const event_t *e)
{
    module_state_t next;
    sm_outcome_t o = module_sm_next(*state, module_sm_classify(e), &next);
    if (o == SM_TRANSITION)
        *state = next;                          /* SM_STAY / SM_REJECTED leave *state alone */
    return o;
}

const char *module_sm_input_name(sm_input_t in)
{
    switch (in) {
    case SM_IN_CONNECT:     return "CONNECT";
    case SM_IN_DISCONNECT:  return "DISCONNECT";
    case SM_IN_SIGNAL_GOOD: return "SIGNAL_GOOD";
    case SM_IN_SIGNAL_WEAK: return "SIGNAL_WEAK";
    case SM_IN_ERROR:       return "ERROR";
    case SM_INPUT_COUNT:    break;
    }
    return "?";
}

const char *module_sm_outcome_name(sm_outcome_t o)
{
    switch (o) {
    case SM_TRANSITION: return "transition";
    case SM_STAY:       return "stay";
    case SM_REJECTED:   return "rejected";
    }
    return "?";
}
