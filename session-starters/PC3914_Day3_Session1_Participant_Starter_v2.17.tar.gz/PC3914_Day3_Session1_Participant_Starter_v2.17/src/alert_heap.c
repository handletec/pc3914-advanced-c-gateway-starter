/* alert_heap.c — array-backed binary max-heap of alert records (Day 2 Block 2, reference). */
#include "alert_heap.h"
#include "gw_alloc.h"
#include <stdint.h>
#include <string.h>

int alert_outranks(const alert_t *a, const alert_t *b)
{
    if (a->severity != b->severity)
        return a->severity > b->severity;   /* more severe first */
    return a->seq < b->seq;                 /* same severity: older first (deterministic) */
}

void alert_heap_init(alert_heap_t *h)
{
    h->items = NULL;
    h->len = 0;
    h->cap = 0;
}

static void swap(alert_t *x, alert_t *y)
{
    alert_t t = *x;
    *x = *y;
    *y = t;
}

/* Move items[i] up while it outranks its parent. */
static void sift_up(alert_heap_t *h, size_t i)
{
    while (i > 0) {
        size_t parent = (i - 1) / 2;
        if (!alert_outranks(&h->items[i], &h->items[parent]))
            break;                          /* parent outranks (or equal-order): invariant holds */
        swap(&h->items[i], &h->items[parent]);
        i = parent;
    }
}

/* D2.5: move items[i] down while a child outranks it, always swapping with
 * the child that outranks the other, so the subtree root is the maximum. */
static void sift_down(alert_heap_t *h, size_t i)
{
    for (;;) {
        size_t left  = 2 * i + 1;
        size_t right = 2 * i + 2;
        size_t best  = i;
        if (left  < h->len && alert_outranks(&h->items[left],  &h->items[best]))
            best = left;
        if (right < h->len && alert_outranks(&h->items[right], &h->items[best]))
            best = right;
        if (best == i)
            return;                         /* neither child outranks: invariant holds here */
        swap(&h->items[i], &h->items[best]);
        i = best;
    }
}

gw_status_t alert_heap_push(alert_heap_t *h, const alert_t *a)
{
    if (!a || a->severity == 0)
        return GW_EINVAL;
    if (h->len == h->cap) {
        if (h->cap > SIZE_MAX / 2)
            return GW_ENOMEM;
        size_t new_cap = h->cap ? h->cap * 2 : 8;
        if (new_cap > SIZE_MAX / sizeof *h->items)
            return GW_ENOMEM;
        alert_t *tmp = gw_realloc(h->items, new_cap * sizeof *tmp);
        if (!tmp)
            return GW_ENOMEM;               /* heap unchanged */
        h->items = tmp;
        h->cap   = new_cap;
    }
    h->items[h->len] = *a;                  /* append at the end ... */
    h->items[h->len].code[sizeof a->code - 1] = '\0';
    sift_up(h, h->len);                     /* ... and restore the invariant upwards */
    h->len++;
    return GW_OK;
}

int alert_heap_peek(const alert_heap_t *h, alert_t *out)
{
    if (h->len == 0)
        return 0;
    *out = h->items[0];
    return 1;
}

int alert_heap_pop(alert_heap_t *h, alert_t *out)
{
    if (h->len == 0)
        return 0;                           /* empty: expected */
    *out = h->items[0];                     /* the root is the maximum */
    h->len--;
    if (h->len > 0) {
        h->items[0] = h->items[h->len];     /* last leaf becomes the root ... */
        sift_down(h, 0);                    /* ... and sinks to where it belongs */
    }
    return 1;
}

size_t alert_heap_size(const alert_heap_t *h) { return h->len; }

void alert_heap_destroy(alert_heap_t *h)
{
    gw_free(h->items);
    h->items = NULL;
    h->len = 0;
    h->cap = 0;
}
