/* alert_strategy.c — alert classification policies (Day 2 Block 4, reference).
 *
 * Part of libgateway_core: pure rules from event to alert record, no I/O,
 * no allocation, no knowledge of the CLI. Which policy a PROCESS runs with
 * is decided in gateway.c, not here. */
#include "alert_strategy.h"
#include "gw_features.h"
#include <string.h>

/* Every policy builds the record the same way: all four fields, code bounded. */
static void fill_alert(alert_t *out, const event_t *e, uint64_t seq, uint8_t severity)
{
    out->severity  = severity;
    out->module_id = e->module_id;
    out->seq       = seq;
    memset(out->code, 0, sizeof out->code);
    strncpy(out->code, e->payload, sizeof out->code - 1);
}

/* "default" — the field policy the gateway has used since Block 2:
 *   ERROR SIM_NOT_READY  -> 3
 *   other ERROR          -> 2
 *   SIGNAL <= -100 dBm   -> 1
 *   anything else        -> no alert */
static int classify_default(const event_t *e, alert_t *out, uint64_t seq)
{
    if (e->kind == EV_ERROR) {
        fill_alert(out, e, seq, strcmp(e->payload, "SIM_NOT_READY") == 0 ? 3 : 2);
        return 1;
    }
    if (e->kind == EV_SIGNAL && e->rssi_dbm <= GW_WEAK_RSSI_DBM) {
        fill_alert(out, e, seq, 1);
        return 1;
    }
    return 0;
}

/* "conservative" — raise earlier and higher (TODO-D2.7):
 *   any ERROR            -> 3
 *   SIGNAL <= -100 dBm   -> 2
 *   SIGNAL <= -90 dBm    -> 1
 *   anything else        -> no alert
 * Use fill_alert() and the GW_*_RSSI_DBM constants; do not touch the heap. */
static int classify_conservative(const event_t *e, alert_t *out, uint64_t seq)
{
    if (e->kind == EV_ERROR) {                  /* D2.7: every error is critical here */
        fill_alert(out, e, seq, 3);
        return 1;
    }
    if (e->kind == EV_SIGNAL && e->rssi_dbm <= GW_WEAK_RSSI_DBM) {
        fill_alert(out, e, seq, 2);
        return 1;
    }
    if (e->kind == EV_SIGNAL && e->rssi_dbm <= GW_POOR_RSSI_DBM) {
        fill_alert(out, e, seq, 1);
        return 1;
    }
    return 0;
}

/* The policy table: adding a policy is adding a row. Nothing else changes. */
static const alert_strategy_t policies[] = {
    { "default",      classify_default },
    { "conservative", classify_conservative },
};

const alert_strategy_t *alert_strategy_default(void) { return &policies[0]; }

size_t alert_strategy_count(void) { return sizeof policies / sizeof policies[0]; }

const alert_strategy_t *alert_strategy_at(size_t i)
{
    return i < alert_strategy_count() ? &policies[i] : NULL;
}

const alert_strategy_t *alert_strategy_find(const char *name)
{
    if (!name)
        return NULL;
    for (size_t i = 0; i < alert_strategy_count(); i++)
        if (strcmp(policies[i].name, name) == 0)
            return &policies[i];
    return NULL;                                /* unknown: expected, the caller decides */
}

gw_status_t alert_classify(const alert_strategy_t *s, const event_t *e, uint64_t seq,
                           alert_t *out, int *raise)
{
    if (!s || !s->classify || !e || !out || !raise)
        return GW_EINVAL;                       /* an invalid policy raises nothing */
    *raise = s->classify(e, out, seq);          /* the only place the pointer is called */
    return GW_OK;
}
