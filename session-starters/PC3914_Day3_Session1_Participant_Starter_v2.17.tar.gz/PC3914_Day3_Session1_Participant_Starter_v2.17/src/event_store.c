/* event_store.c — Lab L1 solution */
#include "event_store.h"
#include "gw_alloc.h"
#include <stdint.h>

/* TODO-L1.1: every allocation checked; partial construction unwound */
event_store_t *event_store_create(size_t initial_cap)
{
    event_store_t *s = gw_malloc(sizeof *s);
    if (!s)
        goto fail;

    s->items = gw_calloc(initial_cap, sizeof *s->items);
    if (!s->items)
        goto fail_items;

    s->cap = initial_cap;
    s->len = 0;
    return s;

fail_items:
    gw_free(s);
fail:
    return NULL;
}

/* TODO-L1.2: grow through a temporary; store unchanged on failure */
int event_store_push(event_store_t *s, event_t *e)
{
    if (s->len == s->cap) {
        size_t new_cap = s->cap ? s->cap * 2 : 8;
        if (new_cap > SIZE_MAX / sizeof *s->items)
            return -1;                                  /* size arithmetic overflow */

        event_t **tmp = gw_realloc(s->items, new_cap * sizeof *tmp);
        if (!tmp)
            return -1;                                  /* s->items still valid; caller keeps e */
        s->items = tmp;
        s->cap   = new_cap;
    }
    s->items[s->len++] = e;                             /* ownership transferred */
    return 0;
}

const event_t *event_store_get(const event_store_t *s, size_t i)
{
    return i < s->len ? s->items[i] : NULL;
}

size_t event_store_len(const event_store_t *s) { return s->len; }

/* TODO-L1.3: children first, container last, NULL-safe */
void event_store_destroy(event_store_t *s)
{
    if (!s)
        return;
    for (size_t i = 0; i < s->len; i++)
        event_free(s->items[i]);
    gw_free(s->items);
    gw_free(s);
}
