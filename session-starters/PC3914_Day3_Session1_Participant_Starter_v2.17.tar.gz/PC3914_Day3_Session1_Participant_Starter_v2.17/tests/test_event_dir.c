/* test_event_dir.c — the filter, the bounded join, and the real fixture directory. */
#include "event_dir.h"
#include "gw_alloc.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

static void test_accept(void)
{
    assert(event_dir_accept("alpha.txt") == 1 && "TODO-D3.1a: alpha.txt is an event input");
    assert(event_dir_accept("burst_events.txt") == 1);
    assert(event_dir_accept(".") == 0 && "D3.1a: dot entries are skipped");
    assert(event_dir_accept("..") == 0);
    assert(event_dir_accept(".stale.txt") == 0 && "D3.1a: dot-files are skipped even with .txt");
    assert(event_dir_accept("notes.md") == 0 && "D3.1a: only .txt");
    assert(event_dir_accept("README") == 0);
    assert(event_dir_accept("events.txt.bak") == 0 && "D3.1a: .txt must be the suffix");
    assert(event_dir_accept(".txt") == 0 && "D3.1a: a bare .txt has no name");
    assert(event_dir_accept("txt") == 0);
    printf("[accept]    OK\n");
}

static void test_join(void)
{
    char out[32];
    memset(out, 'X', sizeof out);
    assert(event_dir_join(out, sizeof out, "data/events", "alpha.txt") == GW_OK && "D3.1b: join dir and name");
    assert(strcmp(out, "data/events/alpha.txt") == 0);
    assert(event_dir_join(out, sizeof out, "data/events/", "alpha.txt") == GW_OK);
    assert(strcmp(out, "data/events/alpha.txt") == 0 && "D3.1b: no double slash");

    /* bounded: 21 characters need 22 bytes */
    assert(event_dir_join(out, 22, "data/events", "alpha.txt") == GW_OK);
    assert(event_dir_join(out, 21, "data/events", "alpha.txt") == GW_ENOSPACE && "D3.1b: refuse to truncate");
    assert(out[0] == '\0');                                   /* nothing half-written is left behind */
    char tiny[4];
    assert(event_dir_join(tiny, sizeof tiny, "data/events", "a.txt") == GW_ENOSPACE && tiny[0] == '\0');
    printf("[join]      OK\n");
}

static void test_list(void)
{
    event_path_t found[8];
    size_t n = 99;
    assert(event_dir_list("data/events", found, 8, &n) == GW_OK);
    assert(n == 2 && "D3.1: exactly alpha.txt and beta.txt are discovered");
    assert(strcmp(found[0].path, "data/events/alpha.txt") == 0);   /* sorted, regardless of readdir order */
    assert(strcmp(found[1].path, "data/events/beta.txt") == 0);
    for (size_t i = 0; i < n; i++)
        printf("            %s\n", found[i].path);

    errno = 0;
    assert(event_dir_list("data/no_such_dir", found, 8, &n) == GW_ENOENT && n == 0);
    assert(errno == ENOENT);
    assert(event_dir_list("data/events", found, 1, &n) == GW_ENOSPACE && n == 0);   /* caller's array too small */
    printf("[list]      OK  (.stale.txt, notes.md, README, events.txt.bak, legacy.txt/ skipped)\n");
}

int main(void)
{
    test_accept();
    test_join();
    test_list();
    assert(gw_alloc_live_count() == 0);
    printf("test_event_dir: all groups passed\n");
    return 0;
}
