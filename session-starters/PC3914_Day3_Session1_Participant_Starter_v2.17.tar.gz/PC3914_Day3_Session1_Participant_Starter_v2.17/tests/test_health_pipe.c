/* test_health_pipe.c — descriptor I/O and the process model, proven with real pipes and real children.
 *
 * [write_all]  1 MiB into a pipe with a slow reader while a 1 ms timer interrupts:
 *              short writes and EINTR happen; every byte must still arrive, in order.
 * [read_full]  a writer that sends the 40-byte record one byte at a time: one write != one read.
 * [eof]        spawn the real reporter; close our write end; the child must see EOF and exit 0.
 * [reap]       finish_reporter closes, reaps, no zombie, no descriptor left open.
 * [exec-fail]  a missing reporter executable: exit status 127, still reaped, nothing leaked. */
#define _POSIX_C_SOURCE 200809L
#include "gw_io.h"
#include "health_report.h"
#include "health_pipe.h"
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <sys/wait.h>
#include <unistd.h>

#define BIG (1u << 20)
#define REPORTER "build/health_reporter"

static void on_alarm(int sig) { (void)sig; }   /* a handler WITHOUT SA_RESTART: blocked syscalls return EINTR */

static void pause_us(long us)
{
    struct timespec ts = { 0, us * 1000L };
    nanosleep(&ts, NULL);
}

/* Descriptors this process holds right now (the DIR's own descriptor is counted consistently). */
static size_t open_fds(void)
{
    DIR *d = opendir("/proc/self/fd");
    assert(d);
    size_t n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL)
        if (e->d_name[0] != '.')
            n++;
    closedir(d);
    return n;
}

static void reap_ok(pid_t pid, int want_status)
{
    int st;
    assert(waitpid(pid, &st, 0) == pid);
    assert(WIFEXITED(st) && WEXITSTATUS(st) == want_status);
}

static void test_write_all(void)
{
    unsigned char *big = malloc(BIG);
    assert(big);
    for (size_t i = 0; i < BIG; i++)
        big[i] = (unsigned char)(i * 7 + 3);

    int fds[2];
    assert(pipe(fds) == 0);
    pid_t child = fork();
    assert(child >= 0);
    if (child == 0) {                               /* reader: slow, small reads, verifies the pattern */
        close(fds[1]);
        unsigned char chunk[4096];
        size_t total = 0;
        int ok = 1;
        for (;;) {
            ssize_t n = read(fds[0], chunk, sizeof chunk);
            if (n < 0) { if (errno == EINTR) continue; ok = 0; break; }
            if (n == 0) break;
            for (ssize_t k = 0; k < n; k++)
                if (chunk[k] != (unsigned char)((total + (size_t)k) * 7 + 3)) ok = 0;
            total += (size_t)n;
            pause_us(1000);                           /* keep the pipe full so the writer blocks */
        }
        _exit(ok && total == BIG ? 0 : 1);
    }
    close(fds[0]);

    struct sigaction sa = { 0 };
    sa.sa_handler = on_alarm;                       /* no SA_RESTART on purpose */
    assert(sigaction(SIGALRM, &sa, NULL) == 0);
    struct itimerval it = { { 0, 1000 }, { 0, 1000 } };   /* every 1 ms */
    assert(setitimer(ITIMER_REAL, &it, NULL) == 0);

    memset(&gw_io_stats, 0, sizeof gw_io_stats);
    gw_status_t rc = write_all(fds[1], big, BIG);
    int saved = errno;

    struct itimerval off = { { 0, 0 }, { 0, 0 } };
    setitimer(ITIMER_REAL, &off, NULL);
    close(fds[1]);

    if (rc != GW_OK)
        fprintf(stderr, "  write_all returned %s (%s) after %zu short writes, %zu EINTR retries\n",
                gw_strstatus(rc), saved ? strerror(saved) : "no errno: a SHORT write, not a failure",
                gw_io_stats.short_writes, gw_io_stats.eintr_retries);
    assert(rc == GW_OK && "TODO-D3.2a: write_all must loop over short writes and retry EINTR");
    reap_ok(child, 0);                              /* every byte arrived, in order */
    assert(gw_io_stats.short_writes + gw_io_stats.eintr_retries > 0 && "the interruptions really happened");
    printf("[write_all] OK  %u bytes delivered; %zu short writes, %zu EINTR retries handled\n",
           BIG, gw_io_stats.short_writes, gw_io_stats.eintr_retries);
    free(big);
}

static void test_read_full(void)
{
    health_record_t sent;
    health_record_init(&sent, 400, 94, 154, 4);
    int fds[2];
    assert(pipe(fds) == 0);
    pid_t child = fork();
    assert(child >= 0);
    if (child == 0) {                               /* writer: one byte per write, with pauses */
        close(fds[0]);
        const unsigned char *p = (const unsigned char *)&sent;
        for (size_t i = 0; i < sizeof sent; i++) {
            if (write(fds[1], p + i, 1) != 1) _exit(1);
            pause_us(500);
        }
        close(fds[1]);
        _exit(0);
    }
    close(fds[1]);
    memset(&gw_io_stats, 0, sizeof gw_io_stats);
    unsigned char buf[sizeof sent + 1];
    size_t got = 0;
    assert(read_full(fds[0], buf, sizeof buf, &got) == GW_OK);
    assert(got == sizeof sent);                     /* EOF stopped the loop exactly at the record's end */
    health_record_t r;
    memcpy(&r, buf, sizeof r);
    assert(health_record_valid(&r, got) && r.processed == 400 && r.rejected == 94 && r.alerts == 154 && r.modules == 4);
    assert(gw_io_stats.short_reads > 0 && "one write is not one read");
    size_t again = 99;
    assert(read_full(fds[0], buf, sizeof buf, &again) == GW_OK && again == 0);   /* EOF is sticky */
    close(fds[0]);
    reap_ok(child, 0);
    printf("[read_full] OK  %zu-byte record assembled from %zu short reads; EOF observed\n",
           got, gw_io_stats.short_reads);
}

/* The child must see EOF after WE close our write end: only possible if it closed its own copy. */
static void test_eof(void)
{
    size_t before = open_fds();
    int wfd;
    pid_t pid;
    fflush(stdout);
    assert(spawn_reporter(REPORTER, &wfd, &pid) == GW_OK);
    health_record_t rec;
    health_record_init(&rec, 7, 1, 2, 1);
    assert(write_all(wfd, &rec, sizeof rec) == GW_OK);
    assert(close(wfd) == 0);                        /* our last write end is gone ... */

    int st = 0, exited = 0;
    for (int i = 0; i < 300 && !exited; i++) {      /* ... the child has 3 s to notice */
        pid_t r = waitpid(pid, &st, WNOHANG);
        assert(r >= 0);
        if (r == pid) exited = 1; else pause_us(10000);
    }
    if (!exited) {
        kill(pid, SIGKILL);
        waitpid(pid, &st, 0);
        assert(0 && "TODO-D3.2b: the reporter never saw EOF — a copy of the write end is still open in the child");
    }
    assert(WIFEXITED(st) && WEXITSTATUS(st) == 0 && "the reporter received the complete record");

    size_t after = open_fds();
    if (after != before)
        fprintf(stderr, "  descriptors open: %zu before, %zu after\n", before, after);
    assert(after == before && "TODO-D3.2c: the parent still holds the read end (descriptor leak)");
    printf("[eof]       OK  child saw EOF and exited 0; %zu descriptors open before and after\n", before);
}

static void test_reap(void)
{
    size_t before = open_fds();
    int wfd, status = -2;
    pid_t pid;
    fflush(stdout);
    assert(spawn_reporter(REPORTER, &wfd, &pid) == GW_OK);
    health_record_t rec;
    health_record_init(&rec, 400, 94, 154, 4);
    assert(write_all(wfd, &rec, sizeof rec) == GW_OK);
    assert(finish_reporter(wfd, pid, &status) == GW_OK);
    assert(status == 0);
    assert(fcntl(wfd, F_GETFD) == -1 && errno == EBADF);          /* write end closed by finish */
    assert(waitpid(pid, NULL, WNOHANG) == -1 && errno == ECHILD); /* already reaped: no zombie */
    assert(open_fds() == before);
    printf("[reap]      OK  status 0, write end closed, child reaped (ECHILD on a second wait)\n");
}

static void test_exec_failure(void)
{
    size_t before = open_fds();
    int wfd, status = -2;
    pid_t pid;
    fflush(stdout);
    assert(spawn_reporter("build/no_such_reporter", &wfd, &pid) == GW_OK);   /* fork worked; exec will not */
    assert(finish_reporter(wfd, pid, &status) == GW_OK);
    assert(status == 127 && "a failed exec is reported by the child's _exit(127), not by exec returning");
    assert(waitpid(pid, NULL, WNOHANG) == -1 && errno == ECHILD);
    assert(open_fds() == before);
    printf("[exec-fail] OK  missing executable -> status 127, reaped, nothing leaked\n");
}

int main(void)
{
    signal(SIGPIPE, SIG_IGN);                       /* a vanished reader must become EPIPE, not a kill */
    assert(sizeof(health_record_t) == 40);
    if (access(REPORTER, X_OK) != 0) {
        fprintf(stderr, "test_health_pipe: %s missing — run `make health-reporter` first\n", REPORTER);
        return 1;
    }
    test_write_all();
    test_read_full();
    test_eof();
    test_reap();
    test_exec_failure();
    printf("test_health_pipe: all groups passed\n");
    return 0;
}
