/* test_snapshot.c — the arena-backed snapshot never touches the heap and
 * never leaves pointers into the store. */
#include "diag_snapshot.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *mk(uint32_t id, event_kind_t k, int16_t rssi, const char *payload)
{
    event_view_t v = { id, k, rssi, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

static int in_arena(const arena_t *a, const void *p)
{
    const unsigned char *q = p;
    return q >= a->base && q < a->base + a->capacity;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    event_store_t *store = event_store_create(8);
    assert(store);
    assert(event_store_push(store, mk(3, EV_CONNECT, -90, "ATTACH_OK"))     == 0);
    assert(event_store_push(store, mk(3, EV_SIGNAL,  -95, "DEGRADED"))      == 0);
    assert(event_store_push(store, mk(1, EV_SIGNAL,  -71, "CONNECTED"))     == 0);
    assert(event_store_push(store, mk(3, EV_ERROR,  -113, "SIM_NOT_READY")) == 0);
    assert(event_store_push(store, mk(1, EV_SIGNAL,  -80, "CONNECTED"))     == 0);
    assert(event_store_push(store, mk(3, EV_SIGNAL,  -74, "CONNECTED"))     == 0);

    arena_t arena;
    assert(arena_init(&arena, 4096) == GW_OK);
    size_t heap_total = gw_alloc_total_count();
    size_t heap_live  = gw_alloc_live_count();

    /* 1. build succeeds and uses ONLY the arena */
    snapshot_t s;
    gw_status_t st = diag_snapshot_build(store, 0, 6, &arena, &s);
    assert(st == GW_OK && "TODO-L3.2a: snapshot_strdup must copy into the arena");
    assert(gw_alloc_total_count() == heap_total);            /* zero heap allocations */
    assert(gw_alloc_live_count()  == heap_live);
    assert(arena_used(&arena) > 0);

    /* 2. per-module aggregation, in module order */
    assert(s.module_count == 2 && "TODO-L3.2b: fill the module array from the table");
    assert(s.modules[0].module_id == 1 && s.modules[0].events == 2 && s.modules[0].errors == 0);
    assert(s.modules[0].has_signal && s.modules[0].weakest_rssi == -80);
    assert(s.modules[0].last_error == NULL);
    assert(s.modules[1].module_id == 3 && s.modules[1].events == 4 && s.modules[1].errors == 1);
    assert(s.modules[1].weakest_rssi == -95);
    assert(s.modules[1].last_error && strcmp(s.modules[1].last_error, "SIM_NOT_READY") == 0);

    /* 3. every string is an arena COPY, not a pointer into the store */
    const event_t *err = event_store_get(store, 3);
    assert(s.modules[1].last_error != err->payload);
    assert(in_arena(&arena, s.modules));
    assert(in_arena(&arena, s.modules[1].last_error));
    assert(in_arena(&arena, s.modules[1].line));
    assert(in_arena(&arena, s.event_lines) && in_arena(&arena, s.event_lines[0]));
    assert(strstr(s.modules[1].line, "weakest -95 dBm") && strstr(s.modules[1].line, "SIM_NOT_READY"));
    assert(s.event_count == 6 && strstr(s.event_lines[3], "SIM_NOT_READY"));

    /* 4. reset reuses the arena; the store is untouched */
    snapshot_module_t *first_modules = s.modules;
    arena_reset(&arena);
    assert(arena_used(&arena) == 0);
    assert(event_store_len(store) == 6);
    assert(strcmp(event_store_get(store, 3)->payload, "SIM_NOT_READY") == 0);
    assert(diag_snapshot_build(store, 0, 6, &arena, &s) == GW_OK);
    assert(s.modules == first_modules);                       /* same bytes handed out again */
    arena_reset(&arena);

    /* 5. a window the arena cannot hold fails cleanly and the store survives */
    arena_t small;
    assert(arena_init(&small, 256) == GW_OK);
    assert(diag_snapshot_build(store, 0, 6, &small, &s) == GW_ENOSPACE);
    arena_reset(&small);                                      /* the documented recovery */
    assert(diag_snapshot_build(store, 0, 1, &small, &s) == GW_OK);   /* one event fits */
    assert(s.event_count == 1);
    arena_destroy(&small);
    assert(strcmp(event_store_get(store, 0)->payload, "ATTACH_OK") == 0);

    /* 6. argument checks */
    assert(diag_snapshot_build(store, 0, 7, &arena, &s) == GW_EINVAL);
    assert(diag_snapshot_build(store, 4, 2, &arena, &s) == GW_EINVAL);
    assert(diag_snapshot_build(store, 2, 2, &arena, &s) == GW_OK);   /* empty window is legal */
    assert(s.module_count == 0 && s.event_count == 0);

    arena_destroy(&arena);
    event_store_destroy(store);
    assert(gw_alloc_live_count() == 0);
    puts("test_snapshot: OK");
    return 0;
}
