#include "event_store.h"
#include "event_parser.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *make_event(uint32_t id, const char *payload)
{
    event_view_t v = { id, EV_SIGNAL, -70, payload, strlen(payload) };
    return event_clone(&v);
}

int main(void)
{
    /* 1. construction failure paths leak nothing and never crash */
    gw_alloc_fail_after(0);
    assert(event_store_create(4) == NULL);
    gw_alloc_fail_after(1);
    assert(event_store_create(4) == NULL);
    assert(gw_alloc_live_count() == 0);

    event_store_t *s = event_store_create(2);
    assert(s);

    /* 2. growth: 128 pushes from cap 2 force six reallocs */
    for (uint32_t i = 0; i < 128; i++) {
        event_t *e = make_event(i, "CONNECTED");
        assert(e);
        assert(event_store_push(s, e) == 0);
    }
    assert(event_store_len(s) == 128);

    /* 3. element pointers stay valid across growth */
    const event_t *first = event_store_get(s, 0);
    assert(first && first->module_id == 0 && strcmp(first->payload, "CONNECTED") == 0);

    /* 4. push failure: store unchanged, caller still owns the event */
    assert(s->len == s->cap);                     /* full: next push must grow */
    event_t *extra = make_event(999, "SIM_NOT_READY");
    assert(extra);
    gw_alloc_fail_after(0);
    assert(event_store_push(s, extra) == -1);
    assert(event_store_len(s) == 128);
    assert(event_store_get(s, 127)->module_id == 127);
    event_free(extra);                            /* still ours */

    /* 5. store still usable after a failed growth */
    event_t *again = make_event(128, "CONNECTED");
    assert(again && event_store_push(s, again) == 0);
    assert(event_store_len(s) == 129);

    /* 6. destroy releases every event and the array */
    event_store_destroy(s);
    event_store_destroy(NULL);
    assert(gw_alloc_live_count() == 0);

    puts("test_event_store: OK");
    return 0;
}
