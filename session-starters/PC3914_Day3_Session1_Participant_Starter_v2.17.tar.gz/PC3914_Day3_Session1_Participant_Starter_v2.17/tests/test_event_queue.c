/* test_event_queue.c — executable invariants of the intake queue.
 * Groups run in order; the first failing assert names the TODO. */
#include "event_queue.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *mk(uint32_t id, const char *payload)
{
    event_view_t v = { id, EV_SIGNAL, -70, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

/* The structural invariant, checked after every operation. */
static void check(const event_queue_t *q)
{
    size_t n = 0;
    const queue_node_t *last = NULL;
    for (const queue_node_t *c = q->head; c; c = c->next) {
        n++;
        last = c;
    }
    assert(q->tail == last
           && "TODO-D2.1a: tail must be the last node (NULL when empty)");
    assert(n == q->size
           && "TODO-D2.1b: size must equal the node count");
    assert((q->size == 0) == (q->head == NULL && q->tail == NULL));
    assert((q->size == 1) == (q->head != NULL && q->head == q->tail));
    assert(!q->tail || q->tail->next == NULL);
}

static void test_empty(void)
{
    event_queue_t *q = event_queue_create();
    assert(q);
    check(q);
    assert(event_queue_is_empty(q) && event_queue_size(q) == 0);
    assert(event_queue_pop(q) == NULL);                   /* expected, not an error */
    check(q);
    event_queue_destroy(q);
    event_queue_destroy(NULL);
    assert(gw_alloc_live_count() == 0);
    puts("[empty]     OK");
}

static void test_one(void)
{
    event_queue_t *q = event_queue_create();
    event_t *e = mk(3, "SIM_NOT_READY");
    assert(event_queue_push(q, e) == GW_OK);
    check(q);
    assert(q->head == q->tail && q->head->event == e);

    event_t *out = event_queue_pop(q);
    assert(out == e);
    check(q);                                             /* names TODO-D2.1a / D2.1b on failure */
    assert(event_queue_size(q) == 0);
    assert(event_queue_pop(q) == NULL);

    event_free(out);                                      /* caller owns it now */
    event_queue_destroy(q);
    assert(gw_alloc_live_count() == 0);
    puts("[one]       OK");
}

static void test_fifo(void)
{
    event_queue_t *q = event_queue_create();
    for (uint32_t i = 0; i < 5; i++) {
        assert(event_queue_push(q, mk(i, "CONNECTED")) == GW_OK);
        check(q);
    }
    assert(event_queue_size(q) == 5);

    for (uint32_t i = 0; i < 5; i++) {
        event_t *e = event_queue_pop(q);
        assert(e && e->module_id == i);                   /* arrival order */
        check(q);
        assert(event_queue_size(q) == 4 - i);
        event_free(e);
    }
    assert(event_queue_pop(q) == NULL);
    check(q);

    /* head/tail transitions: refill after becoming empty */
    assert(event_queue_push(q, mk(7, "A")) == GW_OK);
    assert(event_queue_push(q, mk(8, "B")) == GW_OK);
    check(q);
    event_t *e = event_queue_pop(q);
    assert(e->module_id == 7);
    event_free(e);
    check(q);
    assert(q->head == q->tail && q->head->event->module_id == 8);

    event_queue_destroy(q);                               /* one event still queued */
    assert(gw_alloc_live_count() == 0);
    puts("[fifo]      OK");
}

static void test_failure(void)
{
    event_queue_t *q = event_queue_create();
    event_t *e = mk(5, "NETWORK_LOST");
    size_t live = gw_alloc_live_count();

    gw_alloc_fail_after(0);                               /* the node allocation fails */
    assert(event_queue_push(q, e) == GW_ENOMEM);
    check(q);
    assert(event_queue_size(q) == 0);                     /* queue unchanged */
    assert(gw_alloc_live_count() == live);                /* nothing leaked, e still live */
    assert(strcmp(e->payload, "NETWORK_LOST") == 0);      /* we still own it */

    assert(event_queue_push(q, e) == GW_OK);              /* retry succeeds */
    assert(event_queue_push(q, NULL) == GW_EINVAL);
    check(q);

    event_queue_destroy(q);
    assert(gw_alloc_live_count() == 0);
    puts("[failure]   OK");
}

static void test_destroy(void)
{
    event_queue_t *q = event_queue_create();
    for (uint32_t i = 0; i < 50; i++)
        assert(event_queue_push(q, mk(i, "DEGRADED")) == GW_OK);
    assert(gw_alloc_live_count() == 1 + 50 * 3);          /* queue + (node + event + payload) each */
    event_queue_destroy(q);
    assert(gw_alloc_live_count() == 0);
    puts("[destroy]   OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;

    if (all || !strcmp(g, "empty"))   test_empty();
    if (all || !strcmp(g, "one"))     test_one();
    if (all || !strcmp(g, "fifo"))    test_fifo();
    if (all || !strcmp(g, "failure")) test_failure();
    if (all || !strcmp(g, "destroy")) test_destroy();

    puts("test_event_queue: all groups passed");
    return 0;
}
