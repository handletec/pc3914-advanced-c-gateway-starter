/* test_work_stack.c — LIFO order, empty pop, growth, no ownership. */
#include "work_stack.h"
#include "event_store.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *mk(uint32_t id)
{
    event_view_t v = { id, EV_SIGNAL, -70, "CONNECTED", 9 };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    /* events live in a store; the stack only borrows them */
    event_store_t *store = event_store_create(4);
    assert(store);
    for (uint32_t i = 0; i < 20; i++)
        assert(event_store_push(store, mk(i)) == 0);
    size_t live = gw_alloc_live_count();

    work_stack_t s;
    work_stack_init(&s);
    assert(work_stack_is_empty(&s) && work_stack_pop(&s) == NULL);     /* empty pop: expected */
    assert(work_stack_push(&s, NULL) == GW_EINVAL);                     /* NULL would be indistinguishable from empty */
    assert(work_stack_size(&s) == 0);

    for (size_t i = 0; i < 20; i++)
        assert(work_stack_push(&s, event_store_get(store, i)) == GW_OK); /* grows 8 -> 16 -> 32 */
    assert(work_stack_size(&s) == 20 && s.cap == 32);
    assert(gw_alloc_live_count() == live + 1);                          /* one array, no nodes */

    for (uint32_t i = 20; i-- > 0;) {                                    /* last in, first out */
        const event_t *e = work_stack_pop(&s);
        assert(e && e->module_id == i);
        assert(work_stack_size(&s) == i);
    }
    assert(work_stack_pop(&s) == NULL && work_stack_is_empty(&s));

    /* growth failure leaves the stack unchanged */
    work_stack_t t;
    work_stack_init(&t);
    gw_alloc_fail_after(0);
    assert(work_stack_push(&t, event_store_get(store, 0)) == GW_ENOMEM);
    assert(work_stack_size(&t) == 0 && t.items == NULL);
    assert(work_stack_push(&t, event_store_get(store, 0)) == GW_OK);
    work_stack_destroy(&t);

    work_stack_destroy(&s);
    assert(gw_alloc_live_count() == live);                              /* events untouched */
    assert(strcmp(event_store_get(store, 19)->payload, "CONNECTED") == 0);

    event_store_destroy(store);
    assert(gw_alloc_live_count() == 0);
    puts("test_work_stack: OK");
    return 0;
}
