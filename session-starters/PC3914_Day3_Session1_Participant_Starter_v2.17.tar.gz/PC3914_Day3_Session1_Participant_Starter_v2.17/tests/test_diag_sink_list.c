/* test_diag_sink_list.c — executable invariants of the sink registry. */
#include "diag_sink_list.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Structural invariant: count matches, ids unique, order recorded. */
static void check(const diag_sink_list_t *l, const uint32_t *expect_ids, size_t n)
{
    size_t i = 0;
    for (const diag_sink_t *s = l->head; s; s = s->next, i++) {
        assert(i < n);
        assert(s->id == expect_ids[i]);                       /* order preserved */
        for (const diag_sink_t *t = s->next; t; t = t->next)
            assert(t->id != s->id);                           /* unique */
        if (!s->next)
            assert(i == n - 1);
    }
    assert(i == n);
    assert(l->count == n);
}

static void test_add(void)
{
    diag_sink_list_t l;
    diag_sink_list_init(&l);
    check(&l, NULL, 0);

    assert(diag_sink_list_add(&l, 10, "console") == GW_OK);
    assert(diag_sink_list_add(&l, 20, "logfile") == GW_OK);
    assert(diag_sink_list_add(&l, 30, "telemetry-uplink-with-a-very-long-name") == GW_OK);
    check(&l, (uint32_t[]){10, 20, 30}, 3);                   /* appended in registration order */

    const diag_sink_t *s = diag_sink_list_find(&l, 30);
    assert(s && strlen(s->name) == SINK_NAME_MAX - 1);         /* bounded copy */
    assert(diag_sink_list_find(&l, 99) == NULL);

    assert(diag_sink_list_add(&l, 20, "dup") == GW_EEXIST);    /* expected, list unchanged */
    assert(diag_sink_list_add(&l, 40, "") == GW_EINVAL);
    check(&l, (uint32_t[]){10, 20, 30}, 3);

    size_t live = gw_alloc_live_count();
    gw_alloc_fail_after(0);
    assert(diag_sink_list_add(&l, 40, "late") == GW_ENOMEM);
    assert(gw_alloc_live_count() == live);
    check(&l, (uint32_t[]){10, 20, 30}, 3);

    diag_sink_list_destroy(&l);
    check(&l, NULL, 0);
    assert(gw_alloc_live_count() == 0);
    puts("[add]       OK");
}

static void test_remove(void)
{
    diag_sink_list_t l;
    diag_sink_list_init(&l);
    assert(diag_sink_list_add(&l, 10, "console")  == GW_OK);
    assert(diag_sink_list_add(&l, 20, "logfile")  == GW_OK);
    assert(diag_sink_list_add(&l, 30, "uplink")   == GW_OK);
    assert(diag_sink_list_add(&l, 40, "debug")    == GW_OK);
    size_t live = gw_alloc_live_count();

    /* middle */
    assert(diag_sink_list_remove(&l, 20) == GW_OK
           && "TODO-D2.3: unlink the matching node");
    check(&l, (uint32_t[]){10, 30, 40}, 3);
    assert(diag_sink_list_find(&l, 20) == NULL);               /* unreachable */
    assert(gw_alloc_live_count() == live - 1);                 /* node freed */

    /* head */
    assert(diag_sink_list_remove(&l, 10) == GW_OK);
    check(&l, (uint32_t[]){30, 40}, 2);
    assert(l.head && l.head->id == 30);                        /* head updated */

    /* last */
    assert(diag_sink_list_remove(&l, 40) == GW_OK);
    check(&l, (uint32_t[]){30}, 1);
    assert(l.head->next == NULL);

    /* missing: nothing changes */
    assert(diag_sink_list_remove(&l, 99) == GW_ENOENT);
    check(&l, (uint32_t[]){30}, 1);
    assert(gw_alloc_live_count() == live - 3);

    /* only node -> empty */
    assert(diag_sink_list_remove(&l, 30) == GW_OK);
    check(&l, NULL, 0);
    assert(diag_sink_list_remove(&l, 30) == GW_ENOENT);        /* empty list: still a miss */

    /* reusable after emptying */
    assert(diag_sink_list_add(&l, 50, "again") == GW_OK);
    check(&l, (uint32_t[]){50}, 1);
    diag_sink_list_destroy(&l);
    assert(gw_alloc_live_count() == 0);
    puts("[remove]    OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;
    if (all || !strcmp(g, "add"))    test_add();
    if (all || !strcmp(g, "remove")) test_remove();
    puts("test_diag_sink_list: all groups passed");
    return 0;
}
