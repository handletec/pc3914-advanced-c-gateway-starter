/* test_device_registry.c — behaviour only, through the public interface.
 * No test touches the representation: layout can change without touching this file. */
#include "device_registry.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static device_state_t dev(uint32_t id, module_state_t st, int16_t rssi, size_t n)
{
    device_state_t d = { id, st, rssi, n };
    return d;
}

/* Invariant through the interface: every visited entry is findable at the
 * same address; the visit count equals count(); the load rule holds. */
static void count_visit(const device_state_t *v, void *ctx)
{
    struct { const device_registry_t *r; size_t n; } *c = ctx;
    assert(device_registry_find(c->r, v->module_id) == v);
    c->n++;
}
static void check(const device_registry_t *r)
{
    struct { const device_registry_t *r; size_t n; } c = { r, 0 };
    device_registry_for_each(r, count_visit, &c);
    assert(c.n == device_registry_count(r));
    assert(device_registry_count(r) * 4 <= device_registry_capacity(r) * 3);
}

static uint32_t colliding_id(const device_registry_t *r, uint32_t a)
{
    size_t home = device_registry_home_slot(r, a);
    for (uint32_t b = a + 1; b < a + 100000; b++)
        if (device_registry_home_slot(r, b) == home)
            return b;
    assert(0 && "no collision found in range");
    return 0;
}

static void test_basic(void)
{
    assert(device_registry_create(0) == NULL);
    device_registry_t *r = device_registry_create(8);
    assert(r);
    check(r);
    assert(device_registry_find(r, 3) == NULL);

    device_state_t d = dev(3, MOD_ONLINE, -90, 1);
    assert(device_registry_upsert(r, &d) == GW_OK);
    assert(device_registry_count(r) == 1);
    const device_state_t *v = device_registry_find(r, 3);
    assert(v && v->state == MOD_ONLINE && v->last_rssi == -90 && v->event_count == 1);
    check(r);

    d = dev(3, MOD_CONNECTING, -113, 2);
    assert(device_registry_upsert(r, &d) == GW_OK);
    assert(device_registry_count(r) == 1);
    v = device_registry_find(r, 3);
    assert(v && v->state == MOD_CONNECTING && v->event_count == 2);
    assert(device_registry_find(r, 4) == NULL);
    check(r);

    device_registry_destroy(r);
    device_registry_destroy(NULL);
    assert(gw_alloc_live_count() == 0);
    puts("[basic]     OK");
}

static void test_collision(void)
{
    device_registry_t *r = device_registry_create(8);
    uint32_t a = 3, b = colliding_id(r, 3);
    assert(device_registry_home_slot(r, a) == device_registry_home_slot(r, b));

    device_state_t da = dev(a, MOD_ONLINE, -70, 1);
    device_state_t db = dev(b, MOD_DEGRADED,  -99, 5);
    assert(device_registry_upsert(r, &da) == GW_OK);
    assert(device_registry_upsert(r, &db) == GW_OK);
    assert(device_registry_count(r) == 2);
    const device_state_t *va = device_registry_find(r, a);
    const device_state_t *vb = device_registry_find(r, b);
    assert(va && va->module_id == a && vb && vb->module_id == b && va != vb);
    check(r);

    db.event_count = 6;
    assert(device_registry_upsert(r, &db) == GW_OK);
    assert(device_registry_find(r, a)->event_count == 1);
    assert(device_registry_find(r, b)->event_count == 6);

    uint32_t c = colliding_id(r, b);
    device_state_t dc = dev(c, MOD_OFFLINE, -101, 9);
    assert(device_registry_upsert(r, &dc) == GW_OK);
    assert(device_registry_count(r) == 3);
    assert(device_registry_find(r, 999999) == NULL);
    check(r);

    device_registry_destroy(r);
    assert(gw_alloc_live_count() == 0);
    puts("[collision] OK");
}

static void test_growth(void)
{
    device_registry_t *r = device_registry_create(4);
    size_t live = gw_alloc_live_count();
    for (uint32_t id = 100; id < 103; id++) {
        device_state_t d = dev(id, MOD_ONLINE, -80, id);
        assert(device_registry_upsert(r, &d) == GW_OK);
    }
    assert(device_registry_capacity(r) == 4 && device_registry_count(r) == 3);
    check(r);

    gw_alloc_fail_after(0);
    device_state_t d = dev(103, MOD_ONLINE, -80, 103);
    assert(device_registry_upsert(r, &d) == GW_ENOMEM);
    assert(device_registry_capacity(r) == 4 && device_registry_count(r) == 3);
    assert(device_registry_find(r, 101)->event_count == 101);
    assert(gw_alloc_live_count() == live);

    /* the lifetime rule opacity must not hide: a find() pointer dies at the next upsert that grows */
    const device_state_t *before = device_registry_find(r, 101);
    assert(device_registry_upsert(r, &d) == GW_OK);                /* grows to 8: entries move */
    assert(device_registry_capacity(r) == 8 && device_registry_count(r) == 4);
    const device_state_t *after = device_registry_find(r, 101);
    assert(after && after->event_count == 101);
    (void)before;                                                  /* do not dereference: stale by contract */

    for (uint32_t id = 200; id < 260; id++) {
        device_state_t e = dev(id, MOD_DEGRADED, -95, id);
        assert(device_registry_upsert(r, &e) == GW_OK);
    }
    assert(device_registry_count(r) == 64 && device_registry_capacity(r) == 128);
    for (uint32_t id = 200; id < 260; id++)
        assert(device_registry_find(r, id)->event_count == id);
    check(r);
    assert(gw_alloc_live_count() == live);

    device_registry_destroy(r);
    assert(gw_alloc_live_count() == 0);
    puts("[growth]    OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;
    if (all || !strcmp(g, "basic"))     test_basic();
    if (all || !strcmp(g, "collision")) test_collision();
    if (all || !strcmp(g, "growth"))    test_growth();
    puts("test_device_registry: all groups passed");
    return 0;
}
