/* test_alert_strategy.c — policies are compared on the SAME events; the heap is unchanged. */
#include "alert_strategy.h"
#include "alert_heap.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Build an owned event exactly as the gateway does (event_clone from a view). */
static event_t *mk(uint32_t module_id, event_kind_t kind, int16_t rssi, const char *payload)
{
    event_view_t v = { module_id, kind, rssi, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e && "test setup: event_clone failed");
    return e;
}

/* Run one policy over one event; returns severity (0 = not raised) and checks every field. */
static unsigned sev_under(const alert_strategy_t *p, const event_t *e, uint64_t seq)
{
    alert_t a;
    memset(&a, 0xEE, sizeof a);                                   /* sentinel: untouched must stay 0xEE */
    int raise = -1;
    assert(alert_classify(p, e, seq, &a, &raise) == GW_OK);
    assert(raise == 0 || raise == 1);
    if (!raise) {
        unsigned char *b = (unsigned char *)&a;
        for (size_t i = 0; i < sizeof a; i++)
            assert(b[i] == 0xEE && "not raised: *out must be untouched");
        return 0;
    }
    assert(a.module_id == e->module_id);
    assert(a.seq == seq);
    assert(a.severity >= 1 && a.severity <= 3);
    assert(a.code[sizeof a.code - 1] == '\0');                    /* bounded copy */
    assert(strncmp(a.code, e->payload, sizeof a.code - 1) == 0);
    return a.severity;
}

static void test_default(void)
{
    const alert_strategy_t *d = alert_strategy_default();
    assert(d && strcmp(d->name, "default") == 0 && d->classify);
    event_t *sim  = mk(3, EV_ERROR,  -113, "SIM_NOT_READY");
    event_t *net  = mk(6, EV_ERROR,   -64, "NETWORK_LOST");
    event_t *weak = mk(1, EV_SIGNAL, -100, "DEGRADED");
    event_t *poor = mk(1, EV_SIGNAL,  -95, "CONNECTED");
    event_t *conn = mk(5, EV_CONNECT, -78, "ATTACH_OK");
    assert(sev_under(d, sim,  10) == 3);
    assert(sev_under(d, net,  11) == 2);
    assert(sev_under(d, weak, 12) == 1);
    assert(sev_under(d, poor, 13) == 0);
    assert(sev_under(d, conn, 14) == 0);
    event_free(sim); event_free(net); event_free(weak); event_free(poor); event_free(conn);
    printf("[default]      OK\n");
}

static void test_conservative(void)
{
    const alert_strategy_t *c = alert_strategy_find("conservative");
    assert(c && strcmp(c->name, "conservative") == 0 && c->classify);
    const alert_strategy_t *d = alert_strategy_default();
    event_t *sim  = mk(3, EV_ERROR,  -113, "SIM_NOT_READY");
    event_t *net  = mk(6, EV_ERROR,   -64, "NETWORK_LOST");
    event_t *weak = mk(1, EV_SIGNAL, -100, "DEGRADED");
    event_t *poor = mk(1, EV_SIGNAL,  -90, "CONNECTED");
    event_t *good = mk(1, EV_SIGNAL,  -89, "CONNECTED");
    event_t *conn = mk(5, EV_CONNECT, -78, "ATTACH_OK");

    /* the same event, two policies, different answers */
    assert(sev_under(c, net, 11) == 3 && "TODO-D2.7: conservative treats every ERROR as severity 3");
    assert(sev_under(d, net, 11) == 2);
    assert(sev_under(c, sim, 10) == 3);
    assert(sev_under(c, weak, 12) == 2 && "TODO-D2.7: weak signal (<= -100) is severity 2");
    assert(sev_under(d, weak, 12) == 1);
    assert(sev_under(c, poor, 13) == 1 && "TODO-D2.7: poor signal (<= -90) is severity 1");
    assert(sev_under(d, poor, 13) == 0);
    assert(sev_under(c, good, 14) == 0 && "TODO-D2.7: -89 dBm raises nothing");
    assert(sev_under(c, conn, 15) == 0 && "TODO-D2.7: CONNECT raises nothing");
    event_free(sim); event_free(net); event_free(weak); event_free(poor); event_free(good); event_free(conn);
    printf("[conservative] OK\n");
}

static void test_selection(void)
{
    assert(alert_strategy_count() >= 2);
    assert(alert_strategy_find("default") == alert_strategy_default());
    assert(alert_strategy_find("conservative") != NULL);
    assert(alert_strategy_find("strict") == NULL);                /* unknown: expected */
    assert(alert_strategy_find(NULL) == NULL);
    assert(alert_strategy_at(alert_strategy_count()) == NULL);
    for (size_t i = 0; i < alert_strategy_count(); i++) {          /* every row is selectable by its own name */
        const alert_strategy_t *p = alert_strategy_at(i);
        assert(p && p->name && p->classify && alert_strategy_find(p->name) == p);
    }
    printf("[selection]    OK\n");
}

static void test_invalid(void)
{
    event_t *net = mk(6, EV_ERROR, -64, "NETWORK_LOST");
    alert_t a;
    memset(&a, 0xEE, sizeof a);
    int raise = -1;
    assert(alert_classify(NULL, net, 1, &a, &raise) == GW_EINVAL);          /* NULL policy */
    alert_strategy_t broken = { "broken", NULL };
    assert(alert_classify(&broken, net, 1, &a, &raise) == GW_EINVAL);       /* policy without an operation */
    assert(alert_classify(alert_strategy_default(), NULL, 1, &a, &raise) == GW_EINVAL);
    assert(alert_classify(alert_strategy_default(), net, 1, NULL, &raise) == GW_EINVAL);
    assert(alert_classify(alert_strategy_default(), net, 1, &a, NULL) == GW_EINVAL);
    assert(raise == -1 && ((unsigned char *)&a)[0] == 0xEE);               /* outputs untouched */
    event_free(net);
    printf("[invalid]      OK\n");
}

/* The SAME caller, the policy chosen at run time; the heap is fed the same way. */
static size_t run_policy(const alert_strategy_t *p, event_t **events, size_t n, alert_heap_t *h)
{
    size_t raised = 0;
    for (size_t i = 0; i < n; i++) {
        alert_t a;
        int raise;
        assert(alert_classify(p, events[i], i, &a, &raise) == GW_OK);
        if (raise) {
            assert(alert_heap_push(h, &a) == GW_OK);
            raised++;
        }
    }
    return raised;
}

static void test_heap_unchanged(void)
{
    event_t *ev[] = {
        mk(1, EV_SIGNAL,  -95, "CONNECTED"),     /* seq 0 */
        mk(6, EV_ERROR,   -64, "NETWORK_LOST"),  /* seq 1 */
        mk(3, EV_ERROR,  -113, "SIM_NOT_READY"), /* seq 2 */
        mk(1, EV_SIGNAL, -101, "DEGRADED"),      /* seq 3 */
        mk(5, EV_CONNECT, -78, "ATTACH_OK"),     /* seq 4 */
    };
    const char *chosen[] = { "default", "conservative" };
    size_t expect_raised[] = { 3, 4 };
    uint64_t expect_first[] = { 2, 1 };          /* default: sev3 seq2; conservative: sev3 seq1 outranks sev3 seq2 */
    for (size_t k = 0; k < 2; k++) {
        const alert_strategy_t *p = alert_strategy_find(chosen[k]);   /* selected by name at run time */
        alert_heap_t h;
        alert_heap_init(&h);
        size_t raised = run_policy(p, ev, 5, &h);
        assert(raised == expect_raised[k] && "TODO-D2.7: conservative raises 4 of these 5");
        assert(alert_heap_size(&h) == raised);
        alert_t top;
        assert(alert_heap_pop(&h, &top) && top.seq == expect_first[k]);
        alert_t prev = top;                                            /* still (severity desc, seq asc) */
        while (alert_heap_pop(&h, &top)) {
            assert(!alert_outranks(&top, &prev));
            prev = top;
        }
        alert_heap_destroy(&h);
    }
    for (size_t i = 0; i < 5; i++)
        event_free(ev[i]);
    printf("[heap]         OK\n");
}

int main(void)
{
    test_default();
    test_selection();
    test_invalid();
    test_conservative();
    test_heap_unchanged();
    assert(gw_alloc_live_count() == 0);
    printf("test_alert_strategy: all groups passed\n");
    return 0;
}
