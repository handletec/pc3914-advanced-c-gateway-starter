/* test_diag.c — Block 2 Activity A1: the engine retains owned error events. */
#include "diag_engine.h"
#include "event_parser.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Simulates one read cycle: the SAME buffer is refilled every call. */
static void read_cycle(const char *text)
{
    static char buf[256];
    strncpy(buf, text, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    parse_events(buf, strlen(buf), diag_on_event);
}

int main(void)
{
    diag_init();

    read_cycle("3 ERROR -113 SIM_NOT_READY\n");
    read_cycle("3 SIGNAL -71 CONNECTED\n1 SIGNAL -80 CONNECTED\n");   /* buffer reused */

    /* 1. retained data must survive buffer reuse */
    assert(diag_last_error(3) != NULL);
    assert(strcmp(diag_last_error(3), "SIM_NOT_READY") == 0);

    /* 2. replacement must not leak the previous event */
    size_t live = gw_alloc_live_count();
    read_cycle("3 ERROR -113 NETWORK_LOST\n");
    assert(strcmp(diag_last_error(3), "NETWORK_LOST") == 0);
    assert(gw_alloc_live_count() == live);

    /* 3. allocation failure keeps the previous error and leaks nothing */
    gw_alloc_fail_after(0);
    read_cycle("3 ERROR -113 REG_DENIED\n");
    assert(strcmp(diag_last_error(3), "NETWORK_LOST") == 0);
    assert(gw_alloc_live_count() == live);

    /* 4. shutdown releases everything */
    diag_shutdown();
    assert(diag_last_error(3) == NULL);
    assert(gw_alloc_live_count() == 0);

    puts("test_diag: OK");
    return 0;
}
