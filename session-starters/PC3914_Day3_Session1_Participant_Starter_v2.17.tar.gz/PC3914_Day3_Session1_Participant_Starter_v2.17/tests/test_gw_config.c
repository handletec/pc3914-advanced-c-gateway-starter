/* test_gw_config.c — valid file, missing file, malformed value, unknown key, boundary. */
#include "gw_config.h"
#include "gw_alloc.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

static void test_valid(void)
{
    gw_config_t c;
    gw_config_init(&c);
    assert(strcmp(c.policy, "default") == 0 && c.arena_bytes == 16384);
    size_t line = 99;
    assert(gw_config_load("data/gateway.conf", &c, &line) == GW_OK);
    assert(line == 0);
    assert(strcmp(c.policy, "conservative") == 0);
    assert(c.arena_bytes == 8192);
    printf("[valid]     OK  policy=%s arena_bytes=%zu\n", c.policy, c.arena_bytes);
}

static void test_missing(void)
{
    gw_config_t c;
    gw_config_init(&c);
    errno = 0;
    assert(gw_config_load("data/conf/does_not_exist.conf", &c, NULL) == GW_ENOENT);
    assert(errno == ENOENT);                                    /* the boundary keeps errno for the message */
    assert(strcmp(c.policy, "default") == 0 && c.arena_bytes == 16384);   /* defaults untouched */
    printf("[missing]   OK  %s\n", strerror(errno));
}

static void test_malformed(void)
{
    gw_config_t c;
    size_t line;
    gw_config_init(&c);
    assert(gw_config_load("data/conf/bad_arena.conf", &c, &line) == GW_EINVAL && line == 2);
    assert(c.arena_bytes == 16384 && strcmp(c.policy, "default") == 0);   /* line 1 was valid: still not applied */
    assert(gw_config_load("data/conf/no_equals.conf", &c, &line) == GW_EINVAL && line == 2);
    assert(gw_config_load("data/conf/flag_in_config.conf", &c, &line) == GW_EINVAL && line == 2);  /* trace=1 */
    assert(gw_config_load("data/conf/long_policy.conf", &c, &line) == GW_ENOSPACE && line == 1);
    assert(gw_config_load(NULL, &c, &line) == GW_EINVAL);
    printf("[malformed] OK  bad value, no '=', feature flag, over-long value: all rejected with a line number\n");
}

/* The result must not depend on the loader's line buffer: mutate a copy,
 * load again into another struct, compare. */
static void test_copies(void)
{
    gw_config_t a, b;
    gw_config_init(&a);
    gw_config_init(&b);
    assert(gw_config_load("data/gateway.conf", &a, NULL) == GW_OK);
    assert(gw_config_load("data/conf/unknown_policy.conf", &b, NULL) == GW_OK);   /* loader does not know policy names */
    assert(strcmp(a.policy, "conservative") == 0 && strcmp(b.policy, "strict") == 0);
    assert((const char *)a.policy >= (const char *)&a && (const char *)a.policy < (const char *)(&a + 1));
    printf("[copies]    OK  values live inside the struct, not in a line buffer\n");
}

int main(void)
{
    test_valid();
    test_missing();
    test_malformed();
    test_copies();
    assert(gw_alloc_live_count() == 0 && gw_alloc_total_count() == 0);
    printf("test_gw_config: all groups passed\n");
    return 0;
}
