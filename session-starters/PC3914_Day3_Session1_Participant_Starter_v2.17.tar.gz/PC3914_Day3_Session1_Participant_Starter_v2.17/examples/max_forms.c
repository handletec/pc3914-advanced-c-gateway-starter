/* max_forms.c — three ways to write "max", and what each one fixes (Day 2 Block 4). */
#include <stdio.h>

#define GW_MAX(a,b) ((a) > (b) ? (a) : (b))       /* parentheses: fixes precedence ONLY */

static inline int gw_max_int(int a, int b)         /* a function: arguments evaluated once, typed */
{
    return a > b ? a : b;
}

int main(void)
{
    int i, x;

    printf("GW_MAX(5, 3) * 2 = %d   (precedence fixed)\n", GW_MAX(5, 3) * 2);

    i = 3;
    x = GW_MAX(i++, 5);                            /* 3 > 5 is false: the second (i++) is never evaluated */
    printf("i = 3; x = GW_MAX(i++, 5) -> x = %d, i = %d   (looks fine)\n", x, i);

    i = 7;
    x = GW_MAX(i++, 5);                            /* 7 > 5 is true: (i++) is evaluated AGAIN */
    printf("i = 7; x = GW_MAX(i++, 5) -> x = %d, i = %d   (expected x = 7, i = 8)\n", x, i);

    i = 7;
    x = gw_max_int(i++, 5);                        /* a function evaluates its arguments exactly once */
    printf("i = 7; x = gw_max_int(i++, 5) -> x = %d, i = %d\n", x, i);
    return 0;
}
