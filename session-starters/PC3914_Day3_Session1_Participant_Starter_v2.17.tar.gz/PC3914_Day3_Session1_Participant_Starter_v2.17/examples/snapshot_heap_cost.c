/* snapshot_heap_cost.c — what the snapshot workload costs if every temporary
 * string and array is an individual heap allocation. Same shape of work as
 * diag_snapshot_build: per 50-event window, 1 module array + up to 8 module
 * lines + up to 8 last-error copies + 1 line array + 50 event lines, all
 * freed before the next window. Build: make demo-heap-cost */
#include "gw_alloc.h"
#include <stdio.h>
#include <string.h>

#define WINDOWS 8
#define EVENTS  50
#define MODULES 4

int main(void)
{
    size_t peak_live = 0;
    for (int w = 0; w < WINDOWS; w++) {
        char  *module_lines[MODULES], *last_error[MODULES];
        char **event_lines = gw_malloc(EVENTS * sizeof *event_lines);
        char  *modules     = gw_malloc(MODULES * 48);
        for (int m = 0; m < MODULES; m++) {
            module_lines[m] = gw_malloc(72);
            last_error[m]   = gw_malloc(16);
            snprintf(module_lines[m], 72, "module %d | events 12 | errors 3 | weakest -113 dBm", m);
            strcpy(last_error[m], "SIM_NOT_READY");
        }
        for (int i = 0; i < EVENTS; i++) {
            event_lines[i] = gw_malloc(48);
            snprintf(event_lines[i], 48, "#%d module 3 SIGNAL -71 dBm CONNECTED", w * EVENTS + i);
        }
        if (gw_alloc_live_count() > peak_live)
            peak_live = gw_alloc_live_count();

        /* emit would happen here; then everything dies together */
        for (int i = 0; i < EVENTS; i++)
            gw_free(event_lines[i]);
        for (int m = 0; m < MODULES; m++) {
            gw_free(module_lines[m]);
            gw_free(last_error[m]);
        }
        gw_free(modules);
        gw_free(event_lines);
    }
    printf("%d windows x %d events on the heap:\n", WINDOWS, EVENTS);
    printf("  %zu malloc calls, %zu free calls, peak live blocks %zu, live at exit %zu\n",
           gw_alloc_total_count(), gw_alloc_total_count() - gw_alloc_live_count(),
           peak_live, gw_alloc_live_count());
    printf("  every block is freed within the window it was created in\n");
    return 0;
}
