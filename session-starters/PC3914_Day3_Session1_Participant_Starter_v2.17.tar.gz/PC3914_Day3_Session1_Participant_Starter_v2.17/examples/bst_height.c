/* bst_height.c — measured degeneration: the same 400 keys inserted in
 * sequence order versus a shuffled order. Build: make demo-bst */
#include "event_bst.h"
#include "event_store.h"
#include "gw_alloc.h"
#include <stdio.h>
#include <string.h>

#define N 400

static event_t *mk(uint32_t id)
{
    event_view_t v = { id, EV_SIGNAL, -70, "CONNECTED", 9 };
    return event_clone(&v);
}

int main(void)
{
    event_store_t *store = event_store_create(N);
    for (uint32_t i = 0; i < N; i++)
        event_store_push(store, mk(i));

    /* 1. keys in arrival order — what the gateway would naturally do */
    event_bst_t seq;
    event_bst_init(&seq);
    for (uint64_t k = 0; k < N; k++)
        event_bst_insert(&seq, k, event_store_get(store, (size_t)k));

    /* 2. the same keys in a fixed pseudo-random order (multiplicative permutation) */
    event_bst_t shuffled;
    event_bst_init(&shuffled);
    for (uint64_t i = 0; i < N; i++) {
        uint64_t k = (i * 263 + 71) % N;                /* 263 is coprime with 400: a permutation */
        event_bst_insert(&shuffled, k, event_store_get(store, (size_t)k));
    }

    printf("%d keys inserted in sequence order:  height %zu (a chain: search walks up to %zu nodes)\n",
           N, event_bst_height(&seq), event_bst_height(&seq));
    printf("%d keys inserted in shuffled order:  height %zu (search walks at most %zu nodes)\n",
           N, event_bst_height(&shuffled), event_bst_height(&shuffled));
    printf("a perfectly balanced tree of %d keys would have height 9\n", N);

    event_bst_destroy(&seq);
    event_bst_destroy(&shuffled);
    event_store_destroy(store);
    printf("heap: %zu live at exit\n", gw_alloc_live_count());
    return 0;
}
