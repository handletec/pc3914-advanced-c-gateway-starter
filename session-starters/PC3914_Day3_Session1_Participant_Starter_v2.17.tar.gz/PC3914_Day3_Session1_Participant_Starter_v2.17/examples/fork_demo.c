/* fork_demo.c — the process model in one screen (Day 3 Block 1, trainer demo).
 *
 *   fork()    both processes continue from the return; the child gets a COPY of
 *             the address space (changing `counter` in one is invisible to the other)
 *             and a COPY of the descriptor table (the same open file, shared offset)
 *   waitpid() the parent reaps the child and reads its exit status
 *   exec()    replaces the child's image; a successful exec never returns */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    int counter = 100;
    int fd = 1;                                 /* stdout: inherited across fork, shared across exec */
    char line[96];

    printf("parent %ld: counter=%d, about to fork\n", (long)getpid(), counter);
    fflush(stdout);                             /* empty stdio buffers BEFORE fork: the child would inherit them */

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {                             /* ---- child ---- */
        counter += 1;                           /* the child's copy only */
        int n = snprintf(line, sizeof line, "child  %ld: counter=%d (my copy), parent is %ld, fd %d inherited\n",
                         (long)getpid(), counter, (long)getppid(), fd);
        write(fd, line, (size_t)n);             /* descriptor layer: the inherited descriptor works as-is */
        execl("/bin/echo", "echo", "child: exec replaced me with /bin/echo; this line is echo's", (char *)NULL);
        write(fd, "child: exec FAILED (only printed when exec returns)\n", 52);
        _exit(127);
    }
    /* ---- parent ---- */
    int status;
    if (waitpid(pid, &status, 0) != pid) {      /* reap: without this the child stays a zombie */
        perror("waitpid");
        return 1;
    }
    printf("parent %ld: counter=%d (unchanged), child %ld exited with status %d\n",
           (long)getpid(), counter, (long)pid, WIFEXITED(status) ? WEXITSTATUS(status) : -1);
    return 0;
}
