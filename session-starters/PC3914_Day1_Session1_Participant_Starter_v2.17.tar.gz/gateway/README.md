# PC3914 Day 1 — Session 1 Participant Entry Snapshot

Simulated engineering project for *Advanced C Programming: From Basic C to Systems-Ready*.
It does not represent any real product's architecture.

```
Simulated Module Events (data/*.txt)
        |
        v
    Event Parser        src/event_parser.c   <- your TODOs live here
        |
        v
 Diagnostic Engine      src/diag_engine.c
        |
        v
  Console Output        src/gateway.c
```

## Build and run

```
make            # builds ./gateway
make run        # ./gateway data/module_events.txt
make test       # parser tests (tests/test_event_parser.c)
make clean
```

Compiler flags: `gcc -std=c11 -Wall -Wextra -Werror -g -O0`. Warnings are errors.

## Record format

```
<module_id> <KIND> <rssi_dbm> <payload>
3 ERROR -113 SIM_NOT_READY
```

Four fields, single spaces, one record per line. KIND is one of
CONNECT, DISCONNECT, SIGNAL, ERROR. The payload is a single token.

## Day 1 morning TODOs

| TODO      | File                 | What                                              | Test group |
|-----------|----------------------|---------------------------------------------------|------------|
| TODO-L1.1 | src/event_parser.c   | Bounded `scan_until`: never read past `end`       | `scan`     |
| TODO-L1.2 | src/event_parser.c   | `split_fields`: reject empty / too few / too many | `fields`   |

Run a single group: `./build/test_event_parser scan`

## Data files

- `data/module_events.txt`   — 12 well-formed records (baseline demo)
- `data/malformed_events.txt` — 7 records, 5 malformed
- `data/truncated_events.txt` — last record has no newline
- `data/burst_events.txt`     — 400 records (> one 4 KiB read chunk)


## Session entry
This archive is the Day 1 Session 1 starting state for material version v2.17. Work only on the current TODOs and verification steps in the Participant Practical Guide.
