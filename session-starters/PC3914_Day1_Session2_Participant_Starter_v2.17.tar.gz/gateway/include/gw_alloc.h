#ifndef GW_ALLOC_H
#define GW_ALLOC_H
#include <stddef.h>

/* Thin wrappers over libc. Same contract as malloc/calloc/realloc/free.
 * Added only so tests can inject allocation failure and count blocks. */
void  *gw_malloc(size_t n);
void  *gw_calloc(size_t count, size_t size);
void  *gw_realloc(void *p, size_t n);
void   gw_free(void *p);

/* Test / measurement hooks */
void   gw_alloc_fail_after(int calls);   /* next `calls` allocations succeed, the one after fails; -1 disables */
size_t gw_alloc_live_count(void);        /* blocks allocated and not yet freed */
size_t gw_alloc_total_count(void);       /* successful allocations since start (realloc-from-NULL counts) */

#endif
