/* Day 1 Session 2 prepared Event Store. Repair only the TODO contracts described by the practical guide. */
#include "event_store.h"
#include "gw_alloc.h"
#include <stdint.h>
/* TODO-D1.2B1: check both allocations and unwind partial construction. */
event_store_t *event_store_create(size_t initial_cap){
    event_store_t *s=gw_malloc(sizeof *s); /* deliberately unchecked starter state */
    s->items=gw_calloc(initial_cap,sizeof *s->items);
    if(!s->items) return NULL;
    s->cap=initial_cap; s->len=0; return s;
}
/* TODO-D1.2B2: guard size arithmetic, grow through a temporary, preserve state/ownership on failure. */
int event_store_push(event_store_t *s,event_t *e){
    if(s->len==s->cap){
        s->items=gw_realloc(s->items,s->cap*2*sizeof *s->items);
        if(!s->items) return -1;
        s->cap*=2;
    }
    s->items[s->len++]=e; return 0;
}
const event_t *event_store_get(const event_store_t *s,size_t i){ return i<s->len?s->items[i]:NULL; }
size_t event_store_len(const event_store_t *s){ return s->len; }
/* TODO-D1.2B3: release owned events before the array/container; accept NULL. */
void event_store_destroy(event_store_t *s){ if(!s) return; gw_free(s->items); gw_free(s); }
