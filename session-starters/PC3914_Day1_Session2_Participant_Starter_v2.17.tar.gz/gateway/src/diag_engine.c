/* Day 1 Session 2 prepared state: retained errors still borrow parser-buffer bytes. */
#include "diag_engine.h"
#include <stdio.h>
#include <string.h>
static struct { size_t total, errors; int16_t weakest_rssi; uint32_t weakest_module; int have_signal; } stats;
static unsigned char seen[DIAG_MAX_MODULES];
static event_view_t last_error[DIAG_MAX_MODULES]; /* TODO-D1.2A: replace borrowed retained views with owned events. */
void diag_init(void){ memset(&stats,0,sizeof stats); memset(seen,0,sizeof seen); memset(last_error,0,sizeof last_error); }
void diag_on_event(const event_view_t *ev){
    printf("[module %u] %-10s %5d dBm  %.*s\n",ev->module_id,event_kind_name(ev->kind),ev->rssi_dbm,(int)ev->payload_len,ev->payload);
    stats.total++; if(ev->kind==EV_ERROR) stats.errors++;
    if(ev->kind==EV_SIGNAL && (!stats.have_signal || ev->rssi_dbm<stats.weakest_rssi)){ stats.weakest_rssi=ev->rssi_dbm; stats.weakest_module=ev->module_id; stats.have_signal=1; }
    if(ev->module_id<DIAG_MAX_MODULES) seen[ev->module_id]=1;
    if(ev->kind==EV_ERROR && ev->module_id<DIAG_MAX_MODULES) last_error[ev->module_id]=*ev; /* pointer copied, bytes not owned */
}
const char *diag_last_error(unsigned id){ return (id<DIAG_MAX_MODULES && last_error[id].payload) ? last_error[id].payload : NULL; }
void diag_report(void){
    unsigned modules=0; for(unsigned i=0;i<DIAG_MAX_MODULES;i++) modules+=seen[i];
    printf("--- diagnostics ---\n"); printf("events: %zu  errors: %zu  modules seen: %u\n",stats.total,stats.errors,modules);
    if(stats.have_signal) printf("weakest signal: module %u at %d dBm\n",stats.weakest_module,stats.weakest_rssi);
    for(unsigned i=0;i<DIAG_MAX_MODULES;i++) if(last_error[i].payload) printf("module %u last error: %.*s\n",i,(int)last_error[i].payload_len,last_error[i].payload);
}
void diag_shutdown(void){ /* TODO-D1.2A: owned retained errors must be released after the activity. */ }
