# PC3914 Day 1 — Session 2 Participant Entry Snapshot

**Course:** PC3914 — Advanced C Programming: From Basic C to Systems-Ready  
**Material version:** v2.17

Session 1 parser contracts are completed in this standalone entry state. Session 2 introduces ownership and retained-storage failure paths.

## Current participant work
- Retain error text across parser-buffer reuse without dangling borrowed views.
- Repair Event Store construction, growth, destruction and failure-path ownership.

## Working rule
Use this session-entry snapshot for the current session and keep your previous work separately. Follow the Participant Practical Guide for the current activity and verification steps.

## Build and verification
Run `make course-status` first, then use the commands in the Participant Practical Guide for the current activity or lab.
