#ifndef WORK_STACK_H
#define WORK_STACK_H
#include "event.h"
#include "gw_status.h"
#include <stddef.h>

/* LIFO work stack of BORROWED event pointers (Day 2 side drill).
 *
 * This is a data structure — an explicit last-in-first-out worklist that
 * lives on the heap and is pushed/popped by our code. It is NOT the C call
 * stack (automatic storage), which the compiler manages for function calls.
 *
 * The stack does not own the events: it holds pointers into a store that
 * outlives it. Destroying the stack frees only its own array.
 * Growable array: contiguous, one realloc per doubling, no per-item node.
 *
 * Uses today: reverse-order trace (most recent first). After the break, the
 * same LIFO access pattern appears in iterative tree traversal; that traversal
 * needs a node-pointer stack, not this event-pointer-specific stack. */

typedef struct {
    const event_t **items;      /* owned array of borrowed pointers */
    size_t          len;
    size_t          cap;
} work_stack_t;

void           work_stack_init(work_stack_t *s);
gw_status_t    work_stack_push(work_stack_t *s, const event_t *e);   /* GW_OK | GW_ENOMEM | GW_EINVAL (NULL e) */
const event_t *work_stack_pop(work_stack_t *s);                      /* NULL when empty (expected) */
int            work_stack_is_empty(const work_stack_t *s);
size_t         work_stack_size(const work_stack_t *s);
void           work_stack_destroy(work_stack_t *s);                  /* frees the array only */

#endif
