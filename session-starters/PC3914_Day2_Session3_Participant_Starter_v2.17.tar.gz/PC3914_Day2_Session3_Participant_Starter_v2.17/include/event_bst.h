#ifndef EVENT_BST_H
#define EVENT_BST_H
#include "event.h"
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Ordered index of retained events by SEQUENCE NUMBER (Day 2 Block 2): "find the event with sequence N; walk events in
 * sequence order".
 *
 * Key: the gateway sequence number = the event's index in event_store_t
 * (assigned in arrival order, unique). No timestamp exists in this project
 * and none is invented. Values are BORROWED const event_t * into the store;
 * the tree owns only its nodes.
 *
 * Ordering invariant (tested): for every node, all keys in the left subtree
 * are < node.key and all keys in the right subtree are > node.key.
 * Duplicate policy: a second insert of an existing key is refused with
 * GW_EEXIST and changes nothing.
 *
 * Known limitation, taught openly: this is a naive BST. Inserting keys in
 * increasing order (exactly what sequence numbers do) produces a chain whose
 * height equals its size, so search degrades to a linear walk. Production
 * ordered indexes need a self-balancing tree or a different structure;
 * neither is implemented here. examples/bst_height.c measures both cases.
 *
 * Traversal uses an explicit node-pointer stack local to this module (NOT
 * work_stack_t, which holds const event_t *), so traversal depth is bounded by
 * heap memory. Destruction itself is allocation-free. */

typedef struct bst_node {
    uint64_t         key;
    const event_t   *value;     /* borrowed */
    struct bst_node *left, *right;
} bst_node_t;

typedef struct {
    bst_node_t *root;
    size_t      count;
} event_bst_t;

typedef void (*bst_visit_t)(uint64_t key, const event_t *value, void *ctx);

void           event_bst_init(event_bst_t *t);
gw_status_t    event_bst_insert(event_bst_t *t, uint64_t key, const event_t *value);  /* GW_OK | GW_EEXIST | GW_ENOMEM | GW_EINVAL */
const event_t *event_bst_search(const event_bst_t *t, uint64_t key);                  /* NULL if absent (expected) */
gw_status_t    event_bst_inorder(const event_bst_t *t, bst_visit_t visit, void *ctx); /* ascending key order; GW_ENOMEM if the traversal stack cannot grow */
gw_status_t    event_bst_height(const event_bst_t *t, size_t *out_height);              /* GW_OK | GW_ENOMEM | GW_EINVAL; no partial height */
size_t         event_bst_count(const event_bst_t *t);
void           event_bst_destroy(event_bst_t *t);                                     /* frees every node; values untouched */

#endif
