/* test_event_bst.c — ordering invariant, search, in-order, duplicates, destroy, degeneration. */
#include "event_bst.h"
#include "event_store.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *mk(uint32_t id)
{
    event_view_t v = { id, EV_SIGNAL, -70, "CONNECTED", 9 };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

/* Ordering invariant: every key in the left subtree < node < every key in the right subtree. */
static void check_node(const bst_node_t *n, uint64_t lo, int has_lo, uint64_t hi, int has_hi, size_t *count)
{
    if (!n)
        return;
    assert(!has_lo || n->key > lo);
    assert(!has_hi || n->key < hi);
    (*count)++;
    check_node(n->left,  lo, has_lo, n->key, 1, count);        /* recursion bounded by tree height (small trees here) */
    check_node(n->right, n->key, 1, hi, has_hi, count);
}
static void check(const event_bst_t *t)
{
    size_t n = 0;
    check_node(t->root, 0, 0, 0, 0, &n);
    assert(n == t->count);
}

static uint64_t seen[64]; static size_t nseen;
static void collect(uint64_t key, const event_t *v, void *ctx)
{
    (void)ctx; (void)v;
    seen[nseen++] = key;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    event_store_t *store = event_store_create(8);
    for (uint32_t i = 0; i < 16; i++)
        assert(event_store_push(store, mk(i)) == 0);
    size_t live = gw_alloc_live_count();

    /* 1. non-monotonic keys: a bushy tree */
    event_bst_t t;
    event_bst_init(&t);
    assert(event_bst_search(&t, 7) == NULL);
    uint64_t keys[] = { 8, 3, 12, 1, 5, 10, 14, 7 };
    for (size_t i = 0; i < 8; i++) {
        assert(event_bst_insert(&t, keys[i], event_store_get(store, (size_t)keys[i])) == GW_OK);
        check(&t);
    }
    size_t height = 0;
    assert(event_bst_height(&t, &height) == GW_OK && height == 4);
    assert(event_bst_count(&t) == 8);
    assert(event_bst_height(&t, NULL) == GW_EINVAL);
    height = 777;
    gw_alloc_fail_after(0);
    assert(event_bst_height(&t, &height) == GW_ENOMEM && height == 777);
    assert(event_bst_insert(&t, 5, event_store_get(store, 5)) == GW_EEXIST);   /* duplicate: refused */
    assert(event_bst_insert(&t, 2, NULL) == GW_EINVAL);
    assert(event_bst_count(&t) == 8);

    assert(event_bst_search(&t, 10) == event_store_get(store, 10));            /* borrowed value */
    assert(event_bst_search(&t, 7)->module_id == 7);
    assert(event_bst_search(&t, 9) == NULL);                                   /* missing: expected */

    nseen = 0;
    assert(event_bst_inorder(&t, collect, NULL) == GW_OK);
    assert(nseen == 8);
    for (size_t i = 1; i < nseen; i++)
        assert(seen[i - 1] < seen[i]);                                         /* sorted ascending */
    assert(seen[0] == 1 && seen[7] == 14);

    /* insert failure leaves the tree unchanged */
    gw_alloc_fail_after(0);
    assert(event_bst_insert(&t, 6, event_store_get(store, 6)) == GW_ENOMEM);
    assert(event_bst_count(&t) == 8 && event_bst_search(&t, 6) == NULL);
    check(&t);

    gw_alloc_fail_after(0);                 /* destroy must not allocate */
    event_bst_destroy(&t);
    gw_alloc_fail_after(-1);                 /* destroy did not consume the injected failure */
    assert(t.root == NULL && t.count == 0);
    assert(gw_alloc_live_count() == live);                                     /* nodes freed, events untouched */

    /* 2. monotonic keys: a chain — height == count */
    event_bst_init(&t);
    for (uint64_t k = 0; k < 16; k++)
        assert(event_bst_insert(&t, k, event_store_get(store, (size_t)k)) == GW_OK);
    check(&t);
    height = 0;
    assert(event_bst_height(&t, &height) == GW_OK && height == 16);             /* degenerate */
    assert(event_bst_search(&t, 15)->module_id == 15);
    nseen = 0;
    assert(event_bst_inorder(&t, collect, NULL) == GW_OK && nseen == 16 && seen[15] == 15);
    gw_alloc_fail_after(0);
    event_bst_destroy(&t);
    gw_alloc_fail_after(-1);
    assert(gw_alloc_live_count() == live);

    event_store_destroy(store);
    assert(gw_alloc_live_count() == 0);
    puts("test_event_bst: OK");
    return 0;
}
