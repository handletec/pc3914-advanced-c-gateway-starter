/* test_registry_opaque.c — proves the representation is hidden.
 * Built twice by `make opaque-check`:
 *   1. normally: must compile and run (uses only the public interface)
 *   2. with -DTRY_PRIVATE: must FAIL to compile — the caller cannot reach
 *      into the registry. A successful compile here means the struct leaked. */
#include "device_registry.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    device_registry_t *r = device_registry_create(8);
    assert(r);
    device_state_t d = { 7, MOD_CONNECTED, -71, 1 };
    assert(device_registry_upsert(r, &d) == GW_OK);
#ifdef TRY_PRIVATE
    r->count = 42;                      /* must not compile once the type is opaque */
#endif
    assert(device_registry_count(r) == 1);
    device_registry_destroy(r);
    assert(gw_alloc_live_count() == 0);
    puts("test_registry_opaque: public interface only — OK");
    return 0;
}
