/* test_alert_heap.c — the heap invariant is inspected, not just the popped order. */
#include "alert_heap.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static alert_t al(uint8_t sev, uint32_t mod, uint64_t seq, const char *code)
{
    alert_t a = { sev, mod, seq, "" };
    strncpy(a.code, code, sizeof a.code - 1);
    return a;
}

/* Structural invariant: every parent outranks (or equals in order) each child. */
static void check(const alert_heap_t *h)
{
    for (size_t i = 1; i < h->len; i++) {
        size_t parent = (i - 1) / 2;
        assert(!alert_outranks(&h->items[i], &h->items[parent])
               && "TODO-D2.5: a child must never outrank its parent");
    }
    assert(h->len <= h->cap);
}

static void test_order(void)
{
    alert_heap_t h;
    alert_heap_init(&h);
    alert_t out;
    assert(alert_heap_pop(&h, &out) == 0);                        /* empty: expected */

    /* arrival order is deliberately NOT priority order */
    assert(alert_heap_push(&h, &(alert_t){0}) == GW_EINVAL);      /* severity 0 rejected */
    size_t reject_len = h.len;
    alert_t invalid_high = al(4, 1, 0, "INVALID");
    assert(alert_heap_push(&h, &invalid_high) == GW_EINVAL);             /* severity 4 rejected */
    assert(h.len == reject_len);                                         /* heap unchanged */
    alert_t in[] = {
        al(1, 5, 1, "DEGRADED"),
        al(3, 3, 2, "SIM_NOT_READY"),
        al(2, 1, 3, "NETWORK_LOST"),
        al(3, 6, 4, "SIM_NOT_READY"),
        al(1, 3, 5, "DEGRADED"),
        al(2, 5, 6, "NETWORK_LOST"),
    };
    for (size_t i = 0; i < 6; i++) {
        assert(alert_heap_push(&h, &in[i]) == GW_OK);
        check(&h);
    }
    assert(alert_heap_size(&h) == 6);
    assert(alert_heap_peek(&h, &out) && out.severity == 3 && out.seq == 2);

    /* popped order: severity descending, then seq ascending (older first) */
    uint64_t expect_seq[] = { 2, 4, 3, 6, 1, 5 };
    for (size_t i = 0; i < 6; i++) {
        assert(alert_heap_pop(&h, &out) == 1);
        check(&h);                                                /* invariant after every pop */
        assert(out.seq == expect_seq[i]);
    }
    assert(alert_heap_pop(&h, &out) == 0 && alert_heap_size(&h) == 0);

    alert_heap_destroy(&h);
    assert(gw_alloc_live_count() == 0);
    puts("[order]     OK");
}

static void test_ties(void)
{
    alert_heap_t h;
    alert_heap_init(&h);
    /* all the same severity, pushed in scrambled seq order */
    uint64_t seqs[] = { 9, 4, 7, 1, 8, 2, 6, 3, 5 };
    for (size_t i = 0; i < 9; i++) {
        alert_t a = al(2, 1, seqs[i], "NETWORK_LOST");
        assert(alert_heap_push(&h, &a) == GW_OK);
        check(&h);
    }
    alert_t out;
    for (uint64_t expect = 1; expect <= 9; expect++) {            /* oldest first, deterministic */
        assert(alert_heap_pop(&h, &out) == 1 && out.seq == expect);
        check(&h);
    }
    alert_heap_destroy(&h);
    assert(gw_alloc_live_count() == 0);
    puts("[ties]      OK");
}

static void test_growth(void)
{
    alert_heap_t h;
    alert_heap_init(&h);
    for (uint64_t s = 0; s < 8; s++) {
        alert_t a = al((uint8_t)(1 + s % 3), 1, s, "X");
        assert(alert_heap_push(&h, &a) == GW_OK);
    }
    assert(h.len == 8 && h.cap == 8);
    size_t live = gw_alloc_live_count();

    gw_alloc_fail_after(0);                                       /* the doubling realloc fails */
    alert_t a = al(3, 9, 100, "SIM_NOT_READY");
    assert(alert_heap_push(&h, &a) == GW_ENOMEM);
    assert(h.len == 8 && h.cap == 8);                             /* heap unchanged */
    check(&h);
    assert(gw_alloc_live_count() == live);

    assert(alert_heap_push(&h, &a) == GW_OK);                     /* retry grows to 16 */
    assert(h.len == 9 && h.cap == 16);
    check(&h);
    alert_t out;
    assert(alert_heap_peek(&h, &out) && out.severity == 3 && out.seq == 2);   /* oldest critical first, not the newest */

    for (int i = 0; i < 200; i++) {
        alert_t b = al((uint8_t)(1 + i % 3), (uint32_t)i, (uint64_t)(200 + i), "Y");
        assert(alert_heap_push(&h, &b) == GW_OK);
    }
    check(&h);
    assert(alert_heap_size(&h) == 209);
    alert_t prev;
    assert(alert_heap_pop(&h, &prev));
    while (alert_heap_pop(&h, &out)) {                            /* monotone non-increasing rank */
        assert(!alert_outranks(&out, &prev));
        check(&h);
        prev = out;
    }
    alert_heap_destroy(&h);
    assert(gw_alloc_live_count() == 0);
    puts("[growth]    OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;
    if (all || !strcmp(g, "order"))  test_order();
    if (all || !strcmp(g, "ties"))   test_ties();
    if (all || !strcmp(g, "growth")) test_growth();
    puts("test_alert_heap: all groups passed");
    return 0;
}
