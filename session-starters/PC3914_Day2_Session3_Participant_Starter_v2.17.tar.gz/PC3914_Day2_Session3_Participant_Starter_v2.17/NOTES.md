# PC3914 Day 2 Notes

Use this file for observations, commands and questions during the current session.
