/* diag_sink_list.c — completed Day 2 Session 1 diagnostic-sink registry. */
#include "diag_sink_list.h"
#include "gw_alloc.h"
#include <string.h>

void diag_sink_list_init(diag_sink_list_t *l)
{
    l->head  = NULL;
    l->count = 0;
}

const diag_sink_t *diag_sink_list_find(const diag_sink_list_t *l, uint32_t id)
{
    for (const diag_sink_t *s = l->head; s; s = s->next)
        if (s->id == id)
            return s;
    return NULL;
}

/* Append at the tail: registration order is notification order later.
 * The registry is short, so walking to the end costs nothing worth a tail pointer. */
gw_status_t diag_sink_list_add(diag_sink_list_t *l, uint32_t id, const char *name)
{
    if (!name || name[0] == '\0')
        return GW_EINVAL;
    if (diag_sink_list_find(l, id))
        return GW_EEXIST;                   /* expected: caller decides */

    diag_sink_t *n = gw_malloc(sizeof *n);
    if (!n)
        return GW_ENOMEM;                   /* list unchanged */
    n->id = id;
    size_t len = strlen(name);
    if (len >= SINK_NAME_MAX)
        len = SINK_NAME_MAX - 1;            /* bounded copy */
    memcpy(n->name, name, len);
    n->name[len] = '\0';
    n->next = NULL;

    diag_sink_t **pp = &l->head;            /* address of the link to update */
    while (*pp)
        pp = &(*pp)->next;                  /* walk to the last link (head, or some ->next) */
    *pp = n;
    l->count++;
    return GW_OK;
}

/* D2.3: unlink by id. `pp` always points at the link that leads to the
 * current node — either l->head or a previous node's ->next — so the head
 * case and the middle case are the same assignment. */
gw_status_t diag_sink_list_remove(diag_sink_list_t *l, uint32_t id)
{
    for (diag_sink_t **pp = &l->head; *pp; pp = &(*pp)->next) {
        if ((*pp)->id == id) {
            diag_sink_t *victim = *pp;
            *pp = victim->next;             /* unlink: the link now skips the victim */
            gw_free(victim);
            l->count--;
            return GW_OK;
        }
    }
    return GW_ENOENT;                       /* expected: list unchanged */
}

size_t diag_sink_list_count(const diag_sink_list_t *l) { return l->count; }

void diag_sink_list_destroy(diag_sink_list_t *l)
{
    diag_sink_t *s = l->head;
    while (s) {
        diag_sink_t *next = s->next;        /* read the link before freeing the node */
        gw_free(s);
        s = next;
    }
    l->head  = NULL;
    l->count = 0;
}
