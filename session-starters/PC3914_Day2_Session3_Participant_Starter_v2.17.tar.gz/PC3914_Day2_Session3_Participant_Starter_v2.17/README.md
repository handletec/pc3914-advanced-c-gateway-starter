# PC3914 Day 2 — Session 3: Opaque Modules and Libraries

This is the participant stage-entry workspace for the current session. It contains the verified Day 2 Session 2 completed state plus the current session's intentionally incomplete work. It contains only the current participant stage-entry source and verification assets.

## First commands

```bash
make course-status
make opaque-check
```

At the untouched starter state, `make opaque-check` intentionally fails because private registry access still compiles. This is the current task boundary, not a broken distribution.

## Current participant work

`TODO-D2.6a/b plus LINK_LAB TODO-L2.1..L2.3`

Use `make checkpoint` to save your own current source before a substantial change. Stage progression is supplied by the course distribution; do not copy source from another stage.
