/* registry_client.c — a consumer of libgateway_core that is NOT the gateway.
 * It uses only public headers: no knowledge of the registry's layout, no
 * parser, no main loop. Build: make client-static / make client-shared */
#include "device_registry.h"
#include "gw_alloc.h"
#include <stdio.h>

static void show(const device_state_t *v, void *ctx)
{
    (void)ctx;
    printf("  module %u  %-12s  %5d dBm  %zu events\n",
           v->module_id, module_state_name(v->state), v->last_rssi, v->event_count);
}

int main(void)
{
    device_registry_t *reg = device_registry_create(4);       /* small: forces one growth */
    if (!reg) {
        fprintf(stderr, "registry_client: cannot create registry\n");
        return 1;
    }

    device_state_t fleet[] = {
        { 3,    MOD_ERROR,        -113, 1 },
        { 11,   MOD_CONNECTED,     -71, 4 },                    /* collides with 3 in a small table */
        { 1024, MOD_DEGRADED,     -101, 2 },
        { 7,    MOD_DISCONNECTED, -100, 9 },
    };
    for (size_t i = 0; i < sizeof fleet / sizeof fleet[0]; i++)
        if (device_registry_upsert(reg, &fleet[i]) != GW_OK)
            fprintf(stderr, "registry_client: upsert %u failed\n", fleet[i].module_id);

    printf("registry_client: %zu devices, capacity %zu\n",
           device_registry_count(reg), device_registry_capacity(reg));
    device_registry_for_each(reg, show, NULL);

    const device_state_t *v = device_registry_find(reg, 11);
    printf("find(11): %s\n", v ? module_state_name(v->state) : "absent");
    printf("find(99): %s\n", device_registry_find(reg, 99) ? "present" : "absent (expected)");

    device_registry_destroy(reg);
    printf("heap: %zu live at exit\n", gw_alloc_live_count());
    return 0;
}
