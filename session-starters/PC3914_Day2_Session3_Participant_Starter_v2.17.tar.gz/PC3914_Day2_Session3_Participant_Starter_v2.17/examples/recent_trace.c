/* recent_trace.c — side drill: print the most recent N events of a file,
 * newest first, using an explicit LIFO work stack of borrowed pointers.
 * Build: make demo-stack    Run: ./build/recent_trace data/module_events.txt 5 */
#include "event_parser.h"
#include "event_store.h"
#include "work_stack.h"
#include "gw_alloc.h"
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static event_store_t *store;

static void on_event(const event_view_t *ev)
{
    event_t *e = event_clone(ev);
    if (e && event_store_push(store, e) != 0)
        event_free(e);
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s <events-file> <count>\n", argv[0]);
        return 2;
    }
    char *endp = NULL;
    errno = 0;
    unsigned long parsed = strtoul(argv[2], &endp, 10);
    if (errno != 0 || endp == argv[2] || *endp != '\0' ||
        argv[2][0] == '-' || parsed > SIZE_MAX) {
        fprintf(stderr, "invalid count: %s\n", argv[2]);
        return 2;
    }
    size_t want = (size_t)parsed;
    FILE *in = fopen(argv[1], "rb");
    if (!in) { perror(argv[1]); return 1; }

    store = event_store_create(16);
    if (!store) { fclose(in); return 1; }

    char buf[4096];
    size_t n = fread(buf, 1, sizeof buf, in);
    fclose(in);
    parse_events(buf, n, on_event);

    /* Push the last `want` events oldest-first; popping yields newest-first. */
    work_stack_t trace;
    work_stack_init(&trace);
    size_t len   = event_store_len(store);
    size_t first = len > want ? len - want : 0;
    for (size_t i = first; i < len; i++)
        if (work_stack_push(&trace, event_store_get(store, i)) != GW_OK) {
            fprintf(stderr, "trace truncated: out of memory\n");
            break;
        }

    printf("most recent %zu of %zu events, newest first:\n", work_stack_size(&trace), len);
    const event_t *e;
    while ((e = work_stack_pop(&trace)) != NULL)
        printf("  module %u %-10s %5d dBm  %s\n",
               e->module_id, event_kind_name(e->kind), e->rssi_dbm, e->payload);

    work_stack_destroy(&trace);             /* frees the array; the store still owns the events */
    event_store_destroy(store);
    printf("heap: %zu live at exit\n", gw_alloc_live_count());
    return 0;
}
