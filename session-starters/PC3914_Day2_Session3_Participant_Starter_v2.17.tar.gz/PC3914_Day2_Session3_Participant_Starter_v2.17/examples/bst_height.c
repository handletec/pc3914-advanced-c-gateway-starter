/* bst_height.c — measured degeneration with checked failure paths. */
#include "event_bst.h"
#include "event_store.h"
#include "gw_alloc.h"
#include <stdio.h>
#include <stdlib.h>

#define N 400

static event_t *mk(uint32_t id)
{
    event_view_t v = { id, EV_SIGNAL, -70, "CONNECTED", 9 };
    return event_clone(&v);
}

static void fail(const char *what)
{
    fprintf(stderr, "bst_height: %s failed\n", what);
    exit(1);
}

int main(void)
{
    event_store_t *store = event_store_create(N);
    if (!store) fail("event_store_create");
    for (uint32_t i = 0; i < N; i++) {
        event_t *e = mk(i);
        if (!e) fail("event_clone");
        if (event_store_push(store, e) != 0) { event_free(e); fail("event_store_push"); }
    }

    event_bst_t seq; event_bst_init(&seq);
    for (uint64_t k = 0; k < N; k++)
        if (event_bst_insert(&seq, k, event_store_get(store, (size_t)k)) != GW_OK) fail("sequence insert");

    event_bst_t shuffled; event_bst_init(&shuffled);
    for (uint64_t i = 0; i < N; i++) {
        uint64_t k = (i * 263 + 71) % N;
        if (event_bst_insert(&shuffled, k, event_store_get(store, (size_t)k)) != GW_OK) fail("shuffled insert");
    }

    size_t seq_h = 0, shuffled_h = 0;
    if (event_bst_height(&seq, &seq_h) != GW_OK) fail("sequence height");
    if (event_bst_height(&shuffled, &shuffled_h) != GW_OK) fail("shuffled height");
    printf("%d keys inserted in sequence order:  height %zu (a chain: search walks up to %zu nodes)\n", N, seq_h, seq_h);
    printf("%d keys inserted in shuffled order:  height %zu (search walks at most %zu nodes)\n", N, shuffled_h, shuffled_h);
    printf("a perfectly balanced tree of %d keys would have height 9\n", N);

    event_bst_destroy(&seq); event_bst_destroy(&shuffled); event_store_destroy(store);
    printf("heap: %zu live at exit\n", gw_alloc_live_count());
    return gw_alloc_live_count() == 0 ? 0 : 1;
}
