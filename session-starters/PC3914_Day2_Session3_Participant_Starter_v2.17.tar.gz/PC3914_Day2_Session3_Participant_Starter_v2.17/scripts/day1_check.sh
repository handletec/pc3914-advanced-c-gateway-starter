#!/bin/sh
# Participant Day 1 regression gate used at Day 2 stage entry.
CC="$1"; CFLAGS="$2"; OUT="$3"
mkdir -p "$OUT"
CORE="src/event_parser.c src/event.c src/gw_alloc.c src/gw_status.c src/event_store.c"
B3="src/arena.c src/diag_snapshot.c"
EXTRA="$(ls src/event_queue.c src/diag_sink_list.c src/device_registry.c src/alert_heap.c src/event_bst.c src/alert_strategy.c src/module_state_machine.c src/gw_trace.c 2>/dev/null | tr '\n' ' ')"
APP="src/gateway.c src/diag_engine.c $EXTRA $B3 $CORE"
pass=0; fail=0
ok(){ pass=$((pass+1)); printf '  PASS      %s\n' "$1"; }
exp(){ pass=$((pass+1)); printf '  EXPECTED  %s\n' "$1"; }
bad(){ fail=$((fail+1)); printf '  FAIL      %s\n' "$1"; }
build(){ name="$1"; shift; if $CC $CFLAGS -o "$OUT/$name" "$@" 2>"$OUT/$name.build.log"; then ok "build $name"; else bad "build $name"; fi; }
run(){ if "$OUT/$1" >"$OUT/$1.log" 2>&1; then ok "$1"; else bad "$1"; fi; }
expect(){ if grep -q -- "$3" "$2"; then ok "$1"; else bad "$1"; fi; }
build test_event_parser tests/test_event_parser.c $CORE
build test_diag tests/test_diag.c src/diag_engine.c $CORE
build test_event_store tests/test_event_store.c $CORE
build test_arena tests/test_arena.c src/arena.c $CORE
build test_snapshot tests/test_snapshot.c $B3 $CORE
build gateway $APP
for t in test_event_parser test_diag test_event_store test_arena test_snapshot; do [ -x "$OUT/$t" ] && run "$t"; done
GW="$OUT/gateway"
if [ -x "$GW" ]; then
  "$GW" data/module_events.txt >"$OUT/valid.log" 2>&1; expect "valid input" "$OUT/valid.log" "parser: 12 events, 0 rejected"; expect "valid heap clean" "$OUT/valid.log" "heap: .* 0 live at exit"
  "$GW" data/malformed_events.txt >"$OUT/malformed.log" 2>&1; if grep -q "parser: 2 events, 5 rejected" "$OUT/malformed.log"; then exp "malformed input handled"; else bad "malformed input"; fi
  "$GW" data/truncated_events.txt >"$OUT/truncated.log" 2>&1; if grep -q "19 bytes of incomplete record" "$OUT/truncated.log" && grep -q "parser: 1 events" "$OUT/truncated.log"; then exp "truncated input handled"; else bad "truncated input"; fi
  "$GW" data/burst_events.txt >"$OUT/burst.log" 2>&1; expect "burst retained" "$OUT/burst.log" "store: 400 retained events"; expect "burst snapshots" "$OUT/burst.log" "snapshots: 8 emitted, 0 skipped"; expect "burst heap clean" "$OUT/burst.log" "heap: .* 0 live at exit"
  "$GW" --arena 2048 data/burst_events.txt >"$OUT/small.log" 2>&1; rc=$?; if [ $rc -eq 0 ] && grep -q "snapshots: 0 emitted, 8 skipped" "$OUT/small.log"; then exp "small arena handled"; else bad "small arena"; fi
  if command -v valgrind >/dev/null 2>&1; then if valgrind -q --leak-check=full --error-exitcode=9 "$GW" data/burst_events.txt >/dev/null 2>"$OUT/valgrind.log"; then ok "valgrind burst clean"; else bad "valgrind burst"; fi; else bad "valgrind not installed"; fi
fi
total=$((pass+fail)); if [ $fail -eq 0 ]; then echo "DAY 1 CHECK: PASS ($pass/$total checks; expected failures handled; final state clean)"; exit 0; else echo "DAY 1 CHECK: FAIL ($fail of $total checks failed)"; exit 1; fi
