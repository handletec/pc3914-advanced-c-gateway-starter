#!/bin/sh
set -eu
printf '%s\n' '== Day 1 participant check =='
make test
./gateway data/module_events.txt >/dev/null
./gateway data/malformed_events.txt >/dev/null
./gateway data/truncated_events.txt >/dev/null
./gateway data/burst_events.txt >/dev/null
if ! command -v valgrind >/dev/null 2>&1; then
  echo 'PENDING    memory-tool checks (valgrind unavailable)'
  echo 'DAY 1 CHECK: PENDING'
  exit 2
fi
valgrind -q --leak-check=full --error-exitcode=9 ./gateway data/burst_events.txt >/dev/null
printf '%s\n' 'PASS       build + unit suites' 'PASS       valid/malformed/truncated/burst scenarios' 'PASS       memory-tool burst run clean' 'DAY 1 CHECK: PASS'
