/* Completed Session 2 Event Store: growable owning container with failure-safe replacement. */
#include "event_store.h"
#include "gw_alloc.h"
#include <stdint.h>
event_store_t *event_store_create(size_t initial_cap){
    event_store_t *s=gw_malloc(sizeof *s); if(!s) return NULL;
    s->items=gw_calloc(initial_cap,sizeof *s->items); if(!s->items){gw_free(s);return NULL;}
    s->cap=initial_cap; s->len=0; return s;
}
int event_store_push(event_store_t *s,event_t *e){
    if(s->len==s->cap){
        size_t new_cap;
        if(s->cap==0) new_cap=8; else { if(s->cap>SIZE_MAX/2) return -1; new_cap=s->cap*2; }
        if(new_cap>SIZE_MAX/sizeof *s->items) return -1;
        event_t **tmp=gw_realloc(s->items,new_cap*sizeof *s->items); if(!tmp) return -1;
        s->items=tmp; s->cap=new_cap;
    }
    s->items[s->len++]=e; return 0;
}
const event_t *event_store_get(const event_store_t *s,size_t i){return i<s->len?s->items[i]:NULL;}
size_t event_store_len(const event_store_t *s){return s->len;}
void event_store_destroy(event_store_t *s){if(!s)return;for(size_t i=0;i<s->len;i++)event_free(s->items[i]);gw_free(s->items);gw_free(s);}
