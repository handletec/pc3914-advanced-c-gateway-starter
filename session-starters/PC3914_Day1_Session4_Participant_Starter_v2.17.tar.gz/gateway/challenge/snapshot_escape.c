/* challenge/snapshot_escape.c — CHALLENGE C.
 * The headline feature as first written. It has ONE regression against the
 * arena lifetime contract. Repair it so headline_text() stays valid after
 * arena_reset(), using a technique already known from Day 1. */
#include "snapshot_escape.h"
#include "gw_alloc.h"
#include <string.h>

struct headline {
    const char *text;           /* points at the snapshot's module line */
    int16_t     rssi;
    int         set;
};

headline_t *headline_create(void)
{
    headline_t *h = gw_malloc(sizeof *h);
    if (!h)
        return NULL;
    h->text = "";
    h->rssi = 0;
    h->set  = 0;
    return h;
}

void headline_update(headline_t *h, const snapshot_t *s)
{
    const snapshot_module_t *worst = NULL;
    for (size_t i = 0; i < s->module_count; i++) {
        const snapshot_module_t *m = &s->modules[i];
        if (m->has_signal && (!worst || m->weakest_rssi < worst->weakest_rssi))
            worst = m;
    }
    if (!worst)
        return;                                 /* no signal report in this window: keep the old headline */

    h->text = worst->line;                      /* remember the line for the final report */
    h->rssi = worst->weakest_rssi;
    h->set  = 1;
}

const char *headline_text(const headline_t *h) { return h->text; }
int16_t     headline_rssi(const headline_t *h) { return h->rssi; }

void headline_destroy(headline_t *h)
{
    gw_free(h);
}
