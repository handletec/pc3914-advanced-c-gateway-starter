/* challenge/gateway_headline.c — completed gateway plus the Challenge C
 * "headline" feature. This file is identical for the defective and repaired
 * builds; the challenge lives in challenge/snapshot_escape.c.
 *
 *   Simulated Module Events (file) -> Event Parser -> Diagnostic Engine -> Console
 *                                                  -> Event Store (owned event_t *)
 *                                                       -> Snapshot (arena, per window)
 *
 * The store keeps every event (independent lifetime, heap). Every
 * SNAPSHOT_EVERY events a temporary snapshot is built in ONE arena, emitted,
 * and released with a single arena_reset(). */
#include "event_parser.h"
#include "event_store.h"
#include "diag_engine.h"
#include "diag_snapshot.h"
#include "arena.h"
#include "gw_alloc.h"
#include "snapshot_escape.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define READ_CHUNK      4096
#define SNAPSHOT_EVERY  50
#define ARENA_DEFAULT   16384

static event_store_t *store;

static void on_event(const event_view_t *ev)
{
    diag_on_event(ev);                          /* engine sees the borrowed view */

    event_t *e = event_clone(ev);               /* retain an owned copy */
    if (!e) {
        fprintf(stderr, "warning: event dropped (out of memory)\n");
        return;
    }
    if (event_store_push(store, e) != 0) {      /* store unchanged; we still own e */
        fprintf(stderr, "warning: event dropped (store full)\n");
        event_free(e);
    }
}

static void usage(const char *prog)
{
    fprintf(stderr, "usage: %s [--arena BYTES] <events-file>\n", prog);
}

int main(int argc, char **argv)
{
    size_t arena_bytes = ARENA_DEFAULT;
    int argi = 1;
    if (argc >= 3 && strcmp(argv[1], "--arena") == 0) {
        char *endp;
        errno = 0;                                          /* POSIX errno: library boundary */
        unsigned long v = strtoul(argv[2], &endp, 10);
        if (errno != 0 || *endp != '\0' || v == 0) {
            usage(argv[0]);
            return 2;
        }
        arena_bytes = (size_t)v;
        argi = 3;
    }
    if (argc != argi + 1) {
        usage(argv[0]);
        return 2;
    }

    FILE *in = fopen(argv[argi], "rb");
    if (!in) {
        perror(argv[argi]);                                 /* errno -> message at the boundary */
        return 1;
    }

    store = event_store_create(64);
    if (!store) {
        fprintf(stderr, "error: cannot create event store\n");
        fclose(in);
        return 1;
    }
    arena_t arena;
    gw_status_t st = arena_init(&arena, arena_bytes);       /* project status code */
    if (st != GW_OK) {
        fprintf(stderr, "error: arena_init(%zu): %s\n", arena_bytes, gw_strstatus(st));
        event_store_destroy(store);
        fclose(in);
        return 1;
    }
    diag_init();
    headline_t *headline = headline_create();
    if (!headline) {
        fprintf(stderr, "error: cannot create headline\n");
        arena_destroy(&arena);
        event_store_destroy(store);
        fclose(in);
        return 1;
    }

    char   buf[READ_CHUNK];
    size_t held = 0;
    parse_result_t total = { 0, 0, 0 };
    size_t reported = 0, snapshots = 0, skipped = 0, arena_peak = 0;
    int rc = 0;

    for (;;) {
        size_t n = fread(buf + held, 1, sizeof buf - held, in);
        if (n == 0)
            break;
        held += n;

        parse_result_t r = parse_events(buf, held, on_event);
        total.events   += r.events;
        total.rejected += r.rejected;
        memmove(buf, buf + r.consumed, held - r.consumed);
        held -= r.consumed;
        if (held == sizeof buf) {
            fprintf(stderr, "error: record longer than %d bytes\n", READ_CHUNK);
            rc = 1;
            break;
        }

        /* L3.2c: snapshot cycle — build, emit, release the whole batch */
        while (event_store_len(store) - reported >= SNAPSHOT_EVERY) {
            snapshot_t snap;
            size_t first = reported, last = reported + SNAPSHOT_EVERY;
            st = diag_snapshot_build(store, first, last, &arena, &snap);
            if (st == GW_OK) {
                diag_snapshot_emit(&snap, stdout);
                headline_update(headline, &snap);   /* before the reset, as the contract requires */
                snapshots++;
            } else {
                fprintf(stderr, "snapshot %zu..%zu skipped: %s (arena %zu/%zu bytes)\n",
                        first, last, gw_strstatus(st), arena_used(&arena), arena.capacity);
                skipped++;
            }
            if (arena_used(&arena) > arena_peak)
                arena_peak = arena_used(&arena);
            arena_reset(&arena);            /* snap and everything it points to is now invalid */
            reported = last;
        }
    }
    fclose(in);

    if (held > 0 && rc == 0)
        fprintf(stderr, "warning: %zu bytes of incomplete record at end of input\n", held);

    diag_report();
    printf("parser: %zu events, %zu rejected\n", total.events, total.rejected);
    printf("store: %zu retained events\n", event_store_len(store));
    printf("snapshots: %zu emitted, %zu skipped, arena peak %zu of %zu bytes\n",
           snapshots, skipped, arena_peak, arena.capacity);
    /* bounded print: the text must never be longer than HEADLINE_MAX - 1 */
    printf("headline: %.*s\n", HEADLINE_MAX - 1, headline_text(headline));

    headline_destroy(headline);
    diag_shutdown();
    arena_destroy(&arena);
    event_store_destroy(store);
    store = NULL;
    printf("heap: %zu new blocks, %zu live at exit\n",
           gw_alloc_total_count(), gw_alloc_live_count());
    return rc;
}
