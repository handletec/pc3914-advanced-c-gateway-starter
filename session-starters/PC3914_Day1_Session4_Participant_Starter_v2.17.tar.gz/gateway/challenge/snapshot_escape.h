#ifndef SNAPSHOT_ESCAPE_H
#define SNAPSHOT_ESCAPE_H
#include "diag_snapshot.h"

/* "Headline": the gateway remembers the summary line of the weakest-signal
 * module from the most recent snapshot and prints it in the final report.
 *
 * Contract: headline_update() may be called once per snapshot window, BEFORE
 * the arena is reset. The text returned by headline_text() must remain valid
 * across arena_reset() and until headline_destroy(). */
#define HEADLINE_MAX 160        /* the module summary line is formatted in a 160-byte buffer */

typedef struct headline headline_t;

headline_t *headline_create(void);                            /* NULL on allocation failure */
void        headline_update(headline_t *h, const snapshot_t *s);
const char *headline_text(const headline_t *h);               /* "" until the first update */
int16_t     headline_rssi(const headline_t *h);
void        headline_destroy(headline_t *h);                  /* accepts NULL */

#endif
