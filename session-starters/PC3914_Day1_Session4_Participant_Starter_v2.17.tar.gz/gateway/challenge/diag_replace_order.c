/* challenge/diag_replace_order.c — CHALLENGE B. A copy of the completed engine
 * with ONE regression in the last-error replacement. Repair it. */
#include "diag_engine.h"
#include <stdio.h>
#include <string.h>

static struct {
    size_t   total;
    size_t   errors;
    int16_t  weakest_rssi;
    uint32_t weakest_module;
    int      have_signal;
} stats;

static unsigned char seen[DIAG_MAX_MODULES];
static event_t      *last_error[DIAG_MAX_MODULES];     /* owned clones, or NULL */

void diag_init(void)
{
    memset(&stats, 0, sizeof stats);
    memset(seen, 0, sizeof seen);
    for (unsigned i = 0; i < DIAG_MAX_MODULES; i++)
        last_error[i] = NULL;
}

void diag_on_event(const event_view_t *ev)
{
    /* payload is not NUL-terminated: print exactly payload_len bytes */
    printf("[module %u] %-10s %5d dBm  %.*s\n",
           ev->module_id, event_kind_name(ev->kind), ev->rssi_dbm,
           (int)ev->payload_len, ev->payload);

    stats.total++;
    if (ev->kind == EV_ERROR)
        stats.errors++;
    if (ev->kind == EV_SIGNAL &&
        (!stats.have_signal || ev->rssi_dbm < stats.weakest_rssi)) {
        stats.weakest_rssi   = ev->rssi_dbm;
        stats.weakest_module = ev->module_id;
        stats.have_signal    = 1;
    }
    if (ev->module_id < DIAG_MAX_MODULES)
        seen[ev->module_id] = 1;

    if (ev->kind != EV_ERROR || ev->module_id >= DIAG_MAX_MODULES)
        return;

    event_free(last_error[ev->module_id]);      /* release the previous error first */
    last_error[ev->module_id] = event_clone(ev);/* NULL when the clone fails */
}

const char *diag_last_error(unsigned id)
{
    if (id >= DIAG_MAX_MODULES || !last_error[id])
        return NULL;
    return last_error[id]->payload;             /* borrowed: valid until replaced/shutdown */
}

void diag_report(void)
{
    unsigned modules = 0;
    for (unsigned i = 0; i < DIAG_MAX_MODULES; i++)
        modules += seen[i];

    printf("--- diagnostics ---\n");
    printf("events: %zu  errors: %zu  modules seen: %u\n",
           stats.total, stats.errors, modules);
    if (stats.have_signal)
        printf("weakest signal: module %u at %d dBm\n",
               stats.weakest_module, stats.weakest_rssi);
    for (unsigned i = 0; i < DIAG_MAX_MODULES; i++)
        if (last_error[i])
            printf("module %u last error: %s\n", i, last_error[i]->payload);
}

void diag_shutdown(void)
{
    for (unsigned i = 0; i < DIAG_MAX_MODULES; i++) {
        event_free(last_error[i]);
        last_error[i] = NULL;
    }
}
