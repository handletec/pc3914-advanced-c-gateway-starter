/* test_scan_order.c — CHALLENGE A evidence.
 * The scan must never read the byte AT `end`. The input buffer is an
 * exactly-sized heap block, so a read at buf[len] is one byte past the block:
 * invisible to a plain run (the function still returns the right pointer),
 * visible to valgrind as "Invalid read of size 1 ... 0 bytes after a block".
 * Run: valgrind --error-exitcode=9 ./build/challenge_scan_order */
#include "event_parser.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void cb(const event_view_t *ev) { (void)ev; }

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    /* 1. a record with no terminating newline, in a block of exactly len bytes */
    static const char text[] = "3 SIGNAL -71 CONNEC";
    size_t len = sizeof text - 1;
    char *buf = gw_malloc(len);
    assert(buf);
    memcpy(buf, text, len);

    const char *r = scan_until(buf, buf + len, '\n');
    assert(r == buf + len);                       /* correct value even when the read is wrong */

    parse_result_t pr = parse_events(buf, len, cb);
    assert(pr.events == 0 && pr.consumed == 0);   /* unterminated: nothing consumed */

    /* 2. the delimiter in the last byte: must be found without touching buf[len] */
    buf[len - 1] = ' ';
    assert(scan_until(buf, buf + len, ' ') == buf + 1);
    assert(scan_until(buf + 13, buf + len, ' ') == buf + len - 1);   /* from "CONNE " */

    /* 3. empty range: no byte may be read at all */
    assert(scan_until(buf + len, buf + len, ' ') == buf + len);

    gw_free(buf);
    assert(gw_alloc_live_count() == 0);
    puts("test_scan_order: values OK (run under valgrind for the access evidence)");
    return 0;
}
