/* test_snapshot_escape.c — CHALLENGE C evidence.
 * The headline must stay valid after arena_reset(). The arena's backing block
 * is still allocated, so valgrind sees nothing; a behavioural check after the
 * reset (and the debug poison) exposes the escaped pointer. */
#include "snapshot_escape.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static event_t *mk(uint32_t id, event_kind_t k, int16_t rssi, const char *payload)
{
    event_view_t v = { id, k, rssi, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    event_store_t *store = event_store_create(8);
    assert(store);
    /* window 1: module 3 is the weakest */
    assert(event_store_push(store, mk(3, EV_SIGNAL, -113, "DEGRADED"))  == 0);
    assert(event_store_push(store, mk(1, EV_SIGNAL,  -60, "CONNECTED")) == 0);
    /* window 2: module 1 is the weakest, module 3 is fine */
    assert(event_store_push(store, mk(1, EV_SIGNAL,  -99, "DEGRADED"))  == 0);
    assert(event_store_push(store, mk(3, EV_SIGNAL,  -55, "CONNECTED")) == 0);

    arena_t arena;
    assert(arena_init(&arena, 4096) == GW_OK);
    headline_t *h = headline_create();
    assert(h);

    /* window 1 */
    snapshot_t s;
    assert(diag_snapshot_build(store, 0, 2, &arena, &s) == GW_OK);
    headline_update(h, &s);
    assert(headline_rssi(h) == -113);
    assert(strncmp(headline_text(h), "module 3 |", 10) == 0);
    arena_reset(&arena);                                    /* everything in s is now invalid */

    /* the headline must still say what it said before the reset */
    assert(strncmp(headline_text(h), "module 3 |", 10) == 0
           && "CHALLENGE C: headline text must survive arena_reset()");

    /* window 2 overwrites the same arena bytes with different text */
    assert(diag_snapshot_build(store, 2, 4, &arena, &s) == GW_OK);
    assert(strncmp(headline_text(h), "module 3 |", 10) == 0);   /* still window 1's headline */
    headline_update(h, &s);
    assert(headline_rssi(h) == -99);
    assert(strncmp(headline_text(h), "module 1 |", 10) == 0);
    arena_reset(&arena);
    assert(strstr(headline_text(h), "weakest -99 dBm") != NULL);

    /* the store was never touched by any of this */
    assert(strcmp(event_store_get(store, 0)->payload, "DEGRADED") == 0);

    headline_destroy(h);
    arena_destroy(&arena);
    event_store_destroy(store);
    assert(gw_alloc_live_count() == 0);
    puts("test_snapshot_escape: OK");
    return 0;
}
