/* test_diag_replace_order.c — CHALLENGE B evidence.
 * Retained diagnostic state must survive an EXPECTED allocation failure.
 * Valgrind is clean either way; the contract violation is state loss. */
#include "diag_engine.h"
#include "event_parser.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void read_cycle(const char *text)
{
    static char buf[256];
    strncpy(buf, text, sizeof buf - 1);
    buf[sizeof buf - 1] = '\0';
    parse_events(buf, strlen(buf), diag_on_event);
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    diag_init();

    read_cycle("5 ERROR -101 NETWORK_LOST\n");
    assert(diag_last_error(5) && strcmp(diag_last_error(5), "NETWORK_LOST") == 0);
    size_t live = gw_alloc_live_count();

    /* the next clone fails: an expected failure, not a bug */
    gw_alloc_fail_after(0);
    read_cycle("5 ERROR -113 SIM_NOT_READY\n");

    const char *kept = diag_last_error(5);
    assert(kept != NULL
           && "CHALLENGE B: the previous error must survive an expected allocation failure");
    assert(strcmp(kept, "NETWORK_LOST") == 0);
    assert(gw_alloc_live_count() == live);        /* nothing leaked, nothing lost */

    /* a later successful replacement still works and still leaks nothing */
    read_cycle("5 ERROR -113 SIM_NOT_READY\n");
    assert(strcmp(diag_last_error(5), "SIM_NOT_READY") == 0);
    assert(gw_alloc_live_count() == live);

    diag_shutdown();
    assert(gw_alloc_live_count() == 0);
    puts("test_diag_replace_order: OK");
    return 0;
}
