# PC3914 Day 1 — Session 4 Participant Entry Snapshot

**Course:** PC3914 — Advanced C Programming: From Basic C to Systems-Ready  
**Material version:** v2.17

Sessions 1–3 are completed in this standalone entry state. Session 4 applies regression pressure to those established contracts.

## Current participant work
- Challenge A: bounded traversal ordering.
- Challenge B: preserve retained state on expected allocation failure.
- Challenge C: persistent state must not retain an arena pointer across reset.
- Run the cumulative Day 1 gate after completing the challenges.

## Working rule
Use this session-entry snapshot for the current session and keep your previous work separately. Follow the Participant Practical Guide for the current activity and verification steps.

## Build and verification
Run `make course-status` first, then use the commands in the Participant Practical Guide for the current activity or lab.
