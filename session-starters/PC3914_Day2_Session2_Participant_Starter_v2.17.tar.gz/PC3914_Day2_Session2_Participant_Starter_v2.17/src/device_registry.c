/* device_registry.c — open-addressing hash table, linear probing (Day 2 Block 2). Participants complete TODO-D2.4 in find_slot. */
#include "device_registry.h"
#include "gw_alloc.h"
#include <stdint.h>
#include <string.h>

/* Deliberately simple multiplicative hash. With a power-of-two capacity,
 * % capacity ultimately selects low bits, so ids separated by the capacity
 * can share a home slot. Probing provides correctness; hash quality affects
 * clustering and probe length, not correctness. */
static size_t hash_id(uint32_t id)
{
    return (size_t)(id * 2654435761u);
}

size_t device_registry_home_slot(const device_registry_t *r, uint32_t id)
{
    return hash_id(id) % r->capacity;
}

const char *module_state_name(module_state_t s)
{
    switch (s) {
    case MOD_UNKNOWN:      return "UNKNOWN";
    case MOD_CONNECTED:    return "CONNECTED";
    case MOD_DEGRADED:     return "DEGRADED";
    case MOD_DISCONNECTED: return "DISCONNECTED";
    case MOD_ERROR:        return "ERROR";
    }
    return "?";
}

gw_status_t device_registry_init(device_registry_t *r, size_t initial_capacity)
{
    r->slots = NULL;
    r->capacity = 0;
    r->count = 0;
    if (initial_capacity == 0)
        return GW_EINVAL;
    r->slots = gw_calloc(initial_capacity, sizeof *r->slots);   /* all EMPTY */
    if (!r->slots)
        return GW_ENOMEM;
    r->capacity = initial_capacity;
    return GW_OK;
}

/* TODO-D2.4: linear probing.
 * This version looks ONLY at the home slot. Two ids that hash to the same
 * slot therefore overwrite each other and the second is never found.
 * Required: starting at the home slot, step to (i + 1) % capacity until the
 * slot is EMPTY (not used) or holds `id`; return that index. Bound the loop
 * by capacity and return r->capacity if every slot was probed (cannot
 * happen while the load rule holds, but the loop must still terminate). */
static size_t find_slot(const device_registry_t *r, uint32_t id)
{
    return device_registry_home_slot(r, id);
}

/* Re-insert every entry into a new, larger array. */
static size_t max_load_count(size_t capacity)
{
    size_t q = capacity / 4;
    size_t rem = capacity % 4;
    return q * 3 + (rem * 3) / 4;   /* floor(3 * capacity / 4) */
}

static gw_status_t grow(device_registry_t *r)
{
    if (r->capacity > SIZE_MAX / 2)
        return GW_ENOMEM;
    size_t new_cap = r->capacity * 2;
    if (new_cap > SIZE_MAX / sizeof *r->slots)
        return GW_ENOMEM;
    registry_slot_t *new_slots = gw_calloc(new_cap, sizeof *new_slots);
    if (!new_slots)
        return GW_ENOMEM;                               /* old table untouched */

    device_registry_t fresh = { new_slots, new_cap, 0 };
    for (size_t i = 0; i < r->capacity; i++) {
        if (!r->slots[i].used)
            continue;
        size_t j = find_slot(&fresh, r->slots[i].value.module_id);
        fresh.slots[j].used  = 1;
        fresh.slots[j].value = r->slots[i].value;
        fresh.count++;
    }
    gw_free(r->slots);
    *r = fresh;
    return GW_OK;
}

gw_status_t device_registry_upsert(device_registry_t *r, const device_state_t *v)
{
    size_t i = find_slot(r, v->module_id);
    if (i < r->capacity && r->slots[i].used) {          /* update in place */
        r->slots[i].value = *v;
        return GW_OK;
    }
    /* new id: keep load <= 3/4 (count + 1) * 4 <= capacity * 3 */
    if (r->count >= max_load_count(r->capacity)) {
        gw_status_t st = grow(r);
        if (st != GW_OK)
            return st;                                  /* registry unchanged */
        i = find_slot(r, v->module_id);                 /* slots moved: probe again */
    }
    r->slots[i].used  = 1;
    r->slots[i].value = *v;
    r->count++;
    return GW_OK;
}

const device_state_t *device_registry_find(const device_registry_t *r, uint32_t id)
{
    size_t i = find_slot(r, id);
    if (i < r->capacity && r->slots[i].used)
        return &r->slots[i].value;
    return NULL;                                        /* absent: expected */
}

size_t device_registry_count(const device_registry_t *r) { return r->count; }

void device_registry_destroy(device_registry_t *r)
{
    gw_free(r->slots);
    r->slots = NULL;
    r->capacity = 0;
    r->count = 0;
}
