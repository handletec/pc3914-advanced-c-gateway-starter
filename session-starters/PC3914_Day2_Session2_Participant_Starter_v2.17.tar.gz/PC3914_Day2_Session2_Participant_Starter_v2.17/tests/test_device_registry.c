/* test_device_registry.c — executable invariants of the device-state registry. */
#include "device_registry.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static size_t max_load_count(size_t capacity)
{
    size_t q = capacity / 4;
    size_t rem = capacity % 4;
    return q * 3 + (rem * 3) / 4;
}

static device_state_t dev(uint32_t id, module_state_t st, int16_t rssi, size_t n)
{
    device_state_t d = { id, st, rssi, n };
    return d;
}

/* Structural invariant: count equals used slots; every stored id is findable. */
static void check(const device_registry_t *r)
{
    size_t used = 0;
    for (size_t i = 0; i < r->capacity; i++) {
        if (!r->slots[i].used)
            continue;
        used++;
        const device_state_t *v = device_registry_find(r, r->slots[i].value.module_id);
        assert(v == &r->slots[i].value);                          /* found at its own slot */
    }
    assert(used == r->count);
    assert(r->count <= max_load_count(r->capacity));                 /* load rule */
}

/* Find a second id whose home slot equals id_a's: a REAL collision for this
 * hash and capacity, computed rather than assumed. */
static uint32_t colliding_id(const device_registry_t *r, uint32_t a)
{
    size_t home = device_registry_home_slot(r, a);
    for (uint32_t b = a + 1; b < a + 100000; b++)
        if (device_registry_home_slot(r, b) == home)
            return b;
    assert(0 && "no collision found in range");
    return 0;
}

static void test_basic(void)
{
    device_registry_t r;
    assert(device_registry_init(&r, 0) == GW_EINVAL);
    assert(device_registry_init(&r, 8) == GW_OK);
    check(&r);

    assert(device_registry_find(&r, 3) == NULL);                  /* empty lookup: expected */

    device_state_t d = dev(3, MOD_CONNECTED, -90, 1);
    assert(device_registry_upsert(&r, &d) == GW_OK);
    assert(device_registry_count(&r) == 1);
    const device_state_t *v = device_registry_find(&r, 3);
    assert(v && v->state == MOD_CONNECTED && v->last_rssi == -90 && v->event_count == 1);
    check(&r);

    d = dev(3, MOD_ERROR, -113, 2);                               /* update existing id */
    assert(device_registry_upsert(&r, &d) == GW_OK);
    assert(device_registry_count(&r) == 1);                       /* still one entry */
    v = device_registry_find(&r, 3);
    assert(v && v->state == MOD_ERROR && v->event_count == 2);
    assert(device_registry_find(&r, 4) == NULL);                  /* missing lookup */
    check(&r);

    device_registry_destroy(&r);
    assert(gw_alloc_live_count() == 0);
    puts("[basic]     OK");
}

static void test_collision(void)
{
    device_registry_t r;
    assert(device_registry_init(&r, 8) == GW_OK);

    uint32_t a = 3, b = colliding_id(&r, 3);
    assert(device_registry_home_slot(&r, a) == device_registry_home_slot(&r, b));

    device_state_t da = dev(a, MOD_CONNECTED, -70, 1);
    device_state_t db = dev(b, MOD_DEGRADED,  -99, 5);
    assert(device_registry_upsert(&r, &da) == GW_OK);
    assert(device_registry_upsert(&r, &db) == GW_OK);
    assert(device_registry_count(&r) == 2
           && "TODO-D2.4: a colliding id must be probed to the next free slot, not overwrite");

    const device_state_t *va = device_registry_find(&r, a);
    const device_state_t *vb = device_registry_find(&r, b);
    assert(va && va->module_id == a && va->state == MOD_CONNECTED);   /* both survive */
    assert(vb && vb->module_id == b && vb->state == MOD_DEGRADED);
    assert(va != vb);
    check(&r);

    /* updating one of the colliding pair changes only that one */
    db.event_count = 6;
    assert(device_registry_upsert(&r, &db) == GW_OK);
    assert(device_registry_find(&r, a)->event_count == 1);
    assert(device_registry_find(&r, b)->event_count == 6);
    assert(device_registry_count(&r) == 2);

    /* a third id on the same home slot, and a miss that must walk past both */
    uint32_t c = colliding_id(&r, b);
    device_state_t dc = dev(c, MOD_DISCONNECTED, -101, 9);
    assert(device_registry_upsert(&r, &dc) == GW_OK);
    assert(device_registry_count(&r) == 3);
    assert(device_registry_find(&r, c)->state == MOD_DISCONNECTED);
    assert(device_registry_find(&r, 999999) == NULL);
    check(&r);

    device_registry_destroy(&r);
    assert(gw_alloc_live_count() == 0);
    puts("[collision] OK");
}

static void test_growth(void)
{
    device_registry_t r;
    assert(device_registry_init(&r, 4) == GW_OK);
    size_t live = gw_alloc_live_count();

    /* 4 slots hold at most 3 entries; the 4th insert must double the table */
    for (uint32_t id = 100; id < 103; id++) {
        device_state_t d = dev(id, MOD_CONNECTED, -80, id);
        assert(device_registry_upsert(&r, &d) == GW_OK);
    }
    assert(r.capacity == 4 && r.count == 3);
    check(&r);

    gw_alloc_fail_after(0);                                       /* growth allocation fails */
    device_state_t d = dev(103, MOD_CONNECTED, -80, 103);
    assert(device_registry_upsert(&r, &d) == GW_ENOMEM);
    assert(r.capacity == 4 && r.count == 3);                      /* unchanged, still usable */
    assert(device_registry_find(&r, 101)->event_count == 101);
    assert(gw_alloc_live_count() == live);

    assert(device_registry_upsert(&r, &d) == GW_OK);              /* retry: grows to 8 */
    assert(r.capacity == 8 && r.count == 4);
    for (uint32_t id = 100; id < 104; id++)                       /* every entry re-hashed and found */
        assert(device_registry_find(&r, id) && device_registry_find(&r, id)->event_count == id);
    check(&r);

    for (uint32_t id = 200; id < 260; id++) {                     /* many keys, several doublings */
        device_state_t e = dev(id, MOD_DEGRADED, -95, id);
        assert(device_registry_upsert(&r, &e) == GW_OK);
    }
    assert(r.count == 64 && r.capacity == 128);
    for (uint32_t id = 200; id < 260; id++)
        assert(device_registry_find(&r, id)->event_count == id);
    check(&r);
    assert(gw_alloc_live_count() == live);                        /* one array, old ones freed */

    device_registry_destroy(&r);
    assert(gw_alloc_live_count() == 0);
    puts("[growth]    OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;
    if (all || !strcmp(g, "basic"))     test_basic();
    if (all || !strcmp(g, "collision")) test_collision();
    if (all || !strcmp(g, "growth"))    test_growth();
    puts("test_device_registry: all groups passed");
    return 0;
}
