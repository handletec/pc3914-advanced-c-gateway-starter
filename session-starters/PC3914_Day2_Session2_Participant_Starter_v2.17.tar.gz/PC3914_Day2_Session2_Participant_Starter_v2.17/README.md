# PC3914 Day 2 — Session 2: Non-Linear Structures and Invariants

This is the participant stage-entry workspace for the current session. It contains the verified Day 2 Session 1 completed state plus the current session's intentionally incomplete work. It contains only the current participant stage-entry source and verification assets.

## First commands

```bash
make course-status
make test-day2-block2
```

At the untouched starter state, `make test-day2-block2` intentionally stops at TODO-D2.4 collision assertion. This is the current task boundary, not a broken distribution.

## Current participant work

`TODO-D2.4, TODO-D2.5`

Use `make checkpoint` to save your own current source before a substantial change. Stage progression is supplied by the course distribution; do not copy source from another stage.
