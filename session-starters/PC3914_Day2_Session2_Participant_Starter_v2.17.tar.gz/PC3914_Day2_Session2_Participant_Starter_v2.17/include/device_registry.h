#ifndef DEVICE_REGISTRY_H
#define DEVICE_REGISTRY_H
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Device-state registry (Day 2 Block 2): "what is the current state of
 * module X?"  Keyed by module_id, values stored BY VALUE.
 *
 * Why a hash table and not an array indexed by id: module ids in this
 * scenario are sparse and not bounded by a small maximum (a fleet may use
 * ids in the thousands or from a wide identifier space), so a direct array
 * would either waste space or impose an arbitrary limit. If ids were small,
 * dense and bounded — e.g. slot numbers 0..7 — a plain array would be the
 * simpler and better choice.
 *
 * Collision strategy: open addressing with linear probing.
 *   slot = hash(id) % capacity; on collision try slot+1, slot+2, ... (wrap).
 *   Lookup stops at the matching id or at the first EMPTY slot.
 * There is no removal in this block, so no tombstones are needed; adding
 * removal would require them (a "deleted" marker that lookup skips).
 * Growth: when count would exceed 3/4 of capacity the table doubles and
 * every entry is re-inserted (re-hashed) into the new array.
 *
 * Invariants (tested)
 *   every stored id is found again at its probe sequence
 *   inserting/updating one id changes no other entry
 *   count == number of USED slots; count * 4 <= capacity * 3 after upsert
 *   capacity > 0 and a probe never loops forever (bounded by capacity) */

typedef enum {
    MOD_UNKNOWN = 0,
    MOD_CONNECTED,
    MOD_DEGRADED,
    MOD_DISCONNECTED,
    MOD_ERROR
} module_state_t;

typedef struct {
    uint32_t       module_id;
    module_state_t state;
    int16_t        last_rssi;
    size_t         event_count;
} device_state_t;

typedef struct {
    int            used;          /* 0 = EMPTY, 1 = holds a value */
    device_state_t value;
} registry_slot_t;

typedef struct {
    registry_slot_t *slots;       /* owned array, capacity entries */
    size_t           capacity;
    size_t           count;
} device_registry_t;

gw_status_t device_registry_init(device_registry_t *r, size_t initial_capacity); /* GW_EINVAL (0) | GW_ENOMEM */

/* Insert or update the entry for v->module_id. GW_ENOMEM if growth was
 * needed and failed: the registry is unchanged and still usable. */
gw_status_t device_registry_upsert(device_registry_t *r, const device_state_t *v);

/* Borrowed pointer to the stored value, or NULL if the id is absent (expected).
 * Valid only until the next upsert — growth moves every entry. */
const device_state_t *device_registry_find(const device_registry_t *r, uint32_t id);

size_t      device_registry_count(const device_registry_t *r);
void        device_registry_destroy(device_registry_t *r);

/* Exposed for tests and teaching: the home slot of an id (before probing). */
size_t      device_registry_home_slot(const device_registry_t *r, uint32_t id);
const char *module_state_name(module_state_t s);

#endif
