/* inline_asm_demo.c — where portable C deliberately ends (Day 3 Block 4).
 *
 * ONE tiny platform-specific island: read the CPU's cycle/tick counter.
 * Everything around it is portable C; the island is guarded, has a portable
 * fallback, and is small enough to audit in ten seconds.
 *
 *   portable application C
 *     -> hardware abstraction boundary   (read_cycle_counter(), this file)
 *       -> tiny compiler/platform-specific implementation   (the asm below)
 *         -> device/register/instruction  (RDTSC / CNTVCT_EL0)
 *
 * What this demo is NOT:
 *   - it is NOT synchronization. `volatile`, inline asm and raw counters do
 *     not order memory between threads; C atomics and mutexes do that.
 *   - it is NOT a benchmark harness. Tick rates vary, cores migrate,
 *     frequencies scale; the delta below is an illustration, not a metric.
 *
 * build: gcc -std=c11 -Wall -Wextra -Werror -g -O0 -o build/inline_asm_demo \
 *            examples/inline_asm_demo.c
 */
#include <stdint.h>
#include <stdio.h>

/* The boundary function: callers see portable C and never know which branch
 * they got. Keep nonportable code tiny, explicit and surrounded by portable C. */
static inline uint64_t read_cycle_counter(void)
{
#if defined(__x86_64__)
    uint32_t lo, hi;
    /* RDTSC: the x86-64 time-stamp counter, split across EDX:EAX.
     * asm volatile makes this an observable compiler operation that must be
     * emitted. It is not a general compiler/memory barrier and says nothing
     * about inter-thread visibility or CPU memory ordering. */
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
#elif defined(__aarch64__)
    uint64_t ticks;
    /* CNTVCT_EL0: the AArch64 virtual counter-timer register. */
    __asm__ volatile ("mrs %0, cntvct_el0" : "=r"(ticks));
    return ticks;
#else
    return 0;                   /* portable fallback: the program still builds and runs */
#endif
}

static const char *counter_source(void)
{
#if defined(__x86_64__)
    return "x86_64 rdtsc";
#elif defined(__aarch64__)
    return "aarch64 cntvct_el0";
#else
    return "no counter on this platform (portable fallback returns 0)";
#endif
}

int main(void)
{
    printf("counter source: %s\n", counter_source());

    uint64_t before = read_cycle_counter();
    /* a little portable work between the two reads */
    volatile uint64_t sink = 0;
    for (uint64_t i = 0; i < 1000000; i++)
        sink += i;
    uint64_t after = read_cycle_counter();

    printf("before: %llu\n", (unsigned long long)before);
    printf("after:  %llu\n", (unsigned long long)after);
    printf("delta:  %llu ticks for a million additions (illustration, not a benchmark)\n",
           (unsigned long long)(after - before));
    if (before == 0 && after == 0)
        printf("(fallback platform: both reads are 0 — the program still works)\n");
    return 0;
}
