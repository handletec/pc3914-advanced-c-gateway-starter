/* diag_lookup.c — random access into the gateway's binary diagnostics.
 *
 * usage: diag_lookup DATA_FILE INDEX_FILE MODULE_ID
 *
 * The demonstration: the gateway wrote a diagnostic history and a small
 * persisted index; this SEPARATE program finds one module's latest record
 * with one index probe and ONE fseek+fread — no scanning, no parsing.
 * (Same build, same machine: the layout assertions and magic/version checks
 * are what make that trust legitimate. This is a local format, not a
 * portable one.)
 *
 * The CLI is a strict recogniser, Day 3 discipline: checked strtoul, no atoi. */
#define _POSIX_C_SOURCE 200809L
#include "diag_binary.h"
#include "gw_status.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: %s DATA_FILE INDEX_FILE MODULE_ID\n", argv[0]);
        return 2;
    }
    char *endp;
    errno = 0;
    if (argv[3][0] == '-') {
        fprintf(stderr, "error: MODULE_ID must be a decimal uint32, got '%s'\n", argv[3]);
        return 2;
    }
    unsigned long id = strtoul(argv[3], &endp, 10);
    if (errno != 0 || *endp != '\0' || endp == argv[3] || id > UINT32_MAX) {
        fprintf(stderr, "error: MODULE_ID must be a decimal uint32, got '%s'\n", argv[3]);
        return 2;
    }

    FILE *ixf = fopen(argv[2], "rb");
    if (!ixf) {
        fprintf(stderr, "error: %s: %s\n", argv[2], strerror(errno));
        return 1;
    }
    diag_index_t ix;
    gw_status_t st = diag_index_load(&ix, ixf);
    fclose(ixf);
    if (st != GW_OK) {
        fprintf(stderr, "error: %s is not a diagnostic index (%s)\n", argv[2], gw_strstatus(st));
        return 1;
    }

    uint64_t record_index;
    st = diag_index_get(&ix, (uint32_t)id, &record_index);
    if (st == GW_ENOENT) {
        printf("module %lu: no diagnostic record indexed\n", id);   /* a miss is an answer */
        return 0;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "error: %s: %s\n", argv[1], strerror(errno));
        return 1;
    }
    diag_record_t r;
    st = diag_bin_read_at(f, (size_t)record_index, &r);
    fclose(f);
    if (st != GW_OK) {
        fprintf(stderr, "error: record %llu: %s (index and data file out of step?)\n",
                (unsigned long long)record_index, gw_strstatus(st));
        return 1;
    }

    printf("module %u: record %llu, seq %llu, rssi %d dBm, flags [%s%s%s]\n",
           r.module_id, (unsigned long long)record_index, (unsigned long long)r.sequence,
           r.rssi_dbm,
           (r.flags & DIAG_FLAG_CONNECTED) ? " connected" : "",
           (r.flags & DIAG_FLAG_DEGRADED)  ? " degraded"  : "",
           (r.flags & DIAG_FLAG_ALERT)     ? " alert"     : "");
    return 0;
}
