#ifndef DIAG_LOG_H
#define DIAG_LOG_H
#include <stdio.h>

/* diag_log — a tiny variadic logging wrapper (Day 3 Block 4).
 *
 * One prefix, one format, one newline, one fflush-free write:
 *   diag_log(stderr, "seq %llu module %u", seq, id);
 *   -> "[diag] seq 12 module 7\n"
 *
 * How "..." works: va_start captures the variadic arguments into a va_list,
 * vfprintf consumes them against the format, va_end closes the list. This
 * file FORWARDS the arguments to the library formatter — it never walks
 * them by hand, and it is not a logging framework.
 *
 * The limitation to teach: the compiler cannot type-check arguments implied
 * by a format string it never parses. The format attribute below restores
 * that checking on compilers that support it — with it, passing an int
 * where %s is written is a compile error again; without it, it is a bug
 * the tools must find at run time. */

#if defined(__GNUC__)
#define DIAG_LOG_FORMAT __attribute__((format(printf, 2, 3)))
#else
#define DIAG_LOG_FORMAT
#endif

void diag_log(FILE *to, const char *fmt, ...) DIAG_LOG_FORMAT;

#endif
