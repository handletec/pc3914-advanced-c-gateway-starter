#ifndef GW_OBSERVERS_H
#define GW_OBSERVERS_H
#include "observer.h"
#include <stdio.h>

/* The gateway's concrete observers (Day 3 Block 4).
 *
 * Three consumers of the same completed event, three different reasons:
 *   logger   — one concise line per event, for a person watching a stream
 *   metrics  — counters, for the final report ("did anything get lost?")
 *   reporter — the LAST thing that happened, for a status summary
 *
 * Each is an ordinary function whose context is an ordinary struct the
 * CALLER owns. The observer list stores the pair; it owns neither. */

/* metrics: counts of what the pipeline decided. If every event is processed
 * exactly once and observers are notified exactly once per event, these must
 * equal the gateway's own pipeline counters — that equality is the activity's
 * proof that adding an Observer did not duplicate or drop processing. */
typedef struct {
    size_t events;                 /* every notification */
    size_t transitions;            /* outcome == SM_TRANSITION */
    size_t alerts;                 /* alert_raised */
} gw_metrics_t;

/* reporter: a report-facing summary — the most recent completed event. */
typedef struct {
    uint64_t       last_seq;
    uint32_t       last_module;
    module_state_t last_state;
    size_t         updates;
} gw_report_summary_t;

/* logger: ctx is the FILE* to write to. One line per event via diag_log.
 * The gateway wires it to its own --log-events file, NOT to the report
 * stream: reports must stay byte-comparable across runs, and a per-event
 * line interleaving with snapshot output would break that. */
void logger_on_event(const processed_event_t *ev, void *ctx);

/* TODO-D3.7 (implementation lives in src/gw_observers.c). */
void metrics_on_event(const processed_event_t *ev, void *ctx);

void reporter_on_event(const processed_event_t *ev, void *ctx);

/* Subscribes the gateway's observers, in this documented order:
 *   1. logger (only when log_to != NULL; ctx = log_to)
 *   2. metrics (ctx = m)     3. reporter (ctx = s)
 * Call BEFORE processing begins; contexts must outlive the list.
 * Returns the first non-GW_OK subscribe result, or GW_OK. */
gw_status_t gw_observers_register(observer_list_t *list, FILE *log_to,
                                  gw_metrics_t *m, gw_report_summary_t *s);

#endif
