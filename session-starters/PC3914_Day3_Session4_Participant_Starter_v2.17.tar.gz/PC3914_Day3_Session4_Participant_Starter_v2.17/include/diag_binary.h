#ifndef DIAG_BINARY_H
#define DIAG_BINARY_H
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

/* Same-build local format with an explicitly locked training-ABI layout.
 * It is not a portable serialization format. */
#define DIAG_BIN_MAGIC   0x47574442u
#define DIAG_BIN_VERSION 1u
enum {
    DIAG_FLAG_CONNECTED = 1u << 0,
    DIAG_FLAG_DEGRADED  = 1u << 1,
    DIAG_FLAG_ALERT     = 1u << 2
};
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t flags;
    uint32_t module_id;
    int32_t  rssi_dbm;
    uint64_t sequence;
} diag_record_t;
_Static_assert(sizeof(diag_record_t) == 24, "diag_record_t size changed");
_Static_assert(offsetof(diag_record_t, magic) == 0, "record magic offset");
_Static_assert(offsetof(diag_record_t, version) == 4, "record version offset");
_Static_assert(offsetof(diag_record_t, flags) == 6, "record flags offset");
_Static_assert(offsetof(diag_record_t, module_id) == 8, "record module offset");
_Static_assert(offsetof(diag_record_t, rssi_dbm) == 12, "record rssi offset");
_Static_assert(offsetof(diag_record_t, sequence) == 16, "record sequence offset");

void diag_record_init(diag_record_t *r, uint32_t module_id, int16_t rssi_dbm,
                      uint16_t flags, uint64_t sequence);
int diag_record_valid(const diag_record_t *r);
gw_status_t diag_bin_append(FILE *f, const diag_record_t *r);
gw_status_t diag_bin_count(FILE *f, size_t *out_count);
gw_status_t diag_bin_read_at(FILE *f, size_t index, diag_record_t *out);

#define DIAG_INDEX_MAGIC   0x47574458u
#define DIAG_INDEX_VERSION 1u
#define DIAG_INDEX_SLOTS   16u
typedef struct {
    uint32_t module_id;
    uint64_t record_index;
    uint8_t used;
} diag_index_slot_t;
_Static_assert(sizeof(diag_index_slot_t) == 24, "diag_index_slot_t size changed");
_Static_assert(offsetof(diag_index_slot_t, module_id) == 0, "slot module offset");
_Static_assert(offsetof(diag_index_slot_t, record_index) == 8, "slot record offset");
_Static_assert(offsetof(diag_index_slot_t, used) == 16, "slot used offset");
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t reserved;
    uint32_t count;
    uint32_t reserved2;
    diag_index_slot_t slot[DIAG_INDEX_SLOTS];
} diag_index_t;
_Static_assert(sizeof(diag_index_t) == 400, "diag_index_t training ABI size changed");
_Static_assert(offsetof(diag_index_t, magic) == 0, "index magic offset");
_Static_assert(offsetof(diag_index_t, version) == 4, "index version offset");
_Static_assert(offsetof(diag_index_t, count) == 8, "index count offset");
_Static_assert(offsetof(diag_index_t, slot) == 16, "index slots offset");

void diag_index_init(diag_index_t *ix);
gw_status_t diag_index_put(diag_index_t *ix, uint32_t module_id, uint64_t record_index);
gw_status_t diag_index_get(const diag_index_t *ix, uint32_t module_id, uint64_t *out_index);
gw_status_t diag_index_save(const diag_index_t *ix, FILE *f);
gw_status_t diag_index_load(diag_index_t *ix, FILE *f);
#endif
