#ifndef OBSERVER_H
#define OBSERVER_H
#include "device_registry.h"      /* module_state_t */
#include "module_state_machine.h" /* sm_outcome_t */
#include "event.h"
#include "gw_status.h"
#include <stddef.h>
#include <stdint.h>

/* Event observers — an Observer (Day 3 Block 4).
 *
 * "Which application components want this COMPLETED event?"
 *
 * That is a different question from the Reactor's. The Reactor asks "which
 * I/O SOURCE is ready?" and owns the readiness loop at the FRONT of the
 * pipeline. The Observer sits at the BACK: once the stateful worker has
 * pushed the event into the store, stepped the lifecycle and classified
 * alerts, several independent consumers (a logger, a metrics counter, a
 * report summary) want to hear about the result — without the worker
 * knowing who they are. The worker calls one function; the list fans out.
 *
 * What an observer receives: not the raw event but the PROCESSING RESULT —
 * the event plus what the pipeline decided about it. */
typedef struct {
    const event_t *event;          /* BORROWED: valid only during the callback (see below) */
    uint64_t       seq;            /* the gateway sequence number assigned by the store */
    module_state_t state_after;    /* the module's lifecycle state after this event */
    sm_outcome_t   outcome;        /* SM_TRANSITION / SM_STAY / SM_REJECTED */
    int            alert_raised;   /* 1 when the policy raised an alert for this event */
    uint8_t        alert_severity; /* meaningful only when alert_raised */
} processed_event_t;

typedef void (*event_observer_fn)(const processed_event_t *ev, void *ctx);

typedef struct observer_node {
    event_observer_fn     fn;
    void                 *ctx;
    struct observer_node *next;
} observer_node_t;

/* Ownership contract (precise, tested):
 *   the list OWNS its subscription nodes — destroy frees them and nothing else
 *   the list does NOT own the callback functions, the contexts, or the event
 *   during notify the event is BORROWED: a callback must not free it and must
 *   not keep any pointer from it past the callback unless it clones the data
 *   a context must outlive its subscription (the list never touches it)
 *
 * Mutation rule (the training rule, enforced): subscriptions are configured
 * BEFORE processing begins and stay stable while events are dispatched —
 * observer_subscribe() during notify returns GW_EINVAL and changes nothing.
 * Re-entrant observer_notify() returns GW_EINVAL. observer_list_destroy()
 * during notify is a no-op; the caller destroys after dispatch. Notification
 * is SYNCHRONOUS, on the caller's thread, in subscription order; the list
 * adds no thread and no queue. */
typedef struct {
    observer_node_t *head;
    observer_node_t *tail;         /* append here: notify order == subscription order */
    size_t           count;
    int              notifying;    /* nonzero while a notify is walking the list */
} observer_list_t;

void        observer_list_init(observer_list_t *list);

/* GW_EINVAL: list or fn NULL, or called from inside a callback (unchanged).
 * GW_ENOMEM: node allocation failed (unchanged). */
gw_status_t observer_subscribe(observer_list_t *list, event_observer_fn fn, void *ctx);

/* Calls every subscriber once, in subscription order, on THIS thread.
 * GW_EINVAL when list/ev is NULL or notification is already in progress. */
gw_status_t observer_notify(observer_list_t *list, const processed_event_t *ev);

size_t      observer_count(const observer_list_t *list);

/* Frees the nodes ONLY. Callbacks, contexts and events are untouched.
 * During active notification this is a no-op; destroy after dispatch. */
void        observer_list_destroy(observer_list_t *list);

#endif
