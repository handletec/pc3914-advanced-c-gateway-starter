/* test_observer.c — contract, order, ownership, and the gateway's observers.
 *
 * Deterministic and single-threaded: the Observer runs synchronously on the
 * notifying thread, so there is nothing to time and nothing to race. The
 * [gateway] group is the participant gate for TODO-D3.7: it fails until
 * metrics_on_event() is implemented AND subscribed. */
#define _POSIX_C_SOURCE 200809L
#include "observer.h"
#include "gw_observers.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* One synthetic completed event, built the way the worker builds one. */
static event_t *make_event(uint32_t module_id, event_kind_t kind, int16_t rssi)
{
    event_view_t v = { module_id, kind, rssi, "test", 4 };
    event_t *e = event_clone(&v);
    assert(e && "test setup: event_clone failed");
    return e;
}

static processed_event_t make_processed(const event_t *e, uint64_t seq,
                                        module_state_t after, sm_outcome_t out, int alert)
{
    processed_event_t pe = { e, seq, after, out, alert, alert ? 4 : 0 };
    return pe;
}

/* ---- [contract] validation and the no-mutation-during-notify rule -------- */

static void count_cb(const processed_event_t *ev, void *ctx)
{
    (void)ev;
    (*(int *)ctx)++;
}

static observer_list_t *sneaky_target;
static gw_status_t      sneaky_result = GW_OK;
static int              sneaky_extra;
static void sneaky_cb(const processed_event_t *ev, void *ctx)
{
    (void)ev; (void)ctx;
    /* the training rule: subscriptions are stable during dispatch */
    sneaky_result = observer_subscribe(sneaky_target, count_cb, &sneaky_extra);
}


static gw_status_t reenter_result = GW_OK;
static void reenter_cb(const processed_event_t *ev, void *ctx)
{
    observer_list_t *list = ctx;
    reenter_result = observer_notify(list, ev);
}

static int destroy_hits;
static void destroy_cb(const processed_event_t *ev, void *ctx)
{
    (void)ev;
    observer_list_t *list = ctx;
    observer_list_destroy(list);
    destroy_hits++;
}

static void test_contract(void)
{
    printf("[contract] ");
    observer_list_t list;
    observer_list_init(&list);
    int hits = 0;

    assert(observer_subscribe(NULL, count_cb, &hits) == GW_EINVAL);
    assert(observer_subscribe(&list, NULL, &hits) == GW_EINVAL);
    assert(observer_count(&list) == 0 && "failed subscribes must change nothing");
    assert(observer_notify(&list, NULL) == GW_EINVAL);

    event_t *e = make_event(7, EV_SIGNAL, -60);
    processed_event_t pe = make_processed(e, 0, MOD_ONLINE, SM_STAY, 0);
    assert(observer_notify(&list, &pe) == GW_OK && "an empty list is fine: nobody to tell");

    assert(observer_subscribe(&list, sneaky_cb, NULL) == GW_OK);
    sneaky_target = &list;
    assert(observer_notify(&list, &pe) == GW_OK);
    assert(sneaky_result == GW_EINVAL && "subscribe during notify must be refused");
    assert(observer_count(&list) == 1 && "the refused subscribe must change nothing");
    assert(observer_notify(&list, &pe) == GW_OK && "notify works again after dispatch ends");

    observer_list_t guarded;
    observer_list_init(&guarded);
    assert(observer_subscribe(&guarded, reenter_cb, &guarded) == GW_OK);
    reenter_result = GW_OK;
    assert(observer_notify(&guarded, &pe) == GW_OK);
    assert(reenter_result == GW_EINVAL && "re-entrant notify must be refused");
    observer_list_destroy(&guarded);

    observer_list_init(&guarded);
    destroy_hits = 0;
    assert(observer_subscribe(&guarded, destroy_cb, &guarded) == GW_OK);
    assert(observer_subscribe(&guarded, count_cb, &hits) == GW_OK);
    int before_hits = hits;
    assert(observer_notify(&guarded, &pe) == GW_OK);
    assert(destroy_hits == 1 && hits == before_hits + 1 &&
           "destroy during dispatch must be a no-op; later callbacks still run");
    assert(observer_count(&guarded) == 2 && "destroy during dispatch must not mutate the list");
    observer_list_destroy(&guarded);

    observer_list_destroy(&list);
    event_free(e);
    printf("validation, mutation, re-entry, and destroy guards hold\n");
}

/* ---- [order] notify order == subscription order --------------------------- */

static char order_log[8];
static size_t order_len;
static void tag_cb(const processed_event_t *ev, void *ctx)
{
    (void)ev;
    if (order_len < sizeof order_log - 1)
        order_log[order_len++] = *(const char *)ctx;
}

static void test_order(void)
{
    printf("[order] ");
    observer_list_t list;
    observer_list_init(&list);
    static const char a = 'a', b = 'b', c = 'c';
    assert(observer_subscribe(&list, tag_cb, (void *)&a) == GW_OK);
    assert(observer_subscribe(&list, tag_cb, (void *)&b) == GW_OK);
    assert(observer_subscribe(&list, tag_cb, (void *)&c) == GW_OK);
    assert(observer_count(&list) == 3);

    event_t *e = make_event(3, EV_CONNECT, -50);
    processed_event_t pe = make_processed(e, 1, MOD_CONNECTING, SM_TRANSITION, 0);
    order_len = 0;
    assert(observer_notify(&list, &pe) == GW_OK);
    order_log[order_len] = '\0';
    assert(strcmp(order_log, "abc") == 0 && "callbacks must run in subscription order");

    observer_list_destroy(&list);
    event_free(e);
    printf("three subscribers ran as a, b, c — subscription order\n");
}

/* ---- [gateway] logger + metrics + reporter on the same events ------------- */

static void test_gateway_observers(void)
{
    printf("[gateway] ");
    observer_list_t list;
    observer_list_init(&list);
    gw_metrics_t        m = { 0, 0, 0 };
    gw_report_summary_t s = { 0, 0, MOD_OFFLINE, 0 };
    FILE *log = tmpfile();
    assert(log && "test setup: tmpfile failed");

    assert(gw_observers_register(NULL, log, &m, &s) == GW_EINVAL);
    assert(gw_observers_register(&list, log, NULL, &s) == GW_EINVAL);
    assert(gw_observers_register(&list, log, &m, NULL) == GW_EINVAL);
    assert(observer_count(&list) == 0 && "invalid registration must not partially subscribe");
    assert(gw_observers_register(&list, log, &m, &s) == GW_OK);
    assert(observer_count(&list) >= 2 && "logger and reporter must be subscribed");

    /* Five completed events: 2 transitions, 1 alert — the expected totals. */
    struct { event_kind_t kind; int16_t rssi; module_state_t after; sm_outcome_t out; int alert; }
    fix[5] = {
        { EV_CONNECT,    -55, MOD_CONNECTING, SM_TRANSITION, 0 },
        { EV_SIGNAL,     -60, MOD_ONLINE,     SM_TRANSITION, 0 },
        { EV_SIGNAL,     -62, MOD_ONLINE,     SM_STAY,       0 },
        { EV_ERROR,      -62, MOD_ONLINE,     SM_STAY,       1 },
        { EV_DISCONNECT, -62, MOD_ONLINE,     SM_REJECTED,   0 },
    };
    for (uint64_t i = 0; i < 5; i++) {
        event_t *e = make_event(9, fix[i].kind, fix[i].rssi);
        processed_event_t pe = make_processed(e, i, fix[i].after, fix[i].out, fix[i].alert);
        assert(observer_notify(&list, &pe) == GW_OK);
        event_free(e);                          /* borrowed during notify: still ours after */
    }

    assert(observer_count(&list) == 3 && "TODO-D3.7: metrics observer was never subscribed");
    assert(m.events == 5 && "TODO-D3.7: metrics must see every completed event exactly once");
    assert(m.transitions == 2 && "TODO-D3.7: count only SM_TRANSITION outcomes");
    assert(m.alerts == 1 && "TODO-D3.7: count only events that raised an alert");

    assert(s.updates == 5 && s.last_seq == 4 && s.last_module == 9 &&
           "reporter must hold the LAST completed event");

    /* the logger wrote one line per event to ITS stream */
    rewind(log);
    size_t lines = 0;
    int ch;
    while ((ch = fgetc(log)) != EOF)
        if (ch == '\n')
            lines++;
    assert(lines == 5 && "logger must write exactly one line per event");
    fclose(log);

    observer_list_destroy(&list);
    printf("logger 5 lines, metrics {5, 2, 1}, reporter seq 4 — one processing, three consumers\n");
}

/* ---- [ownership] destroy frees the nodes and nothing else ----------------- */

static void test_ownership(void)
{
    printf("[ownership] ");
    size_t before = gw_alloc_live_count();
    int hits = 0;
    observer_list_t list;
    observer_list_init(&list);
    for (int i = 0; i < 4; i++)
        assert(observer_subscribe(&list, count_cb, &hits) == GW_OK);
    assert(gw_alloc_live_count() == before + 4 && "one node per subscription");

    gw_alloc_fail_after(0);                     /* the next allocation fails */
    assert(observer_subscribe(&list, count_cb, &hits) == GW_ENOMEM);
    gw_alloc_fail_after(-1);
    assert(observer_count(&list) == 4 && "a failed subscribe must change nothing");

    observer_list_destroy(&list);
    assert(gw_alloc_live_count() == before && "destroy frees the nodes ONLY — and all of them");
    assert(hits == 0 && "destroy must not call anybody");
    printf("4 nodes freed, contexts untouched, ENOMEM left the list unchanged\n");
}

int main(void)
{
    test_contract();
    test_order();
    test_gateway_observers();
    test_ownership();
    assert(gw_alloc_live_count() == 0 && "observer tests must leak nothing");
    printf("test_observer: all groups passed (0 live)\n");
    return 0;
}
