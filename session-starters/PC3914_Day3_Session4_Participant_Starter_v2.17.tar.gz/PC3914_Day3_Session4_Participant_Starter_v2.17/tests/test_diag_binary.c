/* test_diag_binary.c — layout, roundtrip, random access, refusal, and the index.
 *
 * Everything runs on tmpfile() streams: real fwrite/fseek/fread against a
 * real file, no fixture paths to clean up, fully deterministic. */
#define _POSIX_C_SOURCE 200809L
#include "diag_binary.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

/* ---- [layout] the same-build contract ------------------------------------- */

static void test_layout(void)
{
    printf("[layout] ");
    /* the _Static_assert in the header already fired at COMPILE time if the
     * layout drifted; here we prove the runtime view agrees */
    assert(sizeof(diag_record_t) == 24);
    assert(offsetof(diag_record_t, magic) == 0);
    assert(offsetof(diag_record_t, version) == 4);
    assert(offsetof(diag_record_t, flags) == 6);
    assert(offsetof(diag_record_t, module_id) == 8);
    assert(offsetof(diag_record_t, rssi_dbm) == 12);
    assert(offsetof(diag_record_t, sequence) == 16);
    assert(sizeof(diag_index_t) == 400);
    diag_record_t r;
    diag_record_init(&r, 7, -61, DIAG_FLAG_CONNECTED, 42);
    assert(diag_record_valid(&r));
    assert(r.magic == DIAG_BIN_MAGIC && r.version == DIAG_BIN_VERSION);
    r.version = 99;
    assert(!diag_record_valid(&r) && "an unknown version must be refused, not guessed at");
    printf("24 bytes, magic 'GWDB', version checked\n");
}

/* ---- [flags] set, clear, test with masks ---------------------------------- */

static void test_flags(void)
{
    printf("[flags] ");
    uint16_t flags = 0;
    flags |= DIAG_FLAG_CONNECTED;                     /* set */
    flags |= DIAG_FLAG_ALERT;
    assert((flags & DIAG_FLAG_CONNECTED) && (flags & DIAG_FLAG_ALERT));
    assert(!(flags & DIAG_FLAG_DEGRADED) && "an unset bit must read as unset");
    flags &= (uint16_t)~DIAG_FLAG_ALERT;              /* clear ONE bit, the others survive */
    assert(!(flags & DIAG_FLAG_ALERT) && (flags & DIAG_FLAG_CONNECTED));
    printf("set |=, clear &=~, test & — independent bits\n");
}

/* ---- [roundtrip] write N, count N, read them back ------------------------- */

static FILE *write_fixture(size_t n)
{
    FILE *f = tmpfile();
    assert(f && "test setup: tmpfile failed");
    for (size_t i = 0; i < n; i++) {
        diag_record_t r;
        diag_record_init(&r, (uint32_t)(i % 3), (int16_t)(-50 - (int)i),
                         (uint16_t)(i % 2 ? DIAG_FLAG_CONNECTED : 0), i);
        assert(diag_bin_append(f, &r) == GW_OK);
    }
    return f;
}

static void test_roundtrip(void)
{
    printf("[roundtrip] ");
    FILE *f = write_fixture(6);
    size_t n = 0;
    assert(diag_bin_count(f, &n) == GW_OK && n == 6);
    for (size_t i = 0; i < 6; i++) {
        diag_record_t r;
        assert(diag_bin_read_at(f, i, &r) == GW_OK);
        assert(r.sequence == i && r.module_id == i % 3 && r.rssi_dbm == -50 - (int)i);
    }
    fclose(f);
    printf("6 records written, 6 counted, 6 read back intact\n");
}

/* ---- [random] jump straight to a record, no scanning ---------------------- */

static void test_random_access(void)
{
    printf("[random] ");
    FILE *f = write_fixture(100);
    diag_record_t r;
    assert(diag_bin_read_at(f, 73, &r) == GW_OK && r.sequence == 73);
    assert(diag_bin_read_at(f, 0, &r) == GW_OK && r.sequence == 0);
    assert(diag_bin_read_at(f, 99, &r) == GW_OK && r.sequence == 99);
    fclose(f);
    printf("records 73, 0, 99 fetched by offset = index * sizeof\n");
}

/* ---- [bounds] past EOF, overflow guard, truncation, foreign bytes --------- */

static void test_bounds(void)
{
    printf("[bounds] ");
    FILE *f = write_fixture(3);
    diag_record_t r;
    assert(diag_bin_read_at(f, 3, &r) == GW_ENOENT && "one past the end is a MISS, not an error");
    assert(diag_bin_read_at(f, (size_t)-1, &r) == GW_EINVAL &&
           "an index that would overflow the offset is refused BEFORE multiplying");

    /* truncate: append half a record's worth of garbage */
    assert(fseek(f, 0L, SEEK_END) == 0);
    assert(fwrite("torn", 1, 4, f) == 4);
    size_t n = 0;
    assert(diag_bin_count(f, &n) == GW_EINVAL && "a torn file must be refused, not rounded");
    fclose(f);

    /* foreign bytes where a record should be */
    FILE *g = tmpfile();
    assert(g);
    char junk[24];
    memset(junk, 0xAB, sizeof junk);
    assert(fwrite(junk, sizeof junk, 1, g) == 1);
    assert(diag_bin_read_at(g, 0, &r) == GW_EINVAL && "no magic, no trust");
    fclose(g);
    printf("miss GW_ENOENT, overflow GW_EINVAL, torn file GW_EINVAL, bad magic GW_EINVAL\n");
}

/* ---- [index] module_id -> slot -> record index -> disk -------------------- */

static void test_index(void)
{
    printf("[index] ");
    diag_index_t ix;
    diag_index_init(&ix);
    uint64_t where = 0;
    assert(diag_index_get(&ix, 7, &where) == GW_ENOENT && "empty index: a clean miss");

    assert(diag_index_put(&ix, 7, 12) == GW_OK);
    assert(diag_index_put(&ix, 23, 40) == GW_OK);    /* 23 % 16 == 7: probes past module 7 */
    assert(diag_index_put(&ix, 7, 99) == GW_OK);     /* update in place: the LATEST record wins */
    assert(ix.count == 2);
    assert(diag_index_get(&ix, 7, &where) == GW_OK && where == 99);
    assert(diag_index_get(&ix, 23, &where) == GW_OK && where == 40 &&
           "linear probing must find the colliding key");

    /* persist and reload through a real file */
    FILE *f = tmpfile();
    assert(f);
    assert(diag_index_save(&ix, f) == GW_OK);
    rewind(f);
    diag_index_t back;
    assert(diag_index_load(&back, f) == GW_OK);
    assert(back.count == 2);
    assert(diag_index_get(&back, 7, &where) == GW_OK && where == 99);
    fclose(f);

    /* persisted header/body validation: wrong version, impossible count,
     * invalid used flag, and count/used mismatch are all refused. */
    diag_index_t bad = back;
    bad.version++;
    FILE *badf = tmpfile(); assert(badf); assert(fwrite(&bad, sizeof bad, 1, badf) == 1); rewind(badf);
    assert(diag_index_load(&back, badf) == GW_EINVAL); fclose(badf);
    bad = ix; bad.count = DIAG_INDEX_SLOTS + 1;
    badf = tmpfile(); assert(badf); assert(fwrite(&bad, sizeof bad, 1, badf) == 1); rewind(badf);
    assert(diag_index_load(&back, badf) == GW_EINVAL); fclose(badf);
    bad = ix; bad.slot[0].used = 2;
    badf = tmpfile(); assert(badf); assert(fwrite(&bad, sizeof bad, 1, badf) == 1); rewind(badf);
    assert(diag_index_load(&back, badf) == GW_EINVAL); fclose(badf);
    bad = ix; bad.count++;
    badf = tmpfile(); assert(badf); assert(fwrite(&bad, sizeof bad, 1, badf) == 1); rewind(badf);
    assert(diag_index_load(&back, badf) == GW_EINVAL); fclose(badf);

    /* a file that is not an index */
    FILE *g = tmpfile();
    assert(g);
    assert(fwrite("not an index at all, sorry......", 32, 1, g) == 1);
    rewind(g);
    assert(diag_index_load(&back, g) == GW_EINVAL && "short read or bad magic: refused");
    fclose(g);

    /* the stated budget: 16 slots, the 17th module is an honest GW_ENOSPACE */
    diag_index_t full;
    diag_index_init(&full);
    for (uint32_t id = 0; id < DIAG_INDEX_SLOTS; id++)
        assert(diag_index_put(&full, id * 100u + 1u, id) == GW_OK);
    assert(diag_index_put(&full, 9999, 0) == GW_ENOSPACE);
    printf("collision probed, update-in-place, save/load roundtrip, full is GW_ENOSPACE\n");
}


/* ---- [io-error] actual stream errors remain GW_EIO ----------------------- */
static void test_io_error(void)
{
    printf("[io-error] ");
    char path[] = "/tmp/pc3914-diag-XXXXXX";
    int fd = mkstemp(path);
    assert(fd >= 0);
    FILE *write_only = fdopen(fd, "wb");
    assert(write_only);
    diag_record_t r;
    assert(diag_bin_read_at(write_only, 0, &r) == GW_EIO);
    clearerr(write_only);
    diag_index_t ix;
    assert(diag_index_load(&ix, write_only) == GW_EIO);
    fclose(write_only);
    unlink(path);
    printf("read failures remain GW_EIO rather than clean EOF/invalid-data results\n");
}

int main(void)
{
    test_layout();
    test_flags();
    test_roundtrip();
    test_random_access();
    test_bounds();
    test_index();
    test_io_error();
    printf("test_diag_binary: all seven groups passed\n");
    return 0;
}
