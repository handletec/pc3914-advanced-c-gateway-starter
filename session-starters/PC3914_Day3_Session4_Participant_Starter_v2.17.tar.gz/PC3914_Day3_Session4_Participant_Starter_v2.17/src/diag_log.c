/* diag_log.c — forward the arguments, never walk them by hand (Day 3 Block 4). */
#include "diag_log.h"
#include <stdarg.h>

void diag_log(FILE *to, const char *fmt, ...)
{
    if (!to || !fmt)
        return;
    va_list ap;
    va_start(ap, fmt);                  /* capture the ... arguments */
    fputs("[diag] ", to);
    vfprintf(to, fmt, ap);              /* the library formatter consumes them */
    va_end(ap);                         /* always paired with va_start */
    fputc('\n', to);
}
