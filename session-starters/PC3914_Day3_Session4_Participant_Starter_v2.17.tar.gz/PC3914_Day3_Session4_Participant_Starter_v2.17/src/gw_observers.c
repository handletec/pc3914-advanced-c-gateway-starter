/* gw_observers.c — the gateway's concrete observers (Day 3 Block 4).
 *
 * Three callbacks, one shape: (const processed_event_t *, void *ctx).
 * The list calls each in subscription order; none of them knows the others
 * exist. The worker that notifies knows none of them by name. */
#include "gw_observers.h"
#include "diag_log.h"

void logger_on_event(const processed_event_t *ev, void *ctx)
{
    FILE *to = ctx;                     /* caller-owned stream; we only write to it */
    diag_log(to, "seq %llu module %u %s -> %s%s",
             (unsigned long long)ev->seq, ev->event->module_id,
             event_kind_name(ev->event->kind), module_state_name(ev->state_after),
             ev->alert_raised ? " [alert]" : "");
    /* ev->event is BORROWED: printed now, no pointer kept. */
}

/* TODO-D3.7: implement the metrics observer.
 *   ctx is a gw_metrics_t * owned by the caller. Count:
 *     - every notification:                m->events++
 *     - ev->outcome == SM_TRANSITION:      m->transitions++
 *     - ev->alert_raised:                  m->alerts++
 *   Do not free anything. Do not keep ev or ev->event.
 * Then subscribe it: add the metrics line in gw_observers_register() below
 * (order is documented in the header: logger, metrics, reporter). */
void metrics_on_event(const processed_event_t *ev, void *ctx)
{
    (void)ev;                           /* TODO-D3.7: count events, transitions, alerts */
    (void)ctx;
}

void reporter_on_event(const processed_event_t *ev, void *ctx)
{
    gw_report_summary_t *s = ctx;
    s->last_seq    = ev->seq;
    s->last_module = ev->event->module_id;
    s->last_state  = ev->state_after;   /* values copied out: nothing borrowed survives */
    s->updates++;
}

gw_status_t gw_observers_register(observer_list_t *list, FILE *log_to,
                                  gw_metrics_t *m, gw_report_summary_t *s)
{
    gw_status_t st;
    if (!list || !m || !s)
        return GW_EINVAL;
    if (log_to) {                       /* the logger is opt-in: no stream, no subscriber */
        st = observer_subscribe(list, logger_on_event, log_to);
        if (st != GW_OK)
            return st;
    }
    (void)m;                            /* TODO-D3.7: subscribe metrics_on_event with ctx m */
    st = observer_subscribe(list, reporter_on_event, s);
    if (st != GW_OK)
        return st;
    return GW_OK;
}
