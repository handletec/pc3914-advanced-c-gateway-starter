/* stream_framer.c — bytes in, complete records out, tail kept (Day 3 Block 3). */
#define _POSIX_C_SOURCE 200809L
#include "stream_framer.h"
#include <errno.h>
#include <string.h>
#include <unistd.h>

void client_init(client_t *c, int fd)
{
    if (!c)
        return;
    c->fd = fd;
    c->used = 0;
    c->events = 0;
    c->rejected = 0;
}

/* parse_events() has no context parameter; bridge it. Reactor thread only. */
static framer_emit_t cur_emit;
static void         *cur_ctx;
static void trampoline(const event_view_t *ev) { cur_emit(ev, cur_ctx); }

/* Parse every complete record currently in c->buf, emit each, compact the tail. */
static void parse_and_compact(client_t *c, framer_emit_t emit, void *ctx)
{
    cur_emit = emit;
    cur_ctx  = ctx;
    parse_result_t r = parse_events(c->buf, c->used, trampoline);   /* views point into c->buf ... */
    c->events   += r.events;
    c->rejected += r.rejected;
    memmove(c->buf, c->buf + r.consumed, c->used - r.consumed);     /* ... and die right here */
    c->used -= r.consumed;
}

/* D3.5: append `data`, parse complete records, keep the incomplete tail.
 *   while there are bytes left to append:
 *     - if c->used == sizeof c->buf: the buffer is full and holds NO complete
 *       record (the last parse would have consumed one) -> GW_ENOSPACE
 *     - copy as much as fits (memcpy into c->buf + c->used; advance data/len)
 *     - parse_and_compact(c, emit, ctx)
 *   after the loop, one more check: a full buffer with no newline is an
 *   overlong record -> GW_ENOSPACE. Otherwise GW_OK: the tail waits for
 *   the next bytes.
 * The starter only appends: no record is ever parsed, no tail ever moves. */
gw_status_t client_feed(client_t *c, const char *data, size_t len, framer_emit_t emit, void *ctx)
{
    if (!c || (!data && len > 0) || !emit)
        return GW_EINVAL;
    while (len > 0) {
        if (c->used == sizeof c->buf)
            return GW_ENOSPACE;
        size_t space = sizeof c->buf - c->used;
        size_t take = len < space ? len : space;
        memcpy(c->buf + c->used, data, take);
        c->used += take;
        data += take;
        len -= take;
        parse_and_compact(c, emit, ctx);
    }
    if (c->used == sizeof c->buf)
        return GW_ENOSPACE;
    return GW_OK;
}

/* Prepared: drain a nonblocking descriptor into the framer. */
gw_status_t client_read(client_t *c, framer_emit_t emit, void *ctx, int *peer_closed)
{
    if (!c || c->fd < 0 || !emit || !peer_closed)
        return GW_EINVAL;
    char chunk[1024];
    *peer_closed = 0;
    for (;;) {
        ssize_t n = read(c->fd, chunk, sizeof chunk);
        if (n > 0) {
            gw_status_t rc = client_feed(c, chunk, (size_t)n, emit, ctx);
            if (rc != GW_OK)
                return rc;                      /* overlong record: the Reactor drops this client */
            continue;                           /* there may be more bytes already queued */
        }
        if (n == 0)  {
            if (c->used > 0) {                  /* transport closed cleanly, but the application record did not */
                c->rejected++;
                c->used = 0;
            }
            *peer_closed = 1;
            return GW_OK;
        }
        if (errno == EINTR)
            continue;                           /* interrupted before any byte moved */
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            return GW_OK;                       /* no more bytes NOW — return to poll, never spin */
        return GW_EIO;                          /* real error: errno kept for the caller */
    }
}
