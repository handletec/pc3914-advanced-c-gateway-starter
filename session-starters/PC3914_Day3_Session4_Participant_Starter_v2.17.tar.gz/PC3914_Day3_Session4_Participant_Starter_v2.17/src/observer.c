/* observer.c — a linked list of subscribers, notified in order (Day 3 Block 4).
 *
 * The list machinery is Day 2's singly linked list with a tail pointer; what
 * is new is the CONTRACT: who owns what, when the event is valid, and that
 * the list must not change under a running notify. */
#include "observer.h"
#include "gw_alloc.h"
#include <stddef.h>

void observer_list_init(observer_list_t *list)
{
    if (!list)
        return;
    list->head = NULL;
    list->tail = NULL;
    list->count = 0;
    list->notifying = 0;
}

gw_status_t observer_subscribe(observer_list_t *list, event_observer_fn fn, void *ctx)
{
    if (!list || !fn)
        return GW_EINVAL;
    if (list->notifying)
        return GW_EINVAL;               /* the training rule: no mutation during dispatch */

    observer_node_t *n = gw_malloc(sizeof *n);
    if (!n)
        return GW_ENOMEM;               /* list unchanged */
    n->fn   = fn;
    n->ctx  = ctx;                      /* borrowed: must outlive the subscription */
    n->next = NULL;

    if (list->tail)
        list->tail->next = n;           /* append: notify order == subscription order */
    else
        list->head = n;
    list->tail = n;
    list->count++;
    return GW_OK;
}

gw_status_t observer_notify(observer_list_t *list, const processed_event_t *ev)
{
    if (!list || !ev || list->notifying)
        return GW_EINVAL;
    list->notifying = 1;                /* subscribe() now refuses: the walk is safe */
    for (observer_node_t *n = list->head; n; n = n->next)
        n->fn(ev, n->ctx);              /* synchronous, this thread, subscription order */
    list->notifying = 0;
    return GW_OK;
}

size_t observer_count(const observer_list_t *list)
{
    return list ? list->count : 0;
}

void observer_list_destroy(observer_list_t *list)
{
    if (!list || list->notifying)
        return;
    observer_node_t *n = list->head;
    while (n) {
        observer_node_t *next = n->next;
        gw_free(n);                     /* the node ONLY: fn, ctx, events are not ours */
        n = next;
    }
    list->head = NULL;
    list->tail = NULL;
    list->count = 0;
    list->notifying = 0;
}
