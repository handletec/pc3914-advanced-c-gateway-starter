/* reactor.c — poll, accept, dispatch, remove (Day 3 Block 3). */
#define _POSIX_C_SOURCE 200809L
#include "reactor.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

gw_status_t reactor_init(reactor_t *r, int listen_fd, framer_emit_t emit, void *ctx)
{
    if (!r || listen_fd < 0 || !emit)
        return GW_EINVAL;
    memset(r, 0, sizeof *r);
    r->listen_fd = listen_fd;
    r->emit = emit;
    r->ctx  = ctx;
    r->fds[0].fd = listen_fd;                   /* slot 0: the listener, readable when accept() has work */
    r->fds[0].events = POLLIN;
    for (size_t i = 0; i < REACTOR_MAX_CLIENTS; i++) {
        r->clients[i].fd = -1;                  /* free slot */
        r->fds[i + 1].fd = -1;                  /* poll() ignores negative fds: no stale entries */
        r->fds[i + 1].events = POLLIN;
    }
    return GW_OK;
}

size_t reactor_active_clients(const reactor_t *r) { return r->active; }

/* D3.6a: the listener is readable — accept every waiting connection.
 *   loop:
 *     int cfd = accept(r->listen_fd, NULL, NULL);
 *     - cfd < 0 and errno EINTR                 -> continue (try again)
 *     - cfd < 0 and errno EAGAIN/EWOULDBLOCK    -> return GW_OK (no more waiting connections)
 *     - cfd < 0 otherwise                        -> report strerror(errno), return GW_EIO
 *     - tcp_set_nonblocking(cfd) != GW_OK        -> close(cfd), continue
 *     - find a free slot i (clients[i].fd == -1):
 *         none free: close(cfd); r->rejected_conns++; continue
 *         found:     client_init(&r->clients[i], cfd); r->fds[i + 1].fd = cfd;
 *                    r->accepted++; r->active++;
 * Return GW_OK after draining the accept queue; return GW_EIO for a hard accept failure.
 * The starter accepts nothing: connections queue up behind the listener. */
static gw_status_t handle_listener(reactor_t *r)
{
    for (;;) {
        int cfd = accept(r->listen_fd, NULL, NULL);
        if (cfd < 0) {
            if (errno == EINTR)
                continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return GW_OK;
            fprintf(stderr, "accept: %s\n", strerror(errno));
            return GW_EIO;
        }
        if (tcp_set_nonblocking(cfd) != GW_OK) {
            close(cfd);
            continue;
        }
        size_t i;
        for (i = 0; i < REACTOR_MAX_CLIENTS; i++)
            if (r->clients[i].fd == -1)
                break;
        if (i == REACTOR_MAX_CLIENTS) {
            close(cfd);
            r->rejected_conns++;
            continue;
        }
        client_init(&r->clients[i], cfd);
        r->fds[i + 1].fd = cfd;
        r->accepted++;
        r->active++;
    }
}

/* Close client slot i and free it — no stale poll entry, no moved client. */
static void drop_client(reactor_t *r, size_t i, int orderly)
{
    r->framed_events   += r->clients[i].events;      /* fold this connection's tallies in */
    r->framed_rejected += r->clients[i].rejected;
    close(r->clients[i].fd);
    r->clients[i].fd = -1;
    r->fds[i + 1].fd = -1;                      /* poll() will skip this slot from now on */
    r->active--;
    if (orderly)
        r->closed_orderly++;
    else
        r->closed_error++;
}

/* D3.6b: a client is ready — read it, and remove it when it is done.
 *   if revents has POLLIN, POLLHUP or POLLERR:
 *     int peer_closed = 0;
 *     gw_status_t rc = client_read(&r->clients[i], r->emit, r->ctx, &peer_closed);
 *     - rc != GW_OK      -> drop_client(r, i, 0)   (overlong record or read error)
 *     - peer_closed      -> drop_client(r, i, 1)   (orderly close AFTER its final bytes were framed)
 * The starter never reads: poll() keeps reporting the same client ready. */
static void handle_client(reactor_t *r, size_t i)
{
    int peer_closed = 0;
    gw_status_t rc = client_read(&r->clients[i], r->emit, r->ctx, &peer_closed);
    if (rc != GW_OK) {
        drop_client(r, i, 0);
        return;
    }
    if (peer_closed)
        drop_client(r, i, 1);
}

gw_status_t reactor_step(reactor_t *r, int timeout_ms)
{
    if (!r || r->listen_fd < 0 || timeout_ms < -1)
        return GW_EINVAL;
    int n;
    for (;;) {
        n = poll(r->fds, REACTOR_MAX_CLIENTS + 1, timeout_ms);
        if (n >= 0)
            break;
        if (errno == EINTR)
            continue;                           /* a signal, not a failure: wait again */
        return GW_EIO;                          /* real poll failure: errno kept */
    }
    if (n == 0)
        return GW_OK;                           /* timeout: nothing ready, nothing to do */

    short lr = r->fds[0].revents;
    if (lr & (POLLERR | POLLHUP | POLLNVAL)) {
        errno = EIO;
        return GW_EIO;
    }
    if ((lr & POLLIN) && handle_listener(r) != GW_OK)
        return GW_EIO;                          /* D3.6a */

    for (size_t i = 0; i < REACTOR_MAX_CLIENTS; i++) {
        if (r->clients[i].fd < 0)
            continue;
        short re = r->fds[i + 1].revents;
        if (re & POLLNVAL) {
            drop_client(r, i, 0);
            continue;
        }
        if (re & (POLLIN | POLLHUP | POLLERR))
            handle_client(r, i);                /* D3.6b */
    }
    return GW_OK;
}

void reactor_shutdown(reactor_t *r)
{
    if (!r)
        return;
    for (size_t i = 0; i < REACTOR_MAX_CLIENTS; i++)
        if (r->clients[i].fd >= 0)
            drop_client(r, i, 1);
    if (r->listen_fd >= 0)
        close(r->listen_fd);
    r->listen_fd = -1;
    r->fds[0].fd = -1;
}
