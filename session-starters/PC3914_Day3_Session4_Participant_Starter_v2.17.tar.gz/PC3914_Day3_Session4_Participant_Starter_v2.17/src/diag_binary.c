/* diag_binary.c — fixed records, guarded offsets, honest failures. */
#include "diag_binary.h"
#include <limits.h>
#include <string.h>

void diag_record_init(diag_record_t *r, uint32_t module_id, int16_t rssi_dbm,
                      uint16_t flags, uint64_t sequence)
{
    if (!r)
        return;
    memset(r, 0, sizeof *r);
    r->magic = DIAG_BIN_MAGIC;
    r->version = DIAG_BIN_VERSION;
    r->flags = flags;
    r->module_id = module_id;
    r->rssi_dbm = rssi_dbm;
    r->sequence = sequence;
}

int diag_record_valid(const diag_record_t *r)
{
    return r && r->magic == DIAG_BIN_MAGIC && r->version == DIAG_BIN_VERSION;
}

gw_status_t diag_bin_append(FILE *f, const diag_record_t *r)
{
    if (!f || !r || !diag_record_valid(r))
        return GW_EINVAL;
    return fwrite(r, sizeof *r, 1, f) == 1 ? GW_OK : GW_EIO;
}

gw_status_t diag_bin_count(FILE *f, size_t *out_count)
{
    if (!f || !out_count)
        return GW_EINVAL;
    if (fseek(f, 0L, SEEK_END) != 0)
        return GW_EIO;
    long size = ftell(f);
    if (size < 0)
        return GW_EIO;
    if ((size_t)size % sizeof(diag_record_t) != 0)
        return GW_EINVAL;
    *out_count = (size_t)size / sizeof(diag_record_t);
    return GW_OK;
}

gw_status_t diag_bin_read_at(FILE *f, size_t index, diag_record_t *out)
{
    if (!f || !out)
        return GW_EINVAL;
    if (index > (size_t)LONG_MAX / sizeof(diag_record_t))
        return GW_EINVAL;
    long offset = (long)(index * sizeof(diag_record_t));
    if (fseek(f, offset, SEEK_SET) != 0)
        return GW_EIO;
    diag_record_t r;
    if (fread(&r, sizeof r, 1, f) != 1)
        return ferror(f) ? GW_EIO : GW_ENOENT;
    if (!diag_record_valid(&r))
        return GW_EINVAL;
    *out = r;
    return GW_OK;
}

static int diag_index_valid(const diag_index_t *ix)
{
    if (!ix || ix->magic != DIAG_INDEX_MAGIC || ix->version != DIAG_INDEX_VERSION ||
        ix->count > DIAG_INDEX_SLOTS)
        return 0;
    size_t used = 0;
    for (size_t i = 0; i < DIAG_INDEX_SLOTS; i++) {
        if (ix->slot[i].used > 1)
            return 0;
        if (ix->slot[i].used)
            used++;
    }
    return used == ix->count;
}

void diag_index_init(diag_index_t *ix)
{
    if (!ix)
        return;
    memset(ix, 0, sizeof *ix);
    ix->magic = DIAG_INDEX_MAGIC;
    ix->version = DIAG_INDEX_VERSION;
}

gw_status_t diag_index_put(diag_index_t *ix, uint32_t module_id, uint64_t record_index)
{
    if (!diag_index_valid(ix))
        return GW_EINVAL;
    size_t h = module_id % DIAG_INDEX_SLOTS;
    for (size_t probe = 0; probe < DIAG_INDEX_SLOTS; probe++) {
        diag_index_slot_t *slot = &ix->slot[(h + probe) % DIAG_INDEX_SLOTS];
        if (slot->used && slot->module_id == module_id) {
            slot->record_index = record_index;
            return GW_OK;
        }
        if (!slot->used) {
            slot->used = 1;
            slot->module_id = module_id;
            slot->record_index = record_index;
            ix->count++;
            return GW_OK;
        }
    }
    return GW_ENOSPACE;
}

gw_status_t diag_index_get(const diag_index_t *ix, uint32_t module_id, uint64_t *out_index)
{
    if (!out_index || !diag_index_valid(ix))
        return GW_EINVAL;
    size_t h = module_id % DIAG_INDEX_SLOTS;
    for (size_t probe = 0; probe < DIAG_INDEX_SLOTS; probe++) {
        const diag_index_slot_t *slot = &ix->slot[(h + probe) % DIAG_INDEX_SLOTS];
        if (!slot->used)
            return GW_ENOENT;
        if (slot->module_id == module_id) {
            *out_index = slot->record_index;
            return GW_OK;
        }
    }
    return GW_ENOENT;
}

gw_status_t diag_index_save(const diag_index_t *ix, FILE *f)
{
    if (!f || !diag_index_valid(ix))
        return GW_EINVAL;
    return fwrite(ix, sizeof *ix, 1, f) == 1 ? GW_OK : GW_EIO;
}

gw_status_t diag_index_load(diag_index_t *ix, FILE *f)
{
    if (!ix || !f)
        return GW_EINVAL;
    diag_index_t tmp;
    if (fread(&tmp, sizeof tmp, 1, f) != 1)
        return ferror(f) ? GW_EIO : GW_EINVAL;
    if (!diag_index_valid(&tmp))
        return GW_EINVAL;
    *ix = tmp;
    return GW_OK;
}
