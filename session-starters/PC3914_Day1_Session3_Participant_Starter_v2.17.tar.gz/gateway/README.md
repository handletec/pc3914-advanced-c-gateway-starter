# PC3914 Day 1 — Session 3 Participant Entry Snapshot

**Course:** PC3914 — Advanced C Programming: From Basic C to Systems-Ready  
**Material version:** v2.17

Session 1 and Session 2 contracts are completed in this standalone entry state. Session 3 adds only the batch-lifetime arena and diagnostic snapshot work.

## Current participant work
- Complete aligned, bounded `arena_alloc` plus overflow-safe array allocation.
- Build snapshot data as arena-owned copies and complete the snapshot/reset cycle.
- Use the prepared crash and memory examples as directed.

## Working rule
Use this session-entry snapshot for the current session and keep your previous work separately. Follow the Participant Practical Guide for the current activity and verification steps.

## Build and verification
Run `make course-status` first, then use the commands in the Participant Practical Guide for the current activity or lab.
