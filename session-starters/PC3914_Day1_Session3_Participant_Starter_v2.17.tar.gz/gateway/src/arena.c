/* arena.c — minimal bump-pointer arena (Block 3).
 * Participants complete TODO-L3.1a/b/c in arena_alloc / arena_alloc_array. */
#include "arena.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>

gw_status_t arena_init(arena_t *a, size_t capacity)
{
    a->base = NULL;
    a->capacity = 0;
    a->offset = 0;
    if (capacity == 0)
        return GW_EINVAL;
    a->base = gw_malloc(capacity);          /* the ONE backing allocation */
    if (!a->base)
        return GW_ENOMEM;
    a->capacity = capacity;
    return GW_OK;
}

/* TODO-L3.1: this version hands out bytes back to back with no alignment
 * and no capacity check. It "works" until a request crosses the end of the
 * backing block or an unaligned pointer is used as a struct.
 * Required:
 *   L3.1a  round the offset up to a multiple of ARENA_ALIGN before use
 *          (guard the rounding arithmetic against overflow)
 *   L3.1b  refuse a request that does not fit: return NULL, arena unchanged
 *          (compare without adding: size > capacity - aligned_offset) */
void *arena_alloc(arena_t *a, size_t size)
{
    assert(a->base != NULL);                /* invariant: initialised */
    assert(a->offset <= a->capacity);       /* invariant: never over-committed */
    if (size == 0)
        return NULL;

    void *p = a->base + a->offset;
    a->offset += size;
    return p;
}

/* TODO-L3.1c: guard count * size against overflow before calling arena_alloc. */
void *arena_alloc_array(arena_t *a, size_t count, size_t size)
{
    return arena_alloc(a, count * size);
}

void arena_reset(arena_t *a)
{
    assert(a->offset <= a->capacity);
#ifndef NDEBUG
    /* Debug builds poison released bytes so a pointer used after reset
     * reads 0xA5 garbage instead of stale-but-plausible data. */
    if (a->base)
        memset(a->base, 0xA5, a->offset);
#endif
    a->offset = 0;
}

void arena_destroy(arena_t *a)
{
    gw_free(a->base);                       /* gw_free(NULL) is a no-op */
    a->base = NULL;
    a->capacity = 0;
    a->offset = 0;
}

size_t arena_used(const arena_t *a)      { return a->offset; }
size_t arena_remaining(const arena_t *a) { return a->capacity - a->offset; }
