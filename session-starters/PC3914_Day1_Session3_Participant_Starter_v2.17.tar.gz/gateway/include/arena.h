#ifndef ARENA_H
#define ARENA_H
#include "gw_status.h"
#include <stddef.h>
#include <stdalign.h>

/* A minimal bump-pointer arena.
 *
 * Lifetime model: every allocation lives until the NEXT arena_reset() or
 * arena_destroy(). There is no per-allocation free and no realloc. Use it
 * only for data that dies together as a batch (e.g. one diagnostic snapshot).
 * Data with independent lifetime stays on the ordinary heap (event_store_t). */
typedef struct {
    unsigned char *base;       /* one backing allocation (gw_malloc) */
    size_t         capacity;   /* bytes available in base */
    size_t         offset;     /* bytes handed out so far; always a multiple of ARENA_ALIGN */
} arena_t;

/* Every pointer returned by arena_alloc is aligned to this. malloc() already
 * guarantees `base` is aligned for any fundamental type, so aligning the
 * offset is enough. */
#define ARENA_ALIGN alignof(max_align_t)

/* Allocates the backing storage. GW_EINVAL if capacity == 0, GW_ENOMEM if
 * the heap allocation fails (arena left with base == NULL). */
gw_status_t arena_init(arena_t *a, size_t capacity);

/* Returns `size` bytes aligned to ARENA_ALIGN, or NULL if the request does
 * not fit in the remaining capacity (the arena is unchanged) or size == 0.
 * Running out of space is an EXPECTED outcome: the caller decides. */
void *arena_alloc(arena_t *a, size_t size);

/* count * size bytes, guarded against multiplication overflow. */
void *arena_alloc_array(arena_t *a, size_t count, size_t size);

/* Releases every allocation at once. offset returns to 0; the backing storage
 * is kept for reuse. EVERY pointer previously returned is invalid after this
 * call — the same bytes will be handed out again. */
void arena_reset(arena_t *a);

/* Frees the backing storage. base becomes NULL; capacity and offset 0.
 * Safe to call on an arena whose init failed, or twice. */
void arena_destroy(arena_t *a);

size_t arena_used(const arena_t *a);
size_t arena_remaining(const arena_t *a);

#endif
