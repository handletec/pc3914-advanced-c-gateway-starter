/* test_arena.c — executable invariants of the arena.
 * Groups run in order; the first failing assert names the TODO. */
#include "arena.h"
#include "gw_alloc.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static int in_arena(const arena_t *a, const void *p, size_t size)
{
    const unsigned char *q = p;
    return q >= a->base && size <= a->capacity && q <= a->base + a->capacity - size;
}

static void test_bump(void)
{
    arena_t a;
    assert(arena_init(&a, 256) == GW_OK);
    assert(a.base != NULL && a.capacity == 256 && a.offset == 0);

    unsigned char *p1 = arena_alloc(&a, 16);
    unsigned char *p2 = arena_alloc(&a, 16);
    assert(p1 && p2 && p2 > p1);                     /* distinct, increasing */
    assert(in_arena(&a, p1, 16) && in_arena(&a, p2, 16));
    assert(arena_used(&a) >= 32);
    memset(p1, 0x11, 16);
    memset(p2, 0x22, 16);
    assert(p1[15] == 0x11 && p2[0] == 0x22);         /* no overlap */

    arena_destroy(&a);
    puts("[bump]     OK");
}

static void test_align(void)
{
    arena_t a;
    assert(arena_init(&a, 1024) == GW_OK);

    void *p = arena_alloc(&a, 1);                    /* odd size ... */
    void *q = arena_alloc(&a, sizeof(double));       /* ... next block must still be aligned */
    assert(p && q);
    assert((uintptr_t)q % ARENA_ALIGN == 0
           && "TODO-L3.1a: align the offset before handing out memory");
    assert((unsigned char *)q - (unsigned char *)p == ARENA_ALIGN);   /* 1 byte rounded up to one unit */

    for (int i = 0; i < 20; i++) {
        void *r = arena_alloc(&a, (size_t)(i % 7) + 1);
        assert(r && (uintptr_t)r % ARENA_ALIGN == 0);
    }
    arena_destroy(&a);
    puts("[align]    OK");
}

static void test_capacity(void)
{
    arena_t a;
    assert(arena_init(&a, 64) == GW_OK);

    void *p = arena_alloc(&a, 48);
    assert(p && in_arena(&a, p, 48));
    size_t used = arena_used(&a);

    assert(arena_alloc(&a, 32) == NULL
           && "TODO-L3.1b: refuse a request that does not fit");
    assert(arena_used(&a) == used);                  /* refused request changed nothing */
    assert(arena_alloc(&a, SIZE_MAX) == NULL);       /* no wrap-around */
    assert(arena_alloc(&a, 0) == NULL);

    void *q = arena_alloc(&a, 16);                   /* exactly what is left still works */
    assert(q && in_arena(&a, q, 16));
    assert(arena_remaining(&a) == 0);
    assert(arena_alloc(&a, 1) == NULL);

    arena_destroy(&a);
    puts("[capacity] OK");
}

static void test_overflow(void)
{
    arena_t a;
    assert(arena_init(&a, 256) == GW_OK);

    assert(arena_alloc_array(&a, SIZE_MAX / 2 + 1, 4) == NULL
           && "TODO-L3.1c: guard count * size");     /* would wrap to a small number */
    assert(arena_alloc_array(&a, SIZE_MAX, SIZE_MAX) == NULL);
    assert(arena_used(&a) == 0);

    void *ok = arena_alloc_array(&a, 4, 8);
    assert(ok && arena_used(&a) == 32);
    assert(arena_alloc_array(&a, 0, 8) == NULL);

    arena_destroy(&a);
    puts("[overflow] OK");
}

static void test_reset(void)
{
    arena_t a;
    assert(arena_init(&a, 256) == GW_OK);

    char *s1 = arena_alloc(&a, 32);
    assert(s1);
    strcpy(s1, "SIM_NOT_READY");
    (void)arena_alloc(&a, 100);

    arena_reset(&a);
    assert(arena_used(&a) == 0);

    /* The same bytes are handed out again: whatever s1 pointed at is gone. */
    char *s2 = arena_alloc(&a, 32);
    assert(s2 == s1);
    assert(strcmp(s2, "SIM_NOT_READY") != 0);        /* debug poison: not the old text */
    strcpy(s2, "NETWORK_LOST");

    arena_destroy(&a);
    puts("[reset]    OK");
}

static void test_lifecycle(void)
{
    arena_t a;
    size_t live = gw_alloc_live_count();

    assert(arena_init(&a, 0) == GW_EINVAL);
    assert(a.base == NULL);
    arena_destroy(&a);                               /* safe on a failed init */

    gw_alloc_fail_after(0);
    assert(arena_init(&a, 1024) == GW_ENOMEM);
    assert(a.base == NULL && a.capacity == 0);

    assert(arena_init(&a, 1024) == GW_OK);
    assert(gw_alloc_live_count() == live + 1);       /* exactly one backing block */
    for (int i = 0; i < 50; i++)
        assert(arena_alloc(&a, 16));
    assert(gw_alloc_live_count() == live + 1);       /* still one: no per-allocation malloc */

    arena_destroy(&a);
    arena_destroy(&a);                               /* second destroy is a no-op */
    assert(gw_alloc_live_count() == live);
    puts("[lifecycle] OK");
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *g = argc > 1 ? argv[1] : "all";
    int all = strcmp(g, "all") == 0;

    if (all || !strcmp(g, "bump"))      test_bump();
    if (all || !strcmp(g, "align"))     test_align();
    if (all || !strcmp(g, "capacity"))  test_capacity();
    if (all || !strcmp(g, "overflow"))  test_overflow();
    if (all || !strcmp(g, "reset"))     test_reset();
    if (all || !strcmp(g, "lifecycle")) test_lifecycle();

    puts("test_arena: all groups passed");
    return 0;
}
