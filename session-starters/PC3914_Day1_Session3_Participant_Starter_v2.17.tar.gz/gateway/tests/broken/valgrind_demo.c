/* valgrind_demo.c — PREPARED PARTICIPANT DIAGNOSTIC FIXTURE. One small, deliberate defect per mode so the
 * class can read each kind of valgrind report on real gateway code.
 *   ./build/valgrind_demo leak      definitely + indirectly lost
 *   ./build/valgrind_demo uaf       invalid read after free
 *   ./build/valgrind_demo overflow  invalid write past a heap block
 *   ./build/valgrind_demo clean     no errors, all blocks freed */
#include "event.h"
#include "gw_alloc.h"
#include <stdio.h>
#include <string.h>

static const event_view_t v1 = { 3, EV_ERROR,  -113, "SIM_NOT_READY", 13 };
static const event_view_t v2 = { 5, EV_ERROR,  -101, "NETWORK_LOST",  12 };

static int demo_leak(void)
{
    event_t *last = event_clone(&v1);
    last = event_clone(&v2);                /* the first clone is now unreachable */
    printf("last error: %s\n", last->payload);
    event_free(last);
    return 0;
}

static int demo_uaf(void)
{
    event_t *e = event_clone(&v1);
    event_free(e);
    printf("payload: %s\n", e->payload);    /* e was freed on the line above */
    return 0;
}

static int demo_overflow(void)
{
    size_t len = v1.payload_len;
    char *copy = gw_malloc(len);            /* room for the bytes, not the terminator */
    memcpy(copy, v1.payload, len);
    copy[len] = '\0';                       /* one byte past the block */
    printf("copy: %s\n", copy);
    gw_free(copy);
    return 0;
}

static int demo_clean(void)
{
    event_t *e = event_clone(&v1);
    printf("payload: %s\n", e->payload);
    event_free(e);
    return 0;
}

int main(int argc, char **argv)
{
    const char *mode = argc > 1 ? argv[1] : "clean";
    if (!strcmp(mode, "leak"))     return demo_leak();
    if (!strcmp(mode, "uaf"))      return demo_uaf();
    if (!strcmp(mode, "overflow")) return demo_overflow();
    return demo_clean();
}
