# PC3914 Day 3 Session 3 Notes

Use this file for observations, commands, evidence and questions during the current session.
