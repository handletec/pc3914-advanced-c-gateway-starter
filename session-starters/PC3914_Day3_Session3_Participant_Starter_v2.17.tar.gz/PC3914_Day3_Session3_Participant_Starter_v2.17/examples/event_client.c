/* event_client.c — a loopback test client for the gateway's Reactor (Day 3 Block 3, prepared).
 *
 * Connects to 127.0.0.1:<port>, then writes standard input to the socket —
 * deliberately BADLY, when asked, to prove the gateway frames a byte stream:
 *
 *   event_client <port>                      write stdin as it comes
 *   event_client <port> --fragment 7         write 7 bytes at a time, with a pause
 *   event_client <port> --delay-us 2000      pause between writes (default 1000)
 *
 * Fragmenting a client does not fragment TCP itself — the point is that the
 * RECEIVER must not care either way. */
#define _POSIX_C_SOURCE 200809L
#include "gw_io.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <port> [--fragment BYTES] [--delay-us US] < events.txt\n", argv[0]);
        return 2;
    }
    char *endp = NULL;
    errno = 0;
    if (argv[1][0] == '-' || argv[1][0] == '\0')
        return 2;
    unsigned long port_ul = strtoul(argv[1], &endp, 10);
    if (errno != 0 || *endp != '\0' || port_ul == 0 || port_ul > 65535)
        return 2;
    size_t fragment = 0;
    long delay_us = 1000;
    int i = 2;
    while (i < argc) {
        const char *opt = argv[i++];
        if (strcmp(opt, "--fragment") != 0 && strcmp(opt, "--delay-us") != 0)
            return 2;
        if (i >= argc)
            return 2;
        const char *val = argv[i++];
        if (val[0] == '-' || val[0] == '\0')
            return 2;
        errno = 0; endp = NULL;
        unsigned long v = strtoul(val, &endp, 10);
        if (errno != 0 || *endp != '\0')
            return 2;
        if (strcmp(opt, "--fragment") == 0) {
            if (v == 0 || v > SIZE_MAX) return 2;
            fragment = (size_t)v;
        } else {
            if (v > 10000000UL) return 2;
            delay_us = (long)v;
        }
    }
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return 1;
    }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port   = htons((uint16_t)port_ul);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (connect(fd, (struct sockaddr *)&addr, sizeof addr) != 0) {
        perror("connect");
        close(fd);
        return 1;
    }

    char buf[4096];
    size_t total = 0, writes = 0;
    ssize_t n;
    while ((n = read(STDIN_FILENO, buf, sizeof buf)) != 0) {
        if (n < 0) {
            if (errno == EINTR)
                continue;
            perror("read(stdin)");
            close(fd);
            return 1;
        }
        size_t off = 0;
        while (off < (size_t)n) {
            size_t chunk = fragment ? fragment : (size_t)n - off;
            if (chunk > (size_t)n - off)
                chunk = (size_t)n - off;
            if (write_all(fd, buf + off, chunk) != GW_OK) {   /* Block 1's loop, reused on a socket */
                perror("write");
                close(fd);
                return 1;
            }
            off += chunk;
            writes++;
            if (fragment && delay_us > 0) {
                struct timespec ts = { delay_us / 1000000, (delay_us % 1000000) * 1000L };
                nanosleep(&ts, NULL);
            }
        }
        total += (size_t)n;
    }
    close(fd);                                   /* orderly close: the gateway sees EOF for this client */
    fprintf(stderr, "event_client: sent %zu bytes in %zu writes\n", total, writes);
    return 0;
}
