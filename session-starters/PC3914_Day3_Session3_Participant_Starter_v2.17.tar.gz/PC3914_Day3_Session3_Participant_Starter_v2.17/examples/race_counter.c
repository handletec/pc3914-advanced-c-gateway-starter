/* race_counter.c — ONE intended defect: `counter++` from four threads with no
 * synchronisation (Day 3 Block 2, trainer demo).
 *
 * Every thread is created, every thread is joined, nothing is freed early:
 * the only bug is the data race. `counter++` is three steps — load, add,
 * store — and two threads can both load the same value, both add one, and
 * both store: one increment is lost. The result varies from run to run. */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define THREADS 4
#define PER_THREAD 1000000

static long counter;                                  /* shared; unprotected: THE defect */

static void *bump(void *arg)
{
    (void)arg;
    for (int i = 0; i < PER_THREAD; i++)
        counter++;                                    /* load, add, store — not atomic */
    return NULL;
}

int main(void)
{
    pthread_t t[THREADS];
    for (int i = 0; i < THREADS; i++) {
        int rc = pthread_create(&t[i], NULL, bump, NULL);
        if (rc != 0) {                                /* pthread returns the error number; errno is not set */
            fprintf(stderr, "pthread_create: %s\n", strerror(rc));
            return 1;
        }
    }
    for (int i = 0; i < THREADS; i++) {
        int rc = pthread_join(t[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_join: %s\n", strerror(rc));
            return 1;
        }
    }
    printf("counter = %ld   (expected %d)\n", counter, THREADS * PER_THREAD);
    return counter == THREADS * PER_THREAD ? 0 : 1;
}
