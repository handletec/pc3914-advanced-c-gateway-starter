/* counter_mutex.c — the same program with the invariant protected (Day 3 Block 2).
 *
 * The mutex does not "make counter++ atomic"; it makes the three steps
 * happen while no other thread can touch counter. The invariant being
 * protected is "counter equals the number of completed increments". */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define THREADS 4
#define PER_THREAD 1000000

static long            counter;
static pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;

static void *bump(void *arg)
{
    (void)arg;
    for (int i = 0; i < PER_THREAD; i++) {
        pthread_mutex_lock(&counter_mutex);
        counter++;
        pthread_mutex_unlock(&counter_mutex);
    }
    return NULL;
}

int main(void)
{
    pthread_t t[THREADS];
    for (int i = 0; i < THREADS; i++) {
        int rc = pthread_create(&t[i], NULL, bump, NULL);
        if (rc != 0) {                                /* pthread returns the error number; errno is not set */
            fprintf(stderr, "pthread_create: %s\n", strerror(rc));
            return 1;
        }
    }
    for (int i = 0; i < THREADS; i++) {
        int rc = pthread_join(t[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_join: %s\n", strerror(rc));
            return 1;
        }
    }
    printf("counter = %ld   (expected %d)\n", counter, THREADS * PER_THREAD);
    return counter == THREADS * PER_THREAD ? 0 : 1;
}
