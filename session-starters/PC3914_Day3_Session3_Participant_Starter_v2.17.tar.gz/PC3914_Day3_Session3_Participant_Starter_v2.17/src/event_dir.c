/* event_dir.c — bounded, filtered directory traversal (Day 3 Block 1, reference). */
#define _POSIX_C_SOURCE 200809L
#include "event_dir.h"
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

/* D3.1a: an event input is a name that
 *   - does not start with '.'  (".", "..", ".stale.txt" are all skipped)
 *   - ends in ".txt" and is longer than ".txt" itself
 * Nothing else: "notes.md", "README", "events.txt.bak" are skipped. */
int event_dir_accept(const char *name)
{
    if (name[0] == '.')
        return 0;                               /* D3.1a: ".", ".." and dot-files */
    size_t n = strlen(name);
    return n > 4 && strcmp(name + n - 4, ".txt") == 0;
}

/* D3.1b: write "<dir>/<name>" into out[cap]. If dir already ends in '/',
 * do not add a second one. Use snprintf and CHECK its return value: when the
 * result would not fit, set out[0] = '\0' and return GW_ENOSPACE — never a
 * silently truncated path. */
gw_status_t event_dir_join(char *out, size_t cap, const char *dir, const char *name)
{
    size_t dlen = strlen(dir);
    const char *sep = (dlen && dir[dlen - 1] == '/') ? "" : "/";
    int n = snprintf(out, cap, "%s%s%s", dir, sep, name);   /* D3.1b: n = length it WANTED to write */
    if (n < 0 || (size_t)n >= cap) {
        if (cap)
            out[0] = '\0';                          /* would have been truncated: refuse */
        return GW_ENOSPACE;
    }
    return GW_OK;
}

static int cmp_path(const void *a, const void *b)
{
    return strcmp(((const event_path_t *)a)->path, ((const event_path_t *)b)->path);
}

gw_status_t event_dir_list(const char *dir, event_path_t *out, size_t max, size_t *count)
{
    *count = 0;
    DIR *d = opendir(dir);
    if (!d)
        return GW_ENOENT;                       /* errno from opendir kept for the caller's message */

    gw_status_t rc = GW_OK;
    for (;;) {
        errno = 0;                              /* readdir returns NULL for both end and error */
        struct dirent *ent = readdir(d);
        if (!ent) {
            if (errno != 0)
                rc = GW_EIO;
            break;
        }
        if (!event_dir_accept(ent->d_name))     /* rule 1: explicit filter */
            continue;
        if (*count == max) {
            rc = GW_ENOSPACE;
            break;
        }
        event_path_t *p = &out[*count];
        rc = event_dir_join(p->path, sizeof p->path, dir, ent->d_name);   /* rule 2: bounded path */
        if (rc != GW_OK)
            break;
        struct stat st;                         /* rule 3: stat decides, d_type is only a hint */
        if (stat(p->path, &st) != 0) {
            rc = GW_EIO;
            break;
        }
        if (!S_ISREG(st.st_mode))
            continue;                           /* directory or other: not an input; slot reused */
        (*count)++;
    }
    closedir(d);
    if (rc != GW_OK) {
        *count = 0;
        return rc;
    }
    qsort(out, *count, sizeof out[0], cmp_path);
    return GW_OK;
}
