/* gw_io.c — "some bytes" into "all bytes" (Day 3 Block 1, reference). */
#define _POSIX_C_SOURCE 200809L
#include "gw_io.h"
#include <errno.h>
#include <unistd.h>

gw_io_stats_t gw_io_stats;

/* D3.2a: write every byte of buf[0..len).
 *   - call write(fd, p, remaining); it returns ssize_t: -1 on error, else bytes moved
 *   - -1 with errno == EINTR: count a retry and try the SAME bytes again
 *   - -1 otherwise: return GW_EIO (errno already says why)
 *   - n < remaining: count a short write; advance p by n, remaining -= n, continue
 *   - keep `remaining` as size_t; convert n only after checking n >= 0
 */
gw_status_t write_all(int fd, const void *buf, size_t len)
{
    const unsigned char *p = buf;
    size_t remaining = len;
    while (remaining > 0) {
        ssize_t n = write(fd, p, remaining);    /* D3.2a: "some bytes" */
        if (n < 0) {
            if (errno == EINTR) {
                gw_io_stats.eintr_retries++;
                continue;                       /* nothing moved: the same request again */
            }
            return GW_EIO;                      /* hard failure: EPIPE, EBADF, ENOSPC ... errno says */
        }
        if ((size_t)n < remaining)
            gw_io_stats.short_writes++;         /* pipe full, signal after partial transfer: keep going */
        p += n;                                 /* advance by what was written ... */
        remaining -= (size_t)n;                 /* ... n is >= 0 here, so the conversion is safe */
    }
    return GW_OK;
}

/* Prepared: read until len bytes or EOF. */
gw_status_t read_full(int fd, void *buf, size_t len, size_t *got)
{
    unsigned char *p = buf;
    size_t remaining = len;
    *got = 0;
    while (remaining > 0) {
        ssize_t n = read(fd, p, remaining);
        if (n < 0) {
            if (errno == EINTR) {
                gw_io_stats.eintr_retries++;
                continue;                       /* interrupted before any byte moved: same request again */
            }
            return GW_EIO;
        }
        if (n == 0)
            break;                              /* EOF: every writer has closed its end */
        if ((size_t)n < remaining)
            gw_io_stats.short_reads++;          /* fewer than asked: normal, keep going */
        p += n;
        remaining -= (size_t)n;
        *got += (size_t)n;
    }
    return GW_OK;
}
