/* tcp_server.c — loopback listener lifecycle (Day 3 Block 3, prepared). */
#define _POSIX_C_SOURCE 200809L
#include "tcp_server.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

gw_status_t tcp_set_nonblocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);          /* read the current flags ... */
    if (flags < 0)
        return GW_EIO;
    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0)   /* ... and add O_NONBLOCK, changing nothing else */
        return GW_EIO;
    return GW_OK;
}

gw_status_t tcp_listener_open(uint16_t port, int *listen_fd, uint16_t *bound_port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0)
        return GW_EIO;

    int on = 1;
    struct sockaddr_in addr;
    socklen_t alen = sizeof addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(port);                       /* 0: the kernel chooses */
    if (inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr) != 1)
        goto fail;                                       /* loopback only, by construction */

    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on) != 0 ||
        bind(fd, (struct sockaddr *)&addr, sizeof addr) != 0 ||
        listen(fd, 8) != 0 ||
        getsockname(fd, (struct sockaddr *)&addr, &alen) != 0 ||
        tcp_set_nonblocking(fd) != GW_OK)
        goto fail;

    *listen_fd  = fd;
    *bound_port = ntohs(addr.sin_port);                  /* the real port, also when 0 was asked */
    return GW_OK;

fail:
    {
        int saved = errno;                               /* close() may clobber errno */
        close(fd);                                       /* no descriptor survives a partial failure */
        errno = saved;
    }
    return GW_EIO;
}
