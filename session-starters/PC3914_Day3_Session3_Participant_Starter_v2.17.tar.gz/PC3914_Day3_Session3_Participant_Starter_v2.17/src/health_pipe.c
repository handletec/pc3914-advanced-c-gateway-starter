/* health_pipe.c — pipe, fork, exec, waitpid (Day 3 Block 1, reference). */
#define _POSIX_C_SOURCE 200809L
#include "health_pipe.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

gw_status_t spawn_reporter(const char *reporter_exe, int *write_fd, pid_t *pid)
{
    int fds[2];
    if (pipe(fds) != 0)
        return GW_EIO;                                  /* errno from pipe() */

    fflush(stdout);                                     /* the child inherits stdio buffers too: empty them first */
    pid_t child = fork();
    if (child < 0) {
        int saved = errno;
        close(fds[0]);
        close(fds[1]);
        errno = saved;
        return GW_EIO;
    }

    if (child == 0) {                                   /* ---- child: continues here with BOTH ends ---- */
        close(fds[1]);                                  /* D3.2b: the child must not hold a write end */
        if (dup2(fds[0], STDIN_FILENO) < 0)             /* stdin now IS the read end */
            _exit(126);
        close(fds[0]);                                  /* D3.2b: after dup2 the original is redundant */
        execl(reporter_exe, "health_reporter", (char *)NULL);   /* replaces this image: no return on success */
        _exit(127);                                     /* only reached when exec failed; _exit: no stdio flush */
    }

    /* ---- parent: continues here with BOTH ends ---- */
    close(fds[0]);                                      /* D3.2c: the parent never reads */
    *write_fd = fds[1];
    *pid = child;
    return GW_OK;
}

gw_status_t finish_reporter(int write_fd, pid_t pid, int *exit_status)
{
    if (close(write_fd) != 0)                           /* last write end in THIS process: the child sees EOF */
        return GW_EIO;
    int status;
    for (;;) {
        if (waitpid(pid, &status, 0) == pid)            /* reap: the kernel can now forget the child */
            break;
        if (errno != EINTR)
            return GW_EIO;                              /* ECHILD: nothing to reap — a logic error upstream */
    }
    *exit_status = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    return GW_OK;
}
