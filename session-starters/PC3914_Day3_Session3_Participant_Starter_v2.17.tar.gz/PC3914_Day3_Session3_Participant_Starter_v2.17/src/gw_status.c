#include "gw_status.h"

const char *gw_strstatus(gw_status_t s)
{
    switch (s) {
    case GW_OK:       return "ok";
    case GW_ENOMEM:   return "out of memory";
    case GW_ENOSPACE: return "arena capacity exhausted";
    case GW_EINVAL:   return "invalid argument";
    case GW_ENOENT:   return "no such entry";
    case GW_EEXIST:   return "entry already exists";
    case GW_EIO:      return "i/o error";
    case GW_ECLOSED:  return "queue closed";
    }
    return "unknown status";
}
