/* gateway.c — Wireless Module Diagnostics Gateway (Day 3 Block 3).
 *
 *   Simulated Module Events (file, or every *.txt in a directory)
 *                                  -> Event Parser -> Diagnostic Engine -> Console
 *                                                  -> Intake Queue (owned, FIFO)
 *                                                       -> Processing stage -> Event Store
 *                                                            -> Snapshot (arena, per window)
 *   Sink registry: diag_sink_list_t (registered diagnostic sinks, Day 3 subscribers)
 *
 * Arrival and processing are separate stages: the parser callback only
 * clones and ENQUEUES; the processing stage DEQUEUES into the store, steps
 * each module's LIFECYCLE (State: module_state_machine, stored in the
 * DEVICE REGISTRY) and raises ALERTS chosen by the selected classification
 * POLICY (Strategy: alert_strategy, picked with --policy at run time) into
 * a priority heap. Trace output is a BUILD-TIME choice (gw_trace: compiled
 * in with -DGW_ENABLE_TRACE=1). Three questions, three mechanisms, no
 * #ifdef in this file.
 *
 * Day 3 Block 1: runtime settings come from a config file (stdio); inputs
 * can be discovered in a directory (opendir/readdir); at the end the gateway
 * can fork+exec a health_reporter child and send it one record through a
 * pipe (descriptor I/O), then reap it.
 *
 * Day 3 Block 2: the intake queue is a thread-safe work_queue_t. With
 * --workers N the processing stage runs on N worker threads; the state they
 * share (store, registry, heap, counters) is protected by ONE state mutex
 * that is never held while waiting on the queue. With N > 1 the per-module
 * event order is no longer guaranteed, so the lifecycle line can differ
 * between runs; every total is the same.
 *
 * Day 3 Block 3: with --listen PORT the input is a byte stream from several
 * loopback TCP clients through ONE poll() Reactor. The Reactor frames
 * complete records, clones and enqueues them in the order it observed, and
 * ONE processing worker keeps the stateful pipeline deterministic — the
 * ordering contract from Block 2, honoured by design. */
#include "event_parser.h"
#include "event_store.h"
#include "diag_engine.h"
#include "diag_snapshot.h"
#include "event_queue.h"
#include "diag_sink_list.h"
#include "device_registry.h"
#include "alert_heap.h"
#include "alert_strategy.h"
#include "module_state_machine.h"
#include "gw_trace.h"
#include "gw_config.h"
#include "event_dir.h"
#include "gw_io.h"
#include "health_report.h"
#include "health_pipe.h"
#include "work_queue.h"
#include "worker_pool.h"
#include "reactor.h"
#include "arena.h"
#include "gw_alloc.h"
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define READ_CHUNK      4096
#define SNAPSHOT_EVERY  50
#define MAX_EVENT_FILES 32

static event_store_t    *store;
static work_queue_t      intake;                /* arrival order, owned events; thread-safe since Day 3 Block 2 */
static pthread_mutex_t   state_mutex = PTHREAD_MUTEX_INITIALIZER;   /* store, registry, heap, counters */
static size_t            n_workers;             /* 0 = process on the main thread */
static worker_pool_t     pool;
static device_registry_t *devices;              /* current state per module_id (opaque handle) */
static alert_heap_t      alerts;                /* most urgent first */
static const alert_strategy_t *policy;          /* classification policy chosen at start-up (Strategy) */
static size_t            queued, processed, raised;
static size_t            transitions, stayed, rejected;   /* lifecycle outcomes (State) */
static arena_t           arena;                 /* snapshot arena; reset after every window */
static parse_result_t    total;                 /* parser totals across every input */
static size_t            reported, snapshots, skipped, arena_peak;

/* Network arrival stage: the Reactor's emit callback. The view points into a
 * client's receive buffer and dies when that buffer is compacted — clone NOW. */
static void net_on_event(const event_view_t *ev, void *ctx);

/* Arrival stage: runs inside the parser callback. */
static void on_event(const event_view_t *ev)
{
    diag_on_event(ev);                          /* engine sees the borrowed view */

    event_t *e = event_clone(ev);               /* retain an owned copy */
    if (!e) {
        fprintf(stderr, "warning: event dropped (out of memory)\n");
        return;
    }
    /* D2.2a: hand the event to the intake queue in arrival order */
    if (work_queue_push(&intake, e) != GW_OK) { /* queue unchanged; we still own e */
        fprintf(stderr, "warning: event dropped (intake queue out of memory or closed)\n");
        event_free(e);
        return;
    }
    queued++;                                   /* main thread only */
}

static void net_on_event(const event_view_t *ev, void *ctx)
{
    (void)ctx;
    on_event(ev);                               /* same clone-then-enqueue path as file input */
}

/* Step the module's lifecycle with this event and store the result.
 * State: the registry holds the current state; the machine decides the next
 * one; this function only moves the value between them and counts outcomes. */
static void update_device(const event_t *e)
{
    device_state_t d = { e->module_id, MOD_OFFLINE, 0, 0 };    /* first sight: OFFLINE */
    const device_state_t *cur = device_registry_find(devices, e->module_id);
    if (cur)
        d = *cur;                                   /* copy out before upsert: growth moves entries */
    d.last_rssi = e->rssi_dbm;
    d.event_count++;

    switch (module_sm_step(&d.state, e)) {          /* current state + event -> next state */
    case SM_TRANSITION:
        transitions++;
        gw_trace("state", e->module_id, module_state_name(d.state));
        break;
    case SM_STAY:     stayed++;   break;
    case SM_REJECTED: rejected++; break;            /* explicit policy: unchanged, counted, not invented */
    }
    if (device_registry_upsert(devices, &d) != GW_OK)
        fprintf(stderr, "warning: registry full, state for module %u not updated\n", e->module_id);
}

/* Raise an alert if the selected policy says so.
 * Strategy: the caller does not know which policy it holds — it asks. */
static void raise_alert(const event_t *e, uint64_t seq)
{
    alert_t a;
    int raise;
    if (alert_classify(policy, e, seq, &a, &raise) != GW_OK || !raise)
        return;                                     /* invalid policy raises nothing; nothing to raise */
    if (alert_heap_push(&alerts, &a) != GW_OK) {    /* the heap is unchanged by any of this */
        fprintf(stderr, "warning: alert dropped (out of memory)\n");
        return;
    }
    raised++;
    gw_trace("alert", e->module_id, a.code);
}

/* D2.2b: the processing stage for ONE event, whoever runs it. Takes
 * ownership of e. Everything it touches is shared state: one lock around it,
 * taken AFTER the queue handed the event over (the queue lock is not held). */
static void process_one(event_t *e, void *ctx)
{
    (void)ctx;
    pthread_mutex_lock(&state_mutex);
    uint64_t seq = event_store_len(store);             /* the gateway sequence number */
    if (event_store_push(store, e) != 0) {             /* store unchanged; still ours */
        pthread_mutex_unlock(&state_mutex);
        fprintf(stderr, "warning: event dropped (store full)\n");
        event_free(e);
        return;
    }
    processed++;                                       /* ownership: us -> store */
    update_device(e);                                  /* e is now store-owned: read only */
    raise_alert(e, seq);
    pthread_mutex_unlock(&state_mutex);
}

/* Main-thread processing (no workers): drain what is queued right now. */
static void process_intake(void)
{
    event_t *e;
    while (work_queue_size(&intake) > 0 && work_queue_pop(&intake, &e) == GW_OK)
        process_one(e, NULL);
}

/* Report line for one device; used through device_registry_for_each. */
static void print_device(const device_state_t *v, void *ctx)
{
    (void)ctx;
    printf("  module %u: %s, last rssi %d dBm, %zu events\n",
           v->module_id, module_state_name(v->state), v->last_rssi, v->event_count);
}

/* L3.2c: snapshot cycle — build, emit, release every complete window.
 * The store is shared with the workers: hold the state lock while a window
 * is built (the queue lock is never involved). */
static void emit_snapshots(void)
{
    pthread_mutex_lock(&state_mutex);
    while (event_store_len(store) - reported >= SNAPSHOT_EVERY) {
        snapshot_t snap;
        size_t first = reported, last = reported + SNAPSHOT_EVERY;
        gw_status_t st = diag_snapshot_build(store, first, last, &arena, &snap);
        if (st == GW_OK) {
            diag_snapshot_emit(&snap, stdout);
            snapshots++;
        } else {
            fprintf(stderr, "snapshot %zu..%zu skipped: %s (arena %zu/%zu bytes)\n",
                    first, last, gw_strstatus(st), arena_used(&arena), arena.capacity);
            skipped++;
        }
        if (arena_used(&arena) > arena_peak)
            arena_peak = arena_used(&arena);
        arena_reset(&arena);                /* snap and everything it points to is now invalid */
        reported = last;
    }
    pthread_mutex_unlock(&state_mutex);
}

/* One input file, read in chunks through stdio; the parse/process/snapshot
 * cycle is unchanged from Day 2. Returns 0, or 1 after a fatal input error. */
static int process_file(const char *path)
{
    FILE *in = fopen(path, "rb");
    if (!in) {
        perror(path);                                       /* errno -> message at the boundary */
        return 1;
    }
    char   buf[READ_CHUNK];
    size_t held = 0;
    int rc = 0;

    for (;;) {
        size_t n = fread(buf + held, 1, sizeof buf - held, in);
        if (n == 0)
            break;
        held += n;

        parse_result_t r = parse_events(buf, held, on_event);
        total.events   += r.events;
        total.rejected += r.rejected;
        memmove(buf, buf + r.consumed, held - r.consumed);
        held -= r.consumed;
        if (held == sizeof buf) {
            fprintf(stderr, "error: record longer than %d bytes\n", READ_CHUNK);
            rc = 1;
            break;
        }

        if (n_workers == 0)
            process_intake();                   /* D2.2b: processing stage, after each read */

        emit_snapshots();                       /* L3.2c: every complete window so far */
    }
    if (ferror(in)) {
        fprintf(stderr, "%s: read error: %s\n", path, strerror(errno));
        rc = 1;
    }
    fclose(in);
    if (held > 0 && rc == 0)
        fprintf(stderr, "warning: %s: %zu bytes of incomplete record at end of input\n", path, held);
    return rc;
}

/* Day 3: hand the health record to a cooperating process through a pipe. */
static int send_health_report(const char *reporter_exe)
{
    health_record_t rec;
    health_record_init(&rec, processed, rejected, raised, device_registry_count(devices));

    int   wfd;
    pid_t child;
    if (spawn_reporter(reporter_exe, &wfd, &child) != GW_OK) {
        fprintf(stderr, "error: cannot start health reporter: %s\n", strerror(errno));
        return 1;
    }
    if (write_all(wfd, &rec, sizeof rec) != GW_OK)          /* EPIPE if the child is already gone */
        fprintf(stderr, "warning: health record not delivered: %s\n", strerror(errno));
    int status;
    if (finish_reporter(wfd, child, &status) != GW_OK) {    /* close write end -> child sees EOF; reap */
        fprintf(stderr, "error: waiting for health reporter: %s\n", strerror(errno));
        return 1;
    }
    printf("health_reporter: pid %ld exited with status %d%s\n", (long)child, status,
           status == 127 ? " (exec failed: check the path)" : "");
    return status == 0 ? 0 : 1;
}

static void usage(const char *prog)
{
    fprintf(stderr, "usage: %s [--config FILE] [--arena BYTES] [--policy NAME] [--report REPORTER_EXE]"
                    " [--workers N] (<events-file> | --events-dir DIR | --listen PORT [--serve-clients N])\n"
                    "  network mode uses exactly ONE processing worker (the ordering contract)\n  policies:", prog);
    for (size_t i = 0; i < alert_strategy_count(); i++)
        fprintf(stderr, " %s", alert_strategy_at(i)->name);
    fputc('\n', stderr);
}

int main(int argc, char **argv)
{
    gw_config_t cfg;
    gw_config_init(&cfg);                                   /* defaults: policy "default", 16384 bytes */
    const char *events_dir = NULL, *reporter_exe = NULL;
    int listen_mode = 0;
    long listen_port = -1;
    size_t serve_clients = 1;
    int workers_given = 0;
    int argi = 1;
    while (argi < argc && argv[argi][0] == '-') {
        const char *opt = argv[argi++];
        if (strcmp(opt, "--config") != 0 && strcmp(opt, "--arena") != 0 &&
            strcmp(opt, "--policy") != 0 && strcmp(opt, "--events-dir") != 0 &&
            strcmp(opt, "--report") != 0 && strcmp(opt, "--workers") != 0 &&
            strcmp(opt, "--listen") != 0 && strcmp(opt, "--serve-clients") != 0) {
            usage(argv[0]); return 2;
        }
        if (argi >= argc) { usage(argv[0]); return 2; }
        const char *val = argv[argi++];
        if (strcmp(opt, "--config") == 0) {
            size_t line; gw_status_t st = gw_config_load(val, &cfg, &line);
            if (st == GW_ENOENT) { fprintf(stderr, "error: %s: %s\n", val, strerror(errno)); return 2; }
            if (st != GW_OK) { fprintf(stderr, "error: %s:%zu: %s\n", val, line, gw_strstatus(st)); return 2; }
        } else if (strcmp(opt, "--arena") == 0) {
            char *endp; errno = 0; if (val[0] == '-' || val[0] == '\0') { usage(argv[0]); return 2; }
            unsigned long v = strtoul(val, &endp, 10);
            if (errno != 0 || *endp != '\0' || v == 0 || v > SIZE_MAX) { usage(argv[0]); return 2; }
            cfg.arena_bytes = (size_t)v;
        } else if (strcmp(opt, "--policy") == 0) {
            if (strlen(val) >= sizeof cfg.policy) { usage(argv[0]); return 2; }
            strcpy(cfg.policy, val);
        } else if (strcmp(opt, "--events-dir") == 0) { events_dir = val;
        } else if (strcmp(opt, "--report") == 0) { reporter_exe = val;
        } else if (strcmp(opt, "--workers") == 0) {
            char *endp; errno = 0; if (val[0] == '-' || val[0] == '\0') { usage(argv[0]); return 2; }
            unsigned long v = strtoul(val, &endp, 10);
            if (errno != 0 || *endp != '\0' || v == 0 || v > WORKER_MAX) { usage(argv[0]); return 2; }
            n_workers = (size_t)v; workers_given = 1;
        } else if (strcmp(opt, "--listen") == 0) {
            char *endp; errno = 0; if (val[0] == '-' || val[0] == '\0') { usage(argv[0]); return 2; }
            unsigned long v = strtoul(val, &endp, 10);
            if (errno != 0 || *endp != '\0' || v > 65535) { usage(argv[0]); return 2; }
            listen_mode = 1; listen_port = (long)v;
        } else if (strcmp(opt, "--serve-clients") == 0) {
            char *endp; errno = 0; if (val[0] == '-' || val[0] == '\0') { usage(argv[0]); return 2; }
            unsigned long v = strtoul(val, &endp, 10);
            if (errno != 0 || *endp != '\0' || v == 0 || v > SIZE_MAX) { usage(argv[0]); return 2; }
            serve_clients = (size_t)v;
        }
    }
    if (listen_mode) {
        if (events_dir != NULL || argc != argi) {           /* network mode takes no file input */
            usage(argv[0]);
            return 2;
        }
        if (workers_given && n_workers != 1) {              /* the ordering contract: ONE stateful worker */
            fprintf(stderr, "error: --listen uses exactly one processing worker\n");
            usage(argv[0]);
            return 2;
        }
        n_workers = 1;
    } else if ((events_dir == NULL) == (argc != argi + 1)) { /* exactly one of: a file, or --events-dir */
        usage(argv[0]);
        return 2;
    }
    policy = alert_strategy_find(cfg.policy);               /* runtime selection, by name (file or option) */
    if (!policy) {
        fprintf(stderr, "error: unknown policy '%s'\n", cfg.policy);
        usage(argv[0]);
        return 2;
    }

    /* Discover inputs before allocating anything: a bad directory is a usage error. */
    event_path_t inputs[MAX_EVENT_FILES];
    size_t n_inputs = 0;
    if (listen_mode) {
        n_inputs = 0;                                       /* input arrives through the Reactor */
    } else if (events_dir) {
        gw_status_t st = event_dir_list(events_dir, inputs, MAX_EVENT_FILES, &n_inputs);
        if (st == GW_ENOENT) {
            fprintf(stderr, "error: %s: %s\n", events_dir, strerror(errno));
            return 2;
        }
        if (st != GW_OK) {
            fprintf(stderr, "error: %s: %s\n", events_dir, gw_strstatus(st));
            return 2;
        }
        if (n_inputs == 0) {
            fprintf(stderr, "error: %s: no event files (*.txt) found\n", events_dir);
            return 2;
        }
    } else {
        if (strlen(argv[argi]) >= sizeof inputs[0].path) {
            fprintf(stderr, "error: path too long\n");
            return 2;
        }
        strcpy(inputs[0].path, argv[argi]);
        n_inputs = 1;
    }

    store = event_store_create(64);
    if (!store) {
        fprintf(stderr, "error: cannot create event store\n");
        return 1;
    }
    gw_status_t st = arena_init(&arena, cfg.arena_bytes);   /* project status code */
    if (st != GW_OK) {
        fprintf(stderr, "error: arena_init(%zu): %s\n", cfg.arena_bytes, gw_strstatus(st));
        event_store_destroy(store);
        return 1;
    }
    int have_intake = work_queue_init(&intake) == GW_OK;
    diag_sink_list_t sinks;
    diag_sink_list_init(&sinks);
    alert_heap_init(&alerts);
    devices = device_registry_create(16);
    if (!have_intake || !devices ||
        diag_sink_list_add(&sinks, 1, "console") != GW_OK ||
        diag_sink_list_add(&sinks, 2, "snapshot-log") != GW_OK) {
        fprintf(stderr, "error: cannot set up intake queue / sink registry\n");
        diag_sink_list_destroy(&sinks);
        work_queue_destroy(&intake);
        device_registry_destroy(devices);
        arena_destroy(&arena);
        event_store_destroy(store);
        return 1;
    }
    diag_init();
    if (n_workers > 0 && worker_pool_start(&pool, &intake, n_workers, process_one, NULL) != GW_OK) {
        /* The unwind inside start closed the shared intake queue and joined
         * whatever was created: this run cannot continue on that queue. */
        fprintf(stderr, "error: cannot start %zu workers — aborting this run\n", n_workers);
        diag_shutdown();
        diag_sink_list_destroy(&sinks);
        work_queue_destroy(&intake);
        device_registry_destroy(devices);
        alert_heap_destroy(&alerts);
        arena_destroy(&arena);
        event_store_destroy(store);
        return 1;
    }

    int rc = 0;
    reactor_t reactor;
    size_t net_accepted = 0, net_orderly = 0, net_errors = 0, net_refused = 0;
    size_t net_framed = 0, net_rejected = 0;
    if (listen_mode) {
        int listen_fd;
        uint16_t bound = 0;
        if (tcp_listener_open((uint16_t)listen_port, &listen_fd, &bound) != GW_OK) {
            fprintf(stderr, "error: cannot listen on 127.0.0.1:%ld: %s\n", listen_port, strerror(errno));
            rc = 1;
        } else if (reactor_init(&reactor, listen_fd, net_on_event, NULL) != GW_OK) {
            close(listen_fd);
            rc = 1;
        } else {
            printf("listening on 127.0.0.1:%u (serving %zu clients, 1 worker)\n", bound, serve_clients);
            fflush(stdout);                                 /* scripts read the port from this line */
            /* Serve until the agreed number of clients have connected AND all have gone. */
            while (!(reactor.accepted + reactor.rejected_conns >= serve_clients && reactor.active == 0)) {
                if (reactor_step(&reactor, 200) != GW_OK) {
                    fprintf(stderr, "error: poll: %s\n", strerror(errno));
                    rc = 1;
                    break;
                }
                emit_snapshots();                           /* complete windows, as events stream in */
            }
            reactor_shutdown(&reactor);                     /* every client fd, then the listener */
            net_accepted = reactor.accepted;
            net_orderly  = reactor.closed_orderly;
            net_errors   = reactor.closed_error;
            net_refused  = reactor.rejected_conns;
            net_framed   = reactor.framed_events;
            net_rejected = reactor.framed_rejected;
        }
    }
    for (size_t i = 0; i < n_inputs && rc == 0; i++) {
        if (n_inputs > 1)
            printf("--- input %zu/%zu: %s ---\n", i + 1, n_inputs, inputs[i].path);
        rc = process_file(inputs[i].path);
    }

    size_t worker_processed = 0;
    if (n_workers > 0) {
        if (worker_pool_stop(&pool, &worker_processed) != GW_OK) {   /* close, drain, join, per-slot sum */
            fprintf(stderr, "error: worker shutdown failed\n");
            rc = 1;
        }
    } else {
        process_intake();                                       /* anything queued by the last read */
    }
    emit_snapshots();                                           /* the last window, once everything is processed */

    diag_report();
    if (listen_mode) {
        printf("network: %zu clients accepted, %zu closed, %zu errors, %zu refused\n",
               net_accepted, net_orderly, net_errors, net_refused);
        printf("parser: %zu events, %zu rejected\n", net_framed, net_rejected);
    } else {
        printf("parser: %zu events, %zu rejected\n", total.events, total.rejected);
    }
    printf("store: %zu retained events\n", event_store_len(store));
    printf("snapshots: %zu emitted, %zu skipped, arena peak %zu of %zu bytes\n",
           snapshots, skipped, arena_peak, arena.capacity);
    printf("intake: %zu queued, %zu processed, %zu still queued\n",
           queued, processed, work_queue_size(&intake));
    if (n_workers > 0)
        printf("workers: %zu threads processed %zu events (per-slot counts, read after join)\n",
               n_workers, worker_processed);
    printf("sinks: %zu registered\n", diag_sink_list_count(&sinks));

    printf("devices: %zu tracked (registry capacity %zu)\n",
           device_registry_count(devices), device_registry_capacity(devices));
    device_registry_for_each(devices, print_device, NULL);      /* D2.6b: through the interface */
    printf("lifecycle: %zu transitions, %zu no-ops, %zu rejected\n", transitions, stayed, rejected);
    printf("alerts: %zu raised (policy %s); most urgent first:\n", raised, policy->name);
    alert_t a;
    for (int shown = 0; shown < 5 && alert_heap_pop(&alerts, &a); shown++)
        printf("  sev %u  seq %llu  module %u  %s\n",
               a.severity, (unsigned long long)a.seq, a.module_id, a.code);
    printf("  (%zu more queued)\n", alert_heap_size(&alerts));

    if (reporter_exe) {
        signal(SIGPIPE, SIG_IGN);                           /* a vanished reader becomes EPIPE, not a death sentence */
        if (send_health_report(reporter_exe) != 0)
            rc = 1;
    }

    alert_heap_destroy(&alerts);
    device_registry_destroy(devices);
    devices = NULL;
    diag_sink_list_destroy(&sinks);
    work_queue_destroy(&intake);                /* after every worker was joined; frees anything still queued */
    diag_shutdown();
    arena_destroy(&arena);
    event_store_destroy(store);
    store = NULL;
    printf("heap: %zu new blocks, %zu live at exit\n",
           gw_alloc_total_count(), gw_alloc_live_count());
    return rc;
}
