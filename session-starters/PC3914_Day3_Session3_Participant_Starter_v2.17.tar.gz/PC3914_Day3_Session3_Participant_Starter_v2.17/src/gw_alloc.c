#include "gw_alloc.h"
#include <stdatomic.h>
#include <stdlib.h>

/* Day 3 Block 2: the counters are now touched from several threads at once.
 * `live_blocks++` on a plain size_t is a data race (load, add, store — three
 * steps that interleave); on an _Atomic it is one indivisible read-modify-write.
 * fail_after stays plain: it is a single-threaded test hook, set before any
 * worker exists. */
static int           fail_after   = -1;
static _Atomic size_t live_blocks  = 0;
static _Atomic size_t total_blocks = 0;

static int should_fail(void)
{
    if (fail_after < 0)
        return 0;
    if (fail_after == 0) {
        fail_after = -1;        /* one-shot */
        return 1;
    }
    fail_after--;
    return 0;
}

void *gw_malloc(size_t n)
{
    if (should_fail())
        return NULL;
    void *p = malloc(n);
    if (p) { live_blocks++; total_blocks++; }
    return p;
}

void *gw_calloc(size_t count, size_t size)
{
    if (should_fail())
        return NULL;
    void *p = calloc(count, size);
    if (p) { live_blocks++; total_blocks++; }
    return p;
}

void *gw_realloc(void *old, size_t n)
{
    if (should_fail())
        return NULL;
    void *p = realloc(old, n);
    if (p && !old) { live_blocks++; total_blocks++; }
    return p;
}

void gw_free(void *p)
{
    if (p)
        live_blocks--;
    free(p);
}

void   gw_alloc_fail_after(int calls) { fail_after = calls; }
size_t gw_alloc_live_count(void)      { return live_blocks; }
size_t gw_alloc_total_count(void)     { return total_blocks; }
