#!/bin/sh
# net_check.sh — deterministic network integration check (Day 3 Block 3).
#
# Starts the gateway on an EPHEMERAL loopback port (--listen 0), reads the
# bound port from its first output line, then drives it with two sequential
# clients (sequential on purpose: the Reactor's observed order is then fixed,
# so the whole report — sequence numbers and lifecycle included — must be
# byte-identical on every run; concurrency-safety is proven by test_reactor).
#
#   client 1: alpha.txt, fragmented into 7-byte writes
#   client 2: beta.txt, one write
#
# Usage: scripts/net_check.sh <gateway-binary> <client-binary> <out-log>
# Exit 0 only when the run completed and the report contains the expected lines.

GW="$1"; CLIENT="$2"; LOG="$3"
[ -x "$GW" ] && [ -x "$CLIENT" ] || { echo "net_check: missing binaries"; exit 1; }

"$GW" --listen 0 --serve-clients 2 > "$LOG" 2>&1 &
GWPID=$!

PORT=""
for i in $(seq 1 50); do                          # bounded wait for the "listening" line
    PORT=$(sed -n 's/^listening on 127\.0\.0\.1:\([0-9]*\).*/\1/p' "$LOG")
    [ -n "$PORT" ] && break
    sleep 0.1
done
if [ -z "$PORT" ]; then
    echo "net_check: gateway never reported its port (see $LOG)"
    kill "$GWPID" 2>/dev/null; wait "$GWPID" 2>/dev/null
    exit 1
fi

"$CLIENT" "$PORT" --fragment 7 --delay-us 200 < data/events/alpha.txt 2>/dev/null || { echo "net_check: client 1 failed"; kill "$GWPID"; exit 1; }
"$CLIENT" "$PORT" < data/events/beta.txt 2>/dev/null || { echo "net_check: client 2 failed"; kill "$GWPID"; exit 1; }

# the gateway exits by itself after serving 2 clients; bound the wait
( sleep 20; kill "$GWPID" 2>/dev/null ) & KILLER=$!
wait "$GWPID"; RC=$?
kill "$KILLER" 2>/dev/null; wait "$KILLER" 2>/dev/null

[ "$RC" -eq 0 ] || { echo "net_check: gateway exited with $RC (see $LOG)"; exit 1; }

ok=1
for want in \
    "network: 2 clients accepted, 2 closed, 0 errors, 0 refused" \
    "parser: 19 events, 0 rejected" \
    "store: 19 retained events" \
    "intake: 19 queued, 19 processed, 0 still queued" \
    "workers: 1 threads processed 19 events" \
    "devices: 3 tracked" \
    "lifecycle: 10 transitions, 7 no-ops, 2 rejected" \
    "alerts: 4 raised (policy default)" \
    "heap: .* 0 live at exit"
do
    grep -q "$want" "$LOG" || { echo "  MISSING   $want"; ok=0; }
done
[ $ok -eq 1 ] && echo "NET CHECK: PASS ($LOG)" || { echo "NET CHECK: FAIL (see $LOG)"; exit 1; }
