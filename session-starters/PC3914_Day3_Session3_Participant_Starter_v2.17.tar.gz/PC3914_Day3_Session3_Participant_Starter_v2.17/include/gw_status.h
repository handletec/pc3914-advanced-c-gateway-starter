#ifndef GW_STATUS_H
#define GW_STATUS_H

/* Project status codes.
 *
 * Gateway functions that can fail in an EXPECTED way return gw_status_t
 * (or NULL for pointer-returning functions, with the reason implied by the
 * contract). This is separate from POSIX `errno`: library calls such as
 * fopen() report through errno and are translated at the boundary where
 * they are called (see gateway.c). Project code never sets errno. */
typedef enum {
    GW_OK = 0,
    GW_ENOMEM,      /* heap allocation failed */
    GW_ENOSPACE,    /* arena capacity exhausted for this cycle */
    GW_EINVAL,      /* invalid argument at an API boundary */
    GW_ENOENT,      /* Day 2: no entry with that key (expected: lookup/removal miss) */
    GW_EEXIST,      /* Day 2: an entry with that key already exists */
    GW_EIO,         /* Day 3: a system call failed; errno holds the reason at the boundary */
    GW_ECLOSED      /* Day 3: the work queue is closed — push: caller keeps the item; pop: shutdown */
} gw_status_t;

/* Static, never NULL. */
const char *gw_strstatus(gw_status_t s);

#endif
