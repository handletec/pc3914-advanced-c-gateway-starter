#ifndef HEALTH_REPORT_H
#define HEALTH_REPORT_H
#include <stddef.h>
#include <stdint.h>

/* The health record the gateway sends to the health_reporter child (Day 3 Block 1).
 *
 * A fixed-size binary record for a pipe between two processes built from the
 * same tree on the same machine: 4 magic bytes, a version, four counters.
 * sizeof(health_record_t) == 40 with no padding (checked by the tests). A
 * portable wire format is a later topic; this is process-local IPC. */

#define HEALTH_MAGIC   "GWHR"
#define HEALTH_VERSION 1u

typedef struct {
    char     magic[4];
    uint32_t version;
    uint64_t processed;      /* events processed by the intake stage */
    uint64_t rejected;       /* lifecycle events rejected by the state machine */
    uint64_t alerts;         /* alerts raised under the selected policy */
    uint64_t modules;        /* modules tracked in the registry */
} health_record_t;

void health_record_init(health_record_t *r, uint64_t processed, uint64_t rejected,
                        uint64_t alerts, uint64_t modules);
int  health_record_valid(const health_record_t *r, size_t received);   /* 1 = complete and well-formed */

#endif
