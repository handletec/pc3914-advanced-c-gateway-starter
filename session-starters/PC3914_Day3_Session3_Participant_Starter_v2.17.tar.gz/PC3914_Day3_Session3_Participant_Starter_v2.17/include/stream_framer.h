#ifndef STREAM_FRAMER_H
#define STREAM_FRAMER_H
#include "event_parser.h"
#include "gw_status.h"
#include <stddef.h>

/* Per-connection stream framing (Day 3 Block 3).
 *
 * TCP delivers BYTES, not records: one read() may return half a line, one
 * line, several lines, or a line split anywhere. Each connection therefore
 * keeps persistent receive state — a buffer and how much of it is used —
 * and record boundaries are recovered from the bytes, exactly as the Day 1
 * parser already does for file chunks.
 *
 *   client_feed   append bytes (bounded), parse every COMPLETE record with
 *                 parse_events(), emit each one, keep the incomplete tail
 *                 at the front of the buffer. GW_ENOSPACE when a record
 *                 cannot fit the buffer even after compaction: the caller
 *                 drops the connection (a protocol violation, not a crash).
 *   client_read   drain a NONBLOCKING descriptor: n > 0 feed; n == 0 peer
 *                 closed; EINTR retry; EAGAIN/EWOULDBLOCK no more bytes now
 *                 (never spin); other errors GW_EIO.
 *
 * LIFETIME RULE (the Day 1 rule, third costume): the event_view_t handed to
 * `emit` points INTO this client's buffer and dies when client_feed
 * compacts or refills it. Clone an owned event_t inside emit — the gateway
 * clones and enqueues — never store the view or its payload pointer.
 *
 * parse_events() takes a plain callback with no context parameter, so the
 * framer bridges emit/ctx through file-scope state. That is safe here
 * because framing runs only on the Reactor thread; it is NOT reentrant. */

#define CLIENT_BUF_MAX 4096

typedef struct {
    int    fd;                  /* -1 = free slot */
    char   buf[CLIENT_BUF_MAX]; /* bytes received, not yet part of a complete record */
    size_t used;
    size_t events;              /* complete records emitted on this connection */
    size_t rejected;            /* malformed records rejected by the parser */
} client_t;

typedef void (*framer_emit_t)(const event_view_t *ev, void *ctx);

void        client_init(client_t *c, int fd);
gw_status_t client_feed(client_t *c, const char *data, size_t len, framer_emit_t emit, void *ctx);
            /* GW_OK | GW_ENOSPACE (record longer than the buffer; connection should be dropped) */
gw_status_t client_read(client_t *c, framer_emit_t emit, void *ctx, int *peer_closed);
            /* GW_OK (*peer_closed set 0/1; an unterminated tail at EOF is counted rejected) | GW_EINVAL | GW_ENOSPACE | GW_EIO */

#endif
