#ifndef REACTOR_H
#define REACTOR_H
#include "stream_framer.h"
#include "tcp_server.h"
#include <poll.h>
#include <stddef.h>

/* One event-driven Reactor over poll() (Day 3 Block 3).
 *
 *   Wait for READINESS, then DISPATCH the handler responsible for that
 *   descriptor. Handlers are short and never block: the listener handler
 *   accepts until EAGAIN; a client handler reads until EAGAIN and emits
 *   every complete record. One slow or silent client cannot block another —
 *   the Reactor only touches descriptors poll() reported ready.
 *
 * Layout: fds[0] is the listener; fds[i + 1] belongs to clients[i].
 * Removal strategy (fixed slots): a free slot has clients[i].fd == -1 and
 * fds[i + 1].fd == -1 — poll() ignores negative fds, so a closed client
 * leaves NO stale entry and no other slot ever moves. When every slot is in
 * use, a new connection is accepted and immediately closed (counted in
 * rejected_conns) so the listener does not stay permanently readable.
 *
 * Emitted views obey the framer's lifetime rule: `emit` must clone before
 * the Reactor touches that client's buffer again. The Reactor never blocks
 * on the work queue and holds no lock while reading sockets. */

#define REACTOR_MAX_CLIENTS 8

typedef struct {
    int           listen_fd;                          /* owned after successful reactor_init; reactor_shutdown closes it */
    struct pollfd fds[REACTOR_MAX_CLIENTS + 1];       /* [0] listener; [i+1] <-> clients[i] */
    client_t      clients[REACTOR_MAX_CLIENTS];
    framer_emit_t emit;
    void         *ctx;
    size_t        accepted;                           /* connections accepted over the Reactor's life */
    size_t        active;                             /* clients connected right now */
    size_t        closed_orderly, closed_error, rejected_conns;
    size_t        framed_events, framed_rejected;    /* totals folded in when a client leaves */
} reactor_t;

gw_status_t reactor_init(reactor_t *r, int listen_fd, framer_emit_t emit, void *ctx);
gw_status_t reactor_step(reactor_t *r, int timeout_ms);
            /* one poll() (EINTR retried) + full dispatch; GW_OK (also on timeout) | GW_EIO (poll failed) */
size_t      reactor_active_clients(const reactor_t *r);
void        reactor_shutdown(reactor_t *r);           /* close every client, then the listener */

#endif
