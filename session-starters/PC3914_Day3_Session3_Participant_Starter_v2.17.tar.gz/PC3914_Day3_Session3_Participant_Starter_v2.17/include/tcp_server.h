#ifndef TCP_SERVER_H
#define TCP_SERVER_H
#include "gw_status.h"
#include <stdint.h>

/* Loopback TCP listener (Day 3 Block 3, prepared).
 *
 * The whole lifecycle the gateway needs, and nothing more:
 *
 *   socket(AF_INET, SOCK_STREAM, 0)
 *   setsockopt(SO_REUSEADDR)          restart without "address already in use"
 *   bind(127.0.0.1, port)             port 0 = the kernel picks an ephemeral port
 *   listen(backlog)
 *   getsockname                       reports the port actually bound (for port 0)
 *   fcntl(O_NONBLOCK)                 the listener never blocks the Reactor
 *
 * Loopback only: this gateway does not accept remote connections.
 * Every syscall reports -1 + errno; this boundary translates to GW_EIO with
 * errno preserved for the caller's message, and never leaks a descriptor on
 * a partial failure. */

gw_status_t tcp_listener_open(uint16_t port, int *listen_fd, uint16_t *bound_port);
            /* GW_OK: *listen_fd is open, nonblocking, listening on 127.0.0.1:*bound_port */
gw_status_t tcp_set_nonblocking(int fd);   /* fcntl F_GETFL, then F_SETFL with O_NONBLOCK added */

#endif
