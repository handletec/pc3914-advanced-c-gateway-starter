#ifndef WORKER_POOL_H
#define WORKER_POOL_H
#include "work_queue.h"
#include <pthread.h>
#include <stddef.h>

/* A fixed set of worker threads draining one work queue (Day 3 Block 2).
 *
 * Each worker:  pop -> (mutex already released by pop) -> fn(event, ctx) -> repeat,
 * and leaves when pop reports GW_ECLOSED (closed AND empty). fn takes
 * OWNERSHIP of the event: it must event_free it or store it somewhere that
 * will. fn runs with no queue lock held; if it touches state shared with
 * other workers or with main, THAT state needs its own protection.
 *
 * Each worker has its own slot and writes ONLY its own `processed` field;
 * main reads a slot's count only after that worker's pthread_join succeeded.
 * Nothing is shared, so nothing needs a lock and no count can be torn.
 *
 * Lifecycle (main thread):
 *   worker_pool_start   creates n threads (1..WORKER_MAX) on an initialised queue.
 *                       On a partial pthread_create failure the queue is closed and
 *                       every created thread is joined directly. If complete
 *                       joining cannot be proven, the process aborts rather
 *                       than expose worker-visible state to destruction. A
 *                       proven unwind returns GW_EIO: fatal for this run.
 *   ... produce with work_queue_push ...
 *   worker_pool_stop    closes the queue (wakes every idle worker), joins every
 *                       created thread, sums the per-slot counts, and publishes
 *                       the total through *processed_out only when every join
 *                       succeeded (GW_OK). On a join failure it returns GW_EIO
 *                       and publishes nothing.
 *   work_queue_destroy  only after stop returned */

#define WORKER_MAX 8

typedef void (*work_fn_t)(event_t *e, void *ctx);

typedef struct {
    pthread_t     thread;
    work_queue_t *queue;          /* borrowed */
    work_fn_t     fn;
    void         *ctx;
    size_t        processed;      /* written by this worker only; read after its join */
} worker_slot_t;

typedef struct {
    work_queue_t  *queue;         /* borrowed */
    worker_slot_t  slots[WORKER_MAX];
    size_t         count;         /* unjoined threads in slots[0..count) */
    size_t         joined_processed; /* counts collected from successfully joined suffix */
} worker_pool_t;

gw_status_t worker_pool_start(worker_pool_t *p, work_queue_t *q, size_t n, work_fn_t fn, void *ctx);
            /* GW_OK | GW_EINVAL (bad arguments) | GW_EIO (pthread_create failed after a proven closed-queue/join rollback) */
gw_status_t worker_pool_stop(worker_pool_t *p, size_t *processed_out);
            /* GW_OK and *processed_out = total | GW_EINVAL | GW_EIO. On GW_EIO,
             *processed_out is untouched and the unjoined prefix is retained for retry. */

#endif
