#ifndef GW_CONFIG_H
#define GW_CONFIG_H
#include "gw_status.h"
#include <stddef.h>

/* Runtime configuration file (Day 3 Block 1) — the stdio layer.
 *
 * Format: one `key=value` per line; blank lines and lines starting with '#'
 * are ignored; no spaces around '='. Keys:
 *
 *   policy=<name>            alert classification policy (a Strategy name)
 *   arena_bytes=<decimal>    snapshot arena size, > 0
 *
 * A config file changes RUNTIME settings only. It cannot set a build-time
 * feature flag: `trace=1` is an unknown key and the file is rejected.
 *
 * Every value is COPIED into gw_config_t. The loader's line buffer is
 * local to gw_config_load(); nothing in the result points into it.
 *
 * Returns
 *   GW_OK        *out filled (unspecified keys keep the defaults set by gw_config_init)
 *   GW_ENOENT    the file cannot be opened (errno from fopen is preserved for the caller)
 *   GW_EINVAL    malformed line, unknown key or bad value; *err_line = 1-based line number
 *   GW_ENOSPACE  a value does not fit its field; *err_line set
 *   GW_EIO       a read error (ferror) after fopen succeeded
 * On any failure *out is left as gw_config_init() set it. */

#define GW_CONFIG_POLICY_MAX 32
#define GW_CONFIG_LINE_MAX   128

typedef struct {
    char   policy[GW_CONFIG_POLICY_MAX];   /* owned copy, NUL-terminated */
    size_t arena_bytes;
} gw_config_t;

void        gw_config_init(gw_config_t *c);                      /* policy "default", arena 16384 */
gw_status_t gw_config_load(const char *path, gw_config_t *out, size_t *err_line);

#endif
