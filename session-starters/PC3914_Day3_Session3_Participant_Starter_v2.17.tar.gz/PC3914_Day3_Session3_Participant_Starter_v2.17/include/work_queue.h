#ifndef WORK_QUEUE_H
#define WORK_QUEUE_H
#include "event_queue.h"
#include "gw_status.h"
#include <pthread.h>
#include <stddef.h>

/* Thread-safe work queue (Day 3 Block 2): the Day 2 event_queue_t, wrapped.
 *
 * The underlying FIFO is untouched. Three things are added around it, and
 * ONE mutex protects all three together — they are one invariant:
 *   - the queue's nodes and size
 *   - the closed flag
 *   - the wait predicate "size == 0 && !closed"
 *
 * Ownership contract (identical to event_queue_t)
 *   push, GW_OK        the queue owns `e` until popped or destroyed
 *   push, GW_ECLOSED   queue closed: unchanged, the CALLER still owns `e`
 *   push, GW_ENOMEM    unchanged, the caller still owns `e`
 *   push, GW_EINVAL    e == NULL
 *   pop,  GW_OK        *out is owned by the caller (event_free it or store it)
 *   pop,  GW_ECLOSED   closed AND empty: shutdown — no item, *out untouched
 *   destroy            frees every event still queued; call only after every
 *                      thread that uses the queue has been joined
 *
 * Blocking: pop waits (without spinning) while the queue is empty and open.
 * push signals not_empty after the predicate has become true; close
 * broadcasts so that every waiting worker wakes, sees closed, and leaves.
 * The mutex is held only around queue state — never while an item is
 * processed, printed or snapshotted. */

typedef struct {
    event_queue_t  *queue;        /* owned; the Day 2 FIFO */
    pthread_mutex_t mutex;        /* protects queue, closed, and the predicate */
    pthread_cond_t  not_empty;    /* "an item arrived, or the queue closed" */
    int             closed;
} work_queue_t;

gw_status_t work_queue_init(work_queue_t *q);                 /* GW_OK | GW_ENOMEM | GW_EIO (pthread init failed) */
gw_status_t work_queue_push(work_queue_t *q, event_t *e);
gw_status_t work_queue_pop(work_queue_t *q, event_t **out);   /* blocks; GW_OK | GW_ECLOSED */
void        work_queue_close(work_queue_t *q);                /* idempotent */
size_t      work_queue_size(work_queue_t *q);                 /* a snapshot: true only at the instant it was read */
int         work_queue_is_closed(work_queue_t *q);
void        work_queue_destroy(work_queue_t *q);              /* after joins only */

#endif
