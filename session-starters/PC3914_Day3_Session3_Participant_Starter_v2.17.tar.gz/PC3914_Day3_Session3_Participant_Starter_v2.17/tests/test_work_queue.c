/* test_work_queue.c — ownership, waiting, waking, draining, and many threads at once.
 *
 * Determinism: functional correctness does not depend on a race reproducing.
 * Bounded timeouts are used only as liveness/failure-detection thresholds: a
 * watchdog thread aborts the run after 10 s with a message naming the TODO
 * that usually causes the hang, and one check waits a bounded 200 ms to
 * observe that pop did NOT return on an empty open queue.
 *
 * The watchdog reads the current phase from an _Atomic index into a fixed
 * name table — test infrastructure, not a participant TODO; a plain pointer
 * here would itself be a data race between the test thread and the watchdog. */
#define _POSIX_C_SOURCE 200809L
#include "work_queue.h"
#include "gw_alloc.h"
#include <assert.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

enum {
    PH_START, PH_OWNERSHIP, PH_WAIT, PH_WAIT_PUSH, PH_WAIT_CLOSE,
    PH_DRAIN, PH_CONCURRENT, PH_CONCURRENT_CLOSE, PH_DESTROY
};
static const char *const phase_name[] = {
    "start", "ownership", "wait", "wait: push should wake the consumer",
    "wait: close should wake an idle consumer", "drain", "concurrent",
    "concurrent: close should wake and drain the consumers", "destroy"
};
static _Atomic int phase_id = PH_START;

static void set_phase(int id) { atomic_store_explicit(&phase_id, id, memory_order_relaxed); }

static void *watchdog(void *arg)
{
    (void)arg;
    struct timespec ts = { 10, 0 };
    nanosleep(&ts, NULL);
    int ph = atomic_load_explicit(&phase_id, memory_order_relaxed);
    fprintf(stderr, "\ntest_work_queue: HANG after 10 s during [%s]\n"
                    "  a waiter was never woken: push must signal (D3.3), close must broadcast (D3.4b)\n",
            phase_name[ph]);
    _exit(1);
}

static void pause_ms(long ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

static event_t *mk(uint32_t module_id, uint64_t seq)
{
    char payload[24];
    snprintf(payload, sizeof payload, "SEQ_%llu", (unsigned long long)seq);
    event_view_t v = { module_id, EV_SIGNAL, -70, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e && "test setup: event_clone failed");
    return e;
}

static uint64_t seq_of(const event_t *e) { return strtoull(e->payload + 4, NULL, 10); }

/* ---- [ownership] ---------------------------------------------------------- */
static void test_ownership(void)
{
    set_phase(PH_OWNERSHIP);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    assert(work_queue_push(&q, NULL) == GW_EINVAL);

    event_t *a = mk(1, 1);
    assert(work_queue_push(&q, a) == GW_OK);          /* queue owns a */
    assert(work_queue_size(&q) == 1);
    event_t *got = NULL;
    assert(work_queue_pop(&q, &got) == GW_OK && got == a);   /* we own it again */
    event_free(got);

    work_queue_close(&q);
    assert(work_queue_is_closed(&q));
    event_t *b = mk(1, 2);
    gw_status_t rc = work_queue_push(&q, b);
    assert(rc == GW_ECLOSED && "D3.3: push on a closed queue must be refused with GW_ECLOSED");
    assert(work_queue_size(&q) == 0);                 /* unchanged: b is still ours ... */
    event_free(b);                                    /* ... so we free it (a double free here would be the queue's bug) */

    got = (event_t *)0x1;
    assert(work_queue_pop(&q, &got) == GW_ECLOSED && got == (event_t *)0x1);   /* shutdown: *out untouched */
    work_queue_destroy(&q);
    assert(gw_alloc_live_count() == 0);
    printf("[ownership]  OK  push/pop transfer, closed push refused and caller kept the event\n");
}

/* ---- [wait] : a consumer blocks on an empty open queue; push wakes it; close wakes it ---- */
typedef struct {
    work_queue_t   *q;
    pthread_mutex_t m;                                /* protects the fields below (test-only state) */
    int             returned;
    gw_status_t     rc;
    event_t        *item;
} waiter_t;

static void *waiter_main(void *arg)
{
    waiter_t *w = arg;
    event_t *e = NULL;
    gw_status_t rc = work_queue_pop(w->q, &e);
    pthread_mutex_lock(&w->m);
    w->rc = rc;
    w->item = e;
    w->returned = 1;
    pthread_mutex_unlock(&w->m);
    return NULL;
}

static int has_returned(waiter_t *w)
{
    pthread_mutex_lock(&w->m);
    int r = w->returned;
    pthread_mutex_unlock(&w->m);
    return r;
}

static void test_wait_and_wake(void)
{
    set_phase(PH_WAIT);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    waiter_t w = { &q, PTHREAD_MUTEX_INITIALIZER, 0, GW_OK, NULL };
    pthread_t t;
    assert(pthread_create(&t, NULL, waiter_main, &w) == 0);

    pause_ms(200);                                    /* bounded observation window, failure detection only */
    if (has_returned(&w))
        fprintf(stderr, "  pop returned %s on an empty, OPEN queue\n", gw_strstatus(w.rc));
    assert(!has_returned(&w) && "D3.4a: pop must wait while the queue is empty and open");

    set_phase(PH_WAIT_PUSH);
    event_t *a = mk(3, 7);
    assert(work_queue_push(&q, a) == GW_OK);          /* signal -> the waiter wakes */
    assert(pthread_join(t, NULL) == 0);
    assert(w.rc == GW_OK && w.item == a);
    event_free(w.item);

    /* second waiter: nothing is pushed; close must wake it with GW_ECLOSED */
    set_phase(PH_WAIT_CLOSE);
    w.returned = 0; w.item = NULL;
    assert(pthread_create(&t, NULL, waiter_main, &w) == 0);
    pause_ms(50);
    work_queue_close(&q);                             /* broadcast -> the waiter wakes, sees closed+empty */
    assert(pthread_join(t, NULL) == 0);
    assert(w.rc == GW_ECLOSED && w.item == NULL);
    work_queue_destroy(&q);
    assert(gw_alloc_live_count() == 0);
    printf("[wait]       OK  pop blocked on empty; push woke it; close woke an idle waiter\n");
}

/* ---- [drain] : close does not discard queued work -------------------------- */
static void test_drain(void)
{
    set_phase(PH_DRAIN);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    for (uint64_t i = 0; i < 10; i++)
        assert(work_queue_push(&q, mk(1, i)) == GW_OK);
    work_queue_close(&q);
    for (uint64_t i = 0; i < 10; i++) {
        event_t *e = NULL;
        assert(work_queue_pop(&q, &e) == GW_OK && seq_of(e) == i);   /* FIFO order kept, all ten */
        event_free(e);
    }
    event_t *e = NULL;
    assert(work_queue_pop(&q, &e) == GW_ECLOSED);
    work_queue_destroy(&q);
    assert(gw_alloc_live_count() == 0);
    printf("[drain]      OK  10 queued items popped after close, then GW_ECLOSED\n");
}

/* ---- [concurrent] : P producers, C consumers, every item exactly once ------- */
#define PRODUCERS 3
#define CONSUMERS 3
#define PER_PRODUCER 200
#define TOTAL (PRODUCERS * PER_PRODUCER)

typedef struct {
    work_queue_t   *q;
    pthread_mutex_t m;                                /* protects seen[] — shared TEST state, not queue state */
    unsigned char   seen[TOTAL];
    size_t          consumed;
} shared_t;

typedef struct { shared_t *s; int index; } producer_arg_t;

static void *producer_indexed(void *arg)
{
    producer_arg_t *pa = arg;
    for (int i = 0; i < PER_PRODUCER; i++) {
        uint64_t seq = (uint64_t)pa->index * PER_PRODUCER + (uint64_t)i;
        event_t *e = mk((uint32_t)pa->index + 1, seq);
        assert(work_queue_push(pa->s->q, e) == GW_OK);
    }
    return NULL;
}

/* Each consumer writes only its own slot; main reads it after that join. */
typedef struct { shared_t *s; size_t consumed_here; } consumer_slot_t;

static void *consumer_main(void *arg)
{
    consumer_slot_t *me = arg;
    shared_t *s = me->s;
    event_t *e;
    while (work_queue_pop(s->q, &e) == GW_OK) {       /* no queue lock held from here on */
        uint64_t seq = seq_of(e);
        assert(seq < TOTAL);
        pthread_mutex_lock(&s->m);
        assert(s->seen[seq] == 0 && "an item was delivered twice");
        s->seen[seq] = 1;
        s->consumed++;
        pthread_mutex_unlock(&s->m);
        event_free(e);                                /* ownership: queue -> consumer -> freed */
        me->consumed_here++;
    }
    return NULL;
}

static void test_concurrent(void)
{
    set_phase(PH_CONCURRENT);
    static shared_t s;
    memset(&s, 0, sizeof s);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    s.q = &q;
    pthread_mutex_init(&s.m, NULL);

    pthread_t consumers[CONSUMERS], producers[PRODUCERS];
    consumer_slot_t cs[CONSUMERS];
    producer_arg_t pa[PRODUCERS];
    for (int i = 0; i < CONSUMERS; i++) {              /* consumers first: they must wait */
        cs[i].s = &s; cs[i].consumed_here = 0;
        assert(pthread_create(&consumers[i], NULL, consumer_main, &cs[i]) == 0);
    }
    for (int i = 0; i < PRODUCERS; i++) {
        pa[i].s = &s; pa[i].index = i;
        assert(pthread_create(&producers[i], NULL, producer_indexed, &pa[i]) == 0);
    }
    for (int i = 0; i < PRODUCERS; i++)
        assert(pthread_join(producers[i], NULL) == 0);
    set_phase(PH_CONCURRENT_CLOSE);
    work_queue_close(&q);                             /* every consumer drains, then leaves */
    size_t total = 0;
    for (int i = 0; i < CONSUMERS; i++) {
        assert(pthread_join(consumers[i], NULL) == 0);
        total += cs[i].consumed_here;                 /* read only after this consumer's join */
    }
    assert(total == TOTAL && s.consumed == TOTAL);
    for (size_t i = 0; i < TOTAL; i++)
        assert(s.seen[i] == 1 && "every item exactly once");
    assert(work_queue_size(&q) == 0);
    work_queue_destroy(&q);
    pthread_mutex_destroy(&s.m);
    assert(gw_alloc_live_count() == 0);
    printf("[concurrent] OK  %d producers x %d items, %d consumers: %zu items, each exactly once; 0 live\n",
           PRODUCERS, PER_PRODUCER, CONSUMERS, total);
}

/* ---- [destroy] : whatever is still queued is freed by destroy ---------------- */
static void test_destroy_frees(void)
{
    set_phase(PH_DESTROY);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    for (uint64_t i = 0; i < 5; i++)
        assert(work_queue_push(&q, mk(2, i)) == GW_OK);
    work_queue_destroy(&q);                           /* frees the five: the queue still owned them */
    assert(gw_alloc_live_count() == 0);
    printf("[destroy]    OK  5 still-queued events freed by destroy; 0 live\n");
}

int main(void)
{
    pthread_t dog;
    assert(pthread_create(&dog, NULL, watchdog, NULL) == 0);
    pthread_detach(dog);

    test_ownership();
    test_wait_and_wake();
    test_drain();
    test_concurrent();
    test_destroy_frees();
    printf("test_work_queue: all groups passed\n");
    return 0;
}
