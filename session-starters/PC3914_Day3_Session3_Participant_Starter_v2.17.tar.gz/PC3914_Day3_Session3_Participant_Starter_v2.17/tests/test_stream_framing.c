/* test_stream_framing.c — bytes become records: split, combined, tail kept, view cloned, bounded.
 * Deterministic prepared chunks; the [socketpair] group uses a real byte stream. */
#define _POSIX_C_SOURCE 200809L
#include "stream_framer.h"
#include "tcp_server.h"
#include "event.h"
#include "gw_alloc.h"
#include "gw_io.h"
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

/* Collecting emit: clones each view (the lifetime rule) and remembers the raw view pointer. */
#define MAX_GOT 16
typedef struct {
    event_t    *events[MAX_GOT];
    const char *view_payloads[MAX_GOT];         /* where the BORROWED payload pointed (for the clone proof) */
    size_t      n;
} collect_t;

static void collect(const event_view_t *ev, void *ctx)
{
    collect_t *g = ctx;
    assert(g->n < MAX_GOT);
    g->view_payloads[g->n] = ev->payload;       /* points into client.buf — will be overwritten */
    g->events[g->n] = event_clone(ev);          /* the rule: clone BEFORE the buffer is reused */
    assert(g->events[g->n]);
    g->n++;
}

static void free_all(collect_t *g)
{
    for (size_t i = 0; i < g->n; i++)
        event_free(g->events[i]);
    g->n = 0;
}


static void test_eof_tail_and_public_validation(void)
{
    client_init(NULL, -1);
    client_t invalid;
    client_init(&invalid, -1);
    collect_t g0 = { { 0 }, { 0 }, 0 };
    assert(client_feed(NULL, "x", 1, collect, &g0) == GW_EINVAL);
    assert(client_feed(&invalid, NULL, 1, collect, &g0) == GW_EINVAL);
    assert(client_feed(&invalid, "x", 1, NULL, &g0) == GW_EINVAL);
    int closed = 0;
    assert(client_read(NULL, collect, &g0, &closed) == GW_EINVAL);
    assert(client_read(&invalid, collect, &g0, &closed) == GW_EINVAL);
    int sp[2];
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sp) == 0);
    assert(tcp_set_nonblocking(sp[0]) == GW_OK);
    client_t c; collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, sp[0]);
    assert(write_all(sp[1], "3 SIGNAL -85 DEGRADED", 21) == GW_OK);
    close(sp[1]);
    assert(client_read(&c, collect, &g, &closed) == GW_OK && closed == 1);
    assert(g.n == 0 && c.events == 0 && c.rejected == 1 && c.used == 0);
    close(sp[0]);
    printf("[eof-tail]   OK  unterminated EOF tail rejected once and cleared; public arguments defended\n");
}
static void test_half_plus_half(void)
{
    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, -1);
    assert(client_feed(&c, "3 SIGNAL -", 10, collect, &g) == GW_OK);
    assert(g.n == 0 && c.used == 10);                             /* half a record: nothing emitted, tail kept */
    assert(client_feed(&c, "85 DEGRADED\n", 12, collect, &g) == GW_OK);
    assert(g.n == 1 && "TODO-D3.5: two halves must become exactly one event");
    assert(g.events[0]->module_id == 3 && g.events[0]->kind == EV_SIGNAL && g.events[0]->rssi_dbm == -85);
    assert(strcmp(g.events[0]->payload, "DEGRADED") == 0);
    assert(c.used == 0 && "TODO-D3.5: the consumed record must leave the buffer");
    free_all(&g);
    printf("[half+half]  OK  one record split across two feeds -> one event, empty buffer\n");
}

static void test_two_in_one(void)
{
    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, -1);
    const char *two = "1 CONNECT -70 ATTACH_OK\n6 ERROR -64 NETWORK_LOST\n";
    assert(client_feed(&c, two, strlen(two), collect, &g) == GW_OK);
    assert(g.n == 2 && "TODO-D3.5: two records in one feed -> two events");
    assert(g.events[0]->kind == EV_CONNECT && g.events[1]->kind == EV_ERROR);
    assert(c.used == 0);
    free_all(&g);
    printf("[two-in-one] OK  one feed carried two records -> two events\n");
}

static void test_tail_retained(void)
{
    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, -1);
    const char *chunk = "5 CONNECT -78 ATTACH_OK\n5 SIGNAL -8";       /* one and a bit */
    assert(client_feed(&c, chunk, strlen(chunk), collect, &g) == GW_OK);
    assert(g.n == 1);
    assert(c.used == 11 && memcmp(c.buf, "5 SIGNAL -8", 11) == 0 && "TODO-D3.5: the incomplete tail stays, at the front");
    assert(client_feed(&c, "0 CONNECTED\n", 12, collect, &g) == GW_OK);
    assert(g.n == 2 && g.events[1]->rssi_dbm == -80 && c.used == 0);
    free_all(&g);
    printf("[tail]       OK  incomplete tail kept at buf[0] and completed by the next feed\n");
}

/* The lifetime rule, proven: the clone survives; the view's bytes do not. */
static void test_clone_survives_reuse(void)
{
    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, -1);
    assert(client_feed(&c, "3 ERROR -113 SIM_NOT_READY\n", 27, collect, &g) == GW_OK);
    assert(g.n == 1);
    const char *view_payload = g.view_payloads[0];
    assert(view_payload >= c.buf && view_payload < c.buf + sizeof c.buf);   /* it pointed into the buffer */
    /* reuse the buffer: a different record travels through the same bytes */
    assert(client_feed(&c, "1 SIGNAL -70 CONNECTED_FINE_NOW\n", 32, collect, &g) == GW_OK);
    assert(g.n == 2);
    assert(strcmp(g.events[0]->payload, "SIM_NOT_READY") == 0 && "the CLONE is intact");
    assert(memcmp(view_payload, "SIM_NOT_READY", 13) != 0 && "the borrowed bytes are gone — never keep the view");
    free_all(&g);
    printf("[clone]      OK  cloned event intact after the buffer was reused; the view's bytes were not\n");
}

static void test_overlong_and_reject(void)
{
    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, -1);
    /* a "record" longer than the whole buffer: bounded, refused, not truncated */
    char big[CLIENT_BUF_MAX + 64];
    memset(big, 'A', sizeof big);                                  /* no newline anywhere */
    assert(client_feed(&c, big, sizeof big, collect, &g) == GW_ENOSPACE && "TODO-D3.5: overlong record -> GW_ENOSPACE");
    assert(g.n == 0);

    client_init(&c, -1);                                           /* malformed but terminated: rejected, counted */
    assert(client_feed(&c, "not an event line\n9 CONNECT -70 ATTACH_OK\n", 42, collect, &g) == GW_OK);
    assert(g.n == 1 && c.rejected == 1 && c.events == 1);
    free_all(&g);
    printf("[bounds]     OK  overlong refused with GW_ENOSPACE; malformed line rejected and counted\n");
}

/* A real byte stream: socketpair, fragmented writes, nonblocking reads, EOF. */
static void test_socketpair_read(void)
{
    int sp[2];
    assert(socketpair(AF_UNIX, SOCK_STREAM, 0, sp) == 0);
    assert(tcp_set_nonblocking(sp[0]) == GW_OK);

    client_t c;
    collect_t g = { { 0 }, { 0 }, 0 };
    client_init(&c, sp[0]);

    const char *text = "1 CONNECT -67 ATTACH_OK\n3 SIGNAL -95 DEGRADED\n3 ERROR -113 SIM_NOT_READY\n";
    size_t len = strlen(text);
    for (size_t off = 0; off < len; off += 7) {                    /* 7-byte fragments */
        size_t chunk = len - off < 7 ? len - off : 7;
        assert(write_all(sp[1], text + off, chunk) == GW_OK);
        int closed = 0;
        assert(client_read(&c, collect, &g, &closed) == GW_OK && closed == 0);
    }
    assert(g.n == 3 && c.events == 3);                             /* framed across 11 fragmented writes */
    int closed = 0;
    assert(client_read(&c, collect, &g, &closed) == GW_OK && closed == 0);   /* EAGAIN path: nothing new, no spin */
    close(sp[1]);
    assert(client_read(&c, collect, &g, &closed) == GW_OK && closed == 1);   /* EOF: orderly peer close */
    close(sp[0]);
    assert(g.events[2]->kind == EV_ERROR && strcmp(g.events[2]->payload, "SIM_NOT_READY") == 0);
    free_all(&g);
    printf("[socketpair] OK  3 records from 11 fragmented writes; EAGAIN did not spin; EOF observed\n");
}

int main(void)
{
    test_eof_tail_and_public_validation();
    test_half_plus_half();
    test_two_in_one();
    test_tail_retained();
    test_clone_survives_reuse();
    test_overlong_and_reject();
    test_socketpair_read();
    assert(gw_alloc_live_count() == 0);
    printf("test_stream_framing: all groups passed\n");
    return 0;
}
