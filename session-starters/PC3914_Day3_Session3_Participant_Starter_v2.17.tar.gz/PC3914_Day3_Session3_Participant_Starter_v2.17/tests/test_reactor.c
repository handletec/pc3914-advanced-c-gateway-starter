/* test_reactor.c — real loopback TCP on an ephemeral port, driven one step at a time.
 * The test controls every send and steps the Reactor between them, so the observed
 * order is chosen by the test: deterministic, no sleeps as correctness. Bounded
 * step budgets are liveness thresholds only (a broken Reactor fails, never hangs). */
#define _POSIX_C_SOURCE 200809L
#include "reactor.h"
#include "event.h"
#include "gw_alloc.h"
#include "gw_io.h"
#include <arpa/inet.h>
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

/* Collecting emit: clones (the lifetime rule) and remembers arrival order. */
#define MAX_GOT 64
typedef struct {
    event_t *events[MAX_GOT];
    size_t   n;
} collect_t;

static void collect(const event_view_t *ev, void *ctx)
{
    collect_t *g = ctx;
    assert(g->n < MAX_GOT);
    g->events[g->n] = event_clone(ev);
    assert(g->events[g->n]);
    g->n++;
}

static void free_all(collect_t *g)
{
    for (size_t i = 0; i < g->n; i++)
        event_free(g->events[i]);
    g->n = 0;
}

static size_t open_fds(void)
{
    DIR *d = opendir("/proc/self/fd");
    assert(d);
    size_t n = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL)
        if (e->d_name[0] != '.')
            n++;
    closedir(d);
    return n;
}

static int connect_client(uint16_t port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    assert(fd >= 0);
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_port   = htons(port);
    assert(inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr) == 1);
    assert(connect(fd, (struct sockaddr *)&addr, sizeof addr) == 0);
    return fd;
}

static void send_all(int fd, const char *s)
{
    size_t len = strlen(s);
    assert(write_all(fd, s, len) == GW_OK);
}

/* Step until a condition holds, within a bounded budget (liveness threshold). */
#define STEP_BUDGET 200
#define step_until(r, cond, why) do {                                            \
        int budget = STEP_BUDGET;                                                \
        while (!(cond) && budget-- > 0)                                          \
            assert(reactor_step((r), 20) == GW_OK);                              \
        if (!(cond))                                                             \
            fprintf(stderr, "  gave up after %d steps: %s\n", STEP_BUDGET, why); \
        assert((cond) && why);                                                   \
    } while (0)


static void test_hard_errors(void)
{
    collect_t g = { { 0 }, 0 };
    reactor_t r;
    assert(reactor_init(NULL, 0, collect, &g) == GW_EINVAL);
    assert(reactor_init(&r, -1, collect, &g) == GW_EINVAL);
    assert(reactor_init(&r, 0, NULL, &g) == GW_EINVAL);
    assert(reactor_step(NULL, 0) == GW_EINVAL);
    assert(tcp_listener_open(0, &r.listen_fd, &(uint16_t){0}) == GW_OK);
    int owned = r.listen_fd;
    assert(reactor_init(&r, owned, collect, &g) == GW_OK);
    assert(reactor_step(&r, -2) == GW_EINVAL);
    close(owned);
    errno = 0;
    assert(reactor_step(&r, 0) == GW_EIO);
    r.listen_fd = -1; r.fds[0].fd = -1;
    reactor_shutdown(&r);
    printf("[hard-error] OK  invalid inputs rejected; invalid listener surfaces as Reactor error\n");
}
static void test_accept_and_interleave(void)
{
    int lfd;
    uint16_t port = 0;
    assert(tcp_listener_open(0, &lfd, &port) == GW_OK && port != 0);   /* ephemeral: no hard-coded port */

    reactor_t r;
    collect_t g = { { 0 }, 0 };
    assert(reactor_init(&r, lfd, collect, &g) == GW_OK);
    assert(reactor_step(&r, 0) == GW_OK);                              /* nothing ready: a timeout is not an error */

    int a = connect_client(port);                                      /* the fragmenting client */
    int b = connect_client(port);                                      /* the bulk client */
    step_until(&r, r.accepted == 2 && r.active == 2, "TODO-D3.6a: two waiting connections must be accepted");

    /* A sends HALF a record and goes silent ... */
    send_all(a, "3 SIGNAL -");
    step_until(&r, r.clients[0].used + r.clients[1].used >= 10, "TODO-D3.6b: a ready client must be read");
    assert(g.n == 0);                                                  /* half a record is not an event */

    /* ... and B is not blocked behind it: two full records arrive and are framed */
    send_all(b, "1 CONNECT -70 ATTACH_OK\n1 SIGNAL -80 CONNECTED\n");
    step_until(&r, g.n == 2, "a silent client must not block another client's records");
    assert(g.events[0]->module_id == 1 && g.events[1]->module_id == 1);

    /* A completes its record: the kept tail plus the rest becomes one event */
    send_all(a, "105 DEGRADED\n");
    step_until(&r, g.n == 3, "TODO-D3.5/D3.6b: the split record must complete");
    assert(g.events[2]->module_id == 3 && g.events[2]->rssi_dbm == -105);

    /* orderly close of both; the Reactor notices EOF and frees both slots */
    close(a);
    close(b);
    step_until(&r, r.active == 0 && r.closed_orderly == 2, "TODO-D3.6b: EOF must remove the client, slot fd = -1");
    assert(r.clients[0].fd == -1 && r.fds[1].fd == -1);                /* no stale poll entry */

    /* a slot is reusable after removal */
    int c = connect_client(port);
    send_all(c, "6 ERROR -64 NETWORK_LOST\n");
    close(c);
    step_until(&r, g.n == 4 && r.active == 0, "a freed slot must accept a new client");
    assert(r.accepted == 3 && r.closed_orderly == 3);

    reactor_shutdown(&r);
    assert(g.n == 4);
    free_all(&g);
    assert(gw_alloc_live_count() == 0);
    printf("[reactor]    OK  2 clients interleaved, half record waited, none blocked; slots reused; 4 events in Reactor order\n");
}

static void test_full_table_rejects(void)
{
    size_t fds_before = open_fds();
    int lfd;
    uint16_t port = 0;
    assert(tcp_listener_open(0, &lfd, &port) == GW_OK);
    reactor_t r;
    collect_t g = { { 0 }, 0 };
    assert(reactor_init(&r, lfd, collect, &g) == GW_OK);

    int cfd[REACTOR_MAX_CLIENTS + 1];
    for (size_t i = 0; i < REACTOR_MAX_CLIENTS + 1; i++)
        cfd[i] = connect_client(port);                              /* one more than the table holds */
    step_until(&r, r.accepted == REACTOR_MAX_CLIENTS && r.rejected_conns == 1,
               "TODO-D3.6a: a full table must close the extra connection, not wedge the listener");
    assert(r.active == REACTOR_MAX_CLIENTS);

    for (size_t i = 0; i < REACTOR_MAX_CLIENTS + 1; i++)
        close(cfd[i]);
    step_until(&r, r.active == 0, "every EOF must be seen");
    reactor_shutdown(&r);
    assert(open_fds() == fds_before && "no descriptor may survive shutdown");
    free_all(&g);
    assert(gw_alloc_live_count() == 0);
    printf("[capacity]   OK  %d clients accepted, the extra one refused and closed; all descriptors returned\n",
           REACTOR_MAX_CLIENTS);
}

static void test_overlong_client_dropped(void)
{
    int lfd;
    uint16_t port = 0;
    assert(tcp_listener_open(0, &lfd, &port) == GW_OK);
    reactor_t r;
    collect_t g = { { 0 }, 0 };
    assert(reactor_init(&r, lfd, collect, &g) == GW_OK);

    int bad = connect_client(port);
    step_until(&r, r.active == 1, "accept the client first");
    char junk[CLIENT_BUF_MAX + 512];
    memset(junk, 'X', sizeof junk);                                  /* an endless "record": no newline */
    assert(write_all(bad, junk, sizeof junk) == GW_OK);
    step_until(&r, r.active == 0 && r.closed_error == 1,
               "TODO-D3.6b: an overlong record must drop the client, not the gateway");
    close(bad);
    reactor_shutdown(&r);
    assert(g.n == 0);
    assert(gw_alloc_live_count() == 0);
    printf("[overlong]   OK  a client streaming an endless record was dropped; the Reactor kept running\n");
}

int main(void)
{
    test_hard_errors();
    test_accept_and_interleave();
    test_full_table_rejects();
    test_overlong_client_dropped();
    printf("test_reactor: all groups passed\n");
    return 0;
}
