/* test_worker_pool.c — workers wait, drain, are joined, and their per-slot counts add up.
 *
 * Functional correctness does not depend on a race reproducing. Bounded
 * timeouts are used only as liveness/failure-detection thresholds (a 10 s
 * watchdog turns a hang into a message). The watchdog reads the phase from
 * an _Atomic index into a fixed name table — test infrastructure, not a
 * participant TODO. */
#define _POSIX_C_SOURCE 200809L
#include "worker_pool.h"
#include "gw_alloc.h"
#include <assert.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define N_ITEMS 300
#define N_WORKERS 3

enum { PH_START, PH_BAD_ARGS, PH_DRAIN_JOIN, PH_DRAIN_JOIN_STOP, PH_IDLE, PH_IDLE_STOP };
static const char *const phase_name[] = {
    "start", "bad-args", "drain-and-join", "drain-and-join: stop should close, drain and join",
    "idle-stop", "idle-stop: close must wake idle workers"
};
static _Atomic int phase_id = PH_START;

static void set_phase(int id) { atomic_store_explicit(&phase_id, id, memory_order_relaxed); }

static void *watchdog(void *arg)
{
    (void)arg;
    struct timespec ts = { 10, 0 };
    nanosleep(&ts, NULL);
    int ph = atomic_load_explicit(&phase_id, memory_order_relaxed);
    fprintf(stderr, "\ntest_worker_pool: HANG after 10 s during [%s]\n"
                    "  workers never left: does close broadcast (D3.4b)? does stop join (D3.4c)?\n"
                    "  or is the work function running with the queue mutex still held?\n", phase_name[ph]);
    _exit(1);
}

static event_t *mk(uint32_t module_id, uint64_t seq)
{
    char payload[24];
    snprintf(payload, sizeof payload, "SEQ_%llu", (unsigned long long)seq);
    event_view_t v = { module_id, EV_SIGNAL, -70, payload, strlen(payload) };
    event_t *e = event_clone(&v);
    assert(e);
    return e;
}

/* Shared state the WORK FUNCTION touches: it needs its own lock (not the queue's). */
typedef struct {
    pthread_mutex_t m;
    unsigned char   seen[N_ITEMS];
    size_t          per_module[4];
    work_queue_t   *q;
} tally_t;

/* The work function takes ownership of e. It also asks the queue for its size:
 * if the worker still held the queue mutex while calling us, that call would
 * deadlock — the watchdog would report it. */
static void tally_fn(event_t *e, void *ctx)
{
    tally_t *t = ctx;
    (void)work_queue_size(t->q);                              /* proves: no queue lock held during work */
    uint64_t seq = strtoull(e->payload + 4, NULL, 10);
    assert(seq < N_ITEMS && e->module_id >= 1 && e->module_id <= 3);
    pthread_mutex_lock(&t->m);
    assert(t->seen[seq] == 0 && "an item was processed twice");
    t->seen[seq] = 1;
    t->per_module[e->module_id]++;
    pthread_mutex_unlock(&t->m);
    event_free(e);                                            /* ownership ends here */
}

static void test_drain_and_join(void)
{
    set_phase(PH_DRAIN_JOIN);
    static tally_t t;
    memset(&t, 0, sizeof t);
    pthread_mutex_init(&t.m, NULL);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    t.q = &q;

    worker_pool_t pool;
    assert(worker_pool_start(&pool, &q, N_WORKERS, tally_fn, &t) == GW_OK);   /* workers wait on an empty queue */
    for (uint64_t i = 0; i < N_ITEMS; i++)
        assert(work_queue_push(&q, mk((uint32_t)(i % 3) + 1, i)) == GW_OK);   /* main produces while they run */

    set_phase(PH_DRAIN_JOIN_STOP);
    size_t total = 0;
    assert(worker_pool_stop(&pool, &total) == GW_OK);         /* close -> drain -> join -> per-slot sum */
    if (total != N_ITEMS)
        fprintf(stderr, "  stop published %zu, expected %d\n", total, N_ITEMS);
    assert(total == N_ITEMS && "D3.4c: stop must join every worker, then sum the per-slot counts");
    for (size_t i = 0; i < N_ITEMS; i++)
        assert(t.seen[i] == 1 && "every item exactly once");
    assert(t.per_module[1] == 100 && t.per_module[2] == 100 && t.per_module[3] == 100);
    assert(work_queue_size(&q) == 0 && work_queue_is_closed(&q));
    work_queue_destroy(&q);                                   /* safe: every worker was joined */
    pthread_mutex_destroy(&t.m);
    assert(gw_alloc_live_count() == 0);
    printf("[drain-join] OK  %d workers processed %zu items exactly once; joined; 0 live\n", N_WORKERS, total);
}

static void test_idle_stop(void)
{
    set_phase(PH_IDLE);
    static tally_t t;
    memset(&t, 0, sizeof t);
    pthread_mutex_init(&t.m, NULL);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    t.q = &q;
    worker_pool_t pool;
    assert(worker_pool_start(&pool, &q, N_WORKERS, tally_fn, &t) == GW_OK);
    set_phase(PH_IDLE_STOP);
    size_t total = 99;
    assert(worker_pool_stop(&pool, &total) == GW_OK);         /* nothing was ever pushed */
    assert(total == 0);
    work_queue_destroy(&q);
    pthread_mutex_destroy(&t.m);
    assert(gw_alloc_live_count() == 0);
    printf("[idle-stop]  OK  %d idle workers woken by close and joined; 0 processed\n", N_WORKERS);
}

static void test_bad_args(void)
{
    set_phase(PH_BAD_ARGS);
    work_queue_t q;
    assert(work_queue_init(&q) == GW_OK);
    worker_pool_t pool;
    size_t total = 0;
    assert(worker_pool_start(&pool, &q, 0, tally_fn, NULL) == GW_EINVAL);
    assert(worker_pool_start(&pool, &q, WORKER_MAX + 1, tally_fn, NULL) == GW_EINVAL);
    assert(worker_pool_start(&pool, &q, 2, NULL, NULL) == GW_EINVAL);
    assert(worker_pool_start(NULL, &q, 2, tally_fn, NULL) == GW_EINVAL);
    assert(worker_pool_stop(NULL, &total) == GW_EINVAL);
    pool.queue = &q;
    pool.count = 0;
    assert(worker_pool_stop(&pool, NULL) == GW_EINVAL);
    work_queue_destroy(&q);
    assert(gw_alloc_live_count() == 0);
    printf("[bad-args]   OK\n");
}

int main(void)
{
    pthread_t dog;
    assert(pthread_create(&dog, NULL, watchdog, NULL) == 0);
    pthread_detach(dog);
    test_bad_args();
    test_drain_and_join();
    test_idle_stop();
    printf("test_worker_pool: all groups passed\n");
    return 0;
}
